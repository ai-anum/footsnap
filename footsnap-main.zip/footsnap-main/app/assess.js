/* FootSnap · Assess
 *
 * The wound assessment: the form, its calculations, the checks and the report, in one file.
 * The questions follow the AireForms "Wound Assessment" report, with each item asked once.
 *
 *   1. SECTIONS     the form. Edit this list to add, remove or reword questions.
 *   2. measure()    wound size in cm from FootSnap's pixel measurements and a scale
 *   3. classify()   suggested Wagner and University of Texas (UT) classifications
 *   4. checks()     answers that contradict each other or the photo
 *   5. Form         draws SECTIONS as tap-friendly controls
 *   6. Report       the printable report and a plain-text summary for pasting into AireForms
 *
 * Nothing here talks to the server; app.html passes data in and saves what comes out.
 */
(function () {
  'use strict';

  /* ================================================================ 1. SECTIONS
   * Field types:
   *   one      pick one option          many    pick any (option `only` clears the others)
   *   yesno    Yes / No                 number  number with a unit
   *   pain     0–10 scale               text    free text (multiline: true for a box)
   *   date     a date
   * showIf(values) hides a field until it applies. `custom` sections are drawn by app code below.
   */
  const SECTIONS = [
    { id: 'patient', title: 'Patient and assessor', fields: [
      { id: 'patient_ref', label: 'Patient reference', type: 'text', hint: 'A study or hospital number. No names.' },
      { id: 'assessor', label: 'Assessed by', type: 'text' },
      { id: 'date', label: 'Assessment date', type: 'date' },
    ]},
    { id: 'wound', title: 'Wound', fields: [
      { id: 'location', label: 'Location', type: 'one', options: ['Toes', 'Plantar forefoot', 'Plantar midfoot', 'Heel', 'Dorsal foot', 'Medial ankle', 'Lateral ankle', 'Lower leg'] },
      { id: 'aetiology', label: 'Aetiology', type: 'one', options: ['Diabetic', 'Venous', 'Arterial', 'Pressure', 'Mixed'] },
      { id: 'onset', label: 'Wound onset', type: 'number', unit: 'year', min: 1950, max: 2100, step: 1 },
      { id: 'recurring', label: 'Recurring ulcer', type: 'yesno' },
    ]},
    { id: 'size', title: 'Size', custom: 'size', fields: [
      { id: 'size_length', label: 'Length', type: 'number', unit: 'cm', min: 0, step: 0.1, hint: 'Filled by measuring on the photo. Typing a value replaces it.' },
      { id: 'size_width', label: 'Width', type: 'number', unit: 'cm', min: 0, step: 0.1 },
      { id: 'size_depth', label: 'Depth', type: 'number', unit: 'cm', min: 0, step: 0.1, hint: 'Measure with a sterile probe. The 3D surface is relative and can\u2019t give depth.' },
    ]},
    { id: 'bed', title: 'Wound bed and edges', fields: [
      { id: 'tissue', label: 'Tissue types present', type: 'many', options: ['Granulation', 'Slough', 'Necrotic', 'Epithelialising', 'Hypergranulation'] },
      { id: 'margins', label: 'Wound margins', type: 'one', options: ['Well-defined', 'Irregular', 'Undermined', 'Rolled'] },
      { id: 'periwound', label: 'Surrounding skin', type: 'many', only: 'Healthy', options: ['Healthy', 'Erythema', 'Macerated', 'Callus', 'Dry or scaly'] },
      { id: 'odour', label: 'Odour', type: 'yesno' },
      { id: 'bleeding', label: 'Bleeding', type: 'one', options: ['None', 'Light', 'Moderate', 'Heavy'] },
    ]},
    { id: 'exudate', title: 'Exudate', fields: [
      { id: 'exudate_amount', label: 'Amount', type: 'one', options: ['None', 'Light', 'Moderate', 'Heavy'] },
      { id: 'exudate_type', label: 'Type', type: 'one', options: ['Serous', 'Sanguineous', 'Serosanguineous', 'Purulent'],
        showIf: (v) => v.exudate_amount && v.exudate_amount !== 'None' },
    ]},
    { id: 'infection', title: 'Infection and blood supply', fields: [
      { id: 'infection', label: 'Signs of infection', type: 'many', only: 'None', options: ['None', 'Swelling', 'Erythema over 2 cm', 'Warmth', 'Increasing pain', 'Purulent discharge'] },
      { id: 'ischaemia', label: 'Ischaemia', type: 'one', options: ['Yes', 'No', 'Not assessed'] },
      { id: 'oedema', label: 'Oedema', type: 'yesno' },
    ]},
    { id: 'depth', title: 'Depth and classification', custom: 'classification', fields: [
      { id: 'reach', label: 'Deepest structure reached', type: 'one', options: ['Skin only', 'Tendon or capsule', 'Bone or joint'] },
      { id: 'abscess', label: 'Abscess or osteomyelitis', type: 'yesno', showIf: (v) => v.reach && v.reach !== 'Skin only' },
      { id: 'gangrene', label: 'Gangrene', type: 'one', options: ['None', 'Forefoot', 'Whole foot'] },
    ]},
    { id: 'healing', title: 'Healing', fields: [
      { id: 'healing', label: 'Healing status', type: 'one', options: ['Improving', 'Static', 'Worsening', 'Healed'] },
    ]},
    { id: 'pain', title: 'Pain', fields: [
      { id: 'pain_frequency', label: 'How often', type: 'one', options: ['Never', 'Sometimes', 'Often', 'Constant'] },
      { id: 'pain_nature', label: 'Nature of pain', type: 'many', options: ['Sharp', 'Burning', 'Throbbing', 'Aching'], showIf: (v) => v.pain_frequency && v.pain_frequency !== 'Never' },
      { id: 'pain_night', label: 'At night', type: 'pain' },
      { id: 'pain_dressing', label: 'At dressing change', type: 'pain' },
      { id: 'pain_walking', label: 'On walking', type: 'pain' },
      { id: 'pain_other', label: 'Other times', type: 'pain' },
      { id: 'pain_interventions', label: 'Current pain relief', type: 'text' },
    ]},
    { id: 'notes', title: 'Notes', fields: [
      { id: 'notes', label: 'Clinical notes', type: 'text', multiline: true },
    ]},
  ];

  // What a section needs before it counts as complete (shown as "6 of 9 sections done").
  const REQUIRED = {
    patient: ['patient_ref', 'date'], wound: ['location', 'aetiology'], size: ['_size'],
    bed: ['tissue', 'periwound'], exudate: ['exudate_amount'], infection: ['infection', 'ischaemia'],
    depth: ['reach', 'gangrene'], healing: ['healing'], pain: ['pain_frequency'], notes: [],
  };

  /* ================================================================ 2. measure()
   * px     FootSnap's measurements of its traced outline, in image pixels: { length, width, area, perimeter }
   * marks  what the clinician marked on the photo, in image pixels:
   *          scale:  { pxPerCm, points: [[x,y],[x,y]], cm }   two points on the ruler and their distance
   *          length: [[x,y],[x,y]]                             both ends of the wound
   *          width:  [[x,y],[x,y]]                             both edges, across the length
   * v      form values: a typed size_length / size_width replaces the marked one; size_depth is typed
   * Every number says where it came from, so the report can show it. Priority for length and width:
   * typed > marked on the photo > FootSnap's outline.
   */
  function measure(px, marks, v) {
    marks = marks || {};
    const ppc = marks.scale && marks.scale.pxPerCm;
    const outline = (n, power) => (ppc && px && px[n] ? round(px[n] / Math.pow(ppc, power || 1)) : null);
    const marked = (k) => (ppc && marks[k] && marks[k].length === 2 ? round(dist(marks[k]) / ppc) : null);
    const none = { value: null, source: null };
    const pick = (k, typedKey) => {
      const typed = num(v[typedKey]);
      if (typed != null) return { value: typed, source: 'clinician' };
      if (marked(k) != null) return { value: marked(k), source: 'photo' };
      if (outline(k) != null) return { value: outline(k), source: 'footsnap' };
      return none;
    };
    const length = pick('length', 'size_length');
    const width = pick('width', 'size_width');
    const depth = num(v.size_depth) != null ? { value: num(v.size_depth), source: 'clinician' } : none;
    const both = length.value != null && width.value != null;
    // Area and perimeter come from FootSnap's traced outline when there is a scale; otherwise an ellipse from L x W.
    const area = outline('area', 2) != null ? { value: outline('area', 2), source: 'footsnap' }
      : both ? { value: round(Math.PI / 4 * length.value * width.value), source: 'ellipse' } : none;
    const perimeter = outline('perimeter') != null ? { value: outline('perimeter'), source: 'footsnap' }
      : both ? { value: round(ellipsePerimeter(length.value / 2, width.value / 2)), source: 'ellipse' } : none;
    // Volume: ellipsoid, pi/6 x L x W x D (a box, L x W x D, overstates it by about 1.9x)
    const volume = both && depth.value != null ? { value: round(Math.PI / 6 * length.value * width.value * depth.value), source: 'ellipsoid' } : none;
    return { length, width, depth, area, perimeter, volume };
  }
  const dist = (p) => Math.hypot(p[1][0] - p[0][0], p[1][1] - p[0][1]);
  // Angle between the length and width lines, in degrees (90 = at right angles).
  function crossAngle(marks) {
    if (!marks || !marks.length || !marks.width) return null;
    const a = Math.atan2(marks.length[1][1] - marks.length[0][1], marks.length[1][0] - marks.length[0][0]);
    const b = Math.atan2(marks.width[1][1] - marks.width[0][1], marks.width[1][0] - marks.width[0][0]);
    const d = Math.abs(((a - b) * 180 / Math.PI) % 180);
    return Math.round(Math.min(d, 180 - d));
  }
  function ellipsePerimeter(a, b) { const h = ((a - b) ** 2) / ((a + b) ** 2); return Math.PI * (a + b) * (1 + 3 * h / (10 + Math.sqrt(4 - 3 * h))); }  // Ramanujan
  const round = (x) => Math.round(x * 10) / 10;
  const num = (x) => (x === '' || x == null || isNaN(Number(x)) ? null : Number(x));

  /* Measurements straight from a mask image, for imported masks (the server measures its own).
   * Length and width are the extents along the mask's main axes; perimeter counts boundary edges
   * and corrects for pixel steps (x pi/4). */
  function measureMask(imageData) {
    const { width: w, height: h, data } = imageData;
    let n = 0, sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0, edges = 0;
    const on = (x, y) => x >= 0 && y >= 0 && x < w && y < h && data[(y * w + x) * 4] > 127;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!on(x, y)) continue;
      n++; sx += x; sy += y; sxx += x * x; syy += y * y; sxy += x * y;
      edges += !on(x - 1, y) + !on(x + 1, y) + !on(x, y - 1) + !on(x, y + 1);
    }
    if (!n) return { area: 0, length: 0, width: 0, perimeter: 0 };
    const mx = sx / n, my = sy / n, cxx = sxx / n - mx * mx, cyy = syy / n - my * my, cxy = sxy / n - mx * my;
    const ang = 0.5 * Math.atan2(2 * cxy, cxx - cyy), c = Math.cos(ang), s = Math.sin(ang);
    let a0 = Infinity, a1 = -Infinity, b0 = Infinity, b1 = -Infinity;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!on(x, y)) continue;
      const u = (x - mx) * c + (y - my) * s, t = -(x - mx) * s + (y - my) * c;
      a0 = Math.min(a0, u); a1 = Math.max(a1, u); b0 = Math.min(b0, t); b1 = Math.max(b1, t);
    }
    const L = a1 - a0 + 1, W = b1 - b0 + 1;
    return { area: n, length: Math.max(L, W), width: Math.min(L, W), perimeter: edges * Math.PI / 4 };
  }

  /* ================================================================ 3. classify()
   * University of Texas: grade = depth (1 superficial, 2 tendon or capsule, 3 bone or joint),
   *                      stage = A clean, B infected, C ischaemic, D infected and ischaemic.
   * Wagner: 1 superficial, 2 deep to tendon or capsule, 3 deep with abscess or osteomyelitis
   *         (or bone involved), 4 forefoot gangrene, 5 whole-foot gangrene.
   * These are suggestions for the clinician to confirm, never a final answer.
   */
  function classify(v) {
    const missing = [];
    const depthGrade = { 'Skin only': 1, 'Tendon or capsule': 2, 'Bone or joint': 3 }[v.reach];
    if (!depthGrade) missing.push('deepest structure');
    const infection = Array.isArray(v.infection) && v.infection.length ? !v.infection.includes('None') : null;
    if (infection == null) missing.push('signs of infection');
    const ischaemia = v.ischaemia === 'Yes' ? true : v.ischaemia === 'No' ? false : null;
    if (ischaemia == null) missing.push(v.ischaemia === 'Not assessed' ? 'an ischaemia assessment' : 'ischaemia');

    let ut = null;
    if (depthGrade && infection != null && ischaemia != null) {
      const stage = infection && ischaemia ? 'D' : ischaemia ? 'C' : infection ? 'B' : 'A';
      const stageText = { A: 'no infection or ischaemia', B: 'infected', C: 'ischaemic', D: 'infected and ischaemic' }[stage];
      ut = { code: 'UT ' + depthGrade + stage, text: ['', 'Superficial', 'Penetrates to tendon or capsule', 'Penetrates to bone or joint'][depthGrade] + ', ' + stageText };
    }

    let wagner = null;
    if (v.gangrene === 'Whole foot') wagner = { code: 'Wagner 5', text: 'Gangrene of the whole foot' };
    else if (v.gangrene === 'Forefoot') wagner = { code: 'Wagner 4', text: 'Gangrene of the forefoot' };
    else if (v.gangrene === 'None' && depthGrade === 1) wagner = { code: 'Wagner 1', text: 'Superficial ulcer' };
    else if (v.gangrene === 'None' && (depthGrade === 3 || (depthGrade === 2 && v.abscess === 'Yes'))) wagner = { code: 'Wagner 3', text: 'Deep ulcer with abscess, osteomyelitis or bone involvement' };
    else if (v.gangrene === 'None' && depthGrade === 2 && v.abscess === 'No') wagner = { code: 'Wagner 2', text: 'Deep ulcer to tendon or capsule' };
    if (!wagner) { if (!v.gangrene) missing.push('gangrene'); if (depthGrade === 2 && !v.abscess) missing.push('abscess or osteomyelitis'); }

    return { ut, wagner, missing: [...new Set(missing)] };
  }

  /* ================================================================ 4. checks()
   * Answers that disagree. Shown while filling the form and on the report.
   * ctx.woundFound: FootSnap found a wound in the photo.
   */
  function checks(v, ctx) {
    const out = [];
    const has = (k, x) => Array.isArray(v[k]) && v[k].includes(x);
    if (v.exudate_type === 'Purulent' && has('infection', 'None')) out.push('Purulent exudate is recorded, but signs of infection say None.');
    if (has('infection', 'Purulent discharge') && v.exudate_type && v.exudate_type !== 'Purulent') out.push('Purulent discharge is a sign of infection, but the exudate type is ' + v.exudate_type.toLowerCase() + '.');
    if (v.healing === 'Healed' && ctx.woundFound) out.push('Marked as healed, but FootSnap still finds a wound in the photo.');
    if (v.gangrene && v.gangrene !== 'None' && !has('tissue', 'Necrotic')) out.push('Gangrene is recorded, but necrotic tissue is not selected.');
    if (v.reach === 'Skin only' && num(v.size_depth) != null && num(v.size_depth) > 1) out.push('Depth is over 1 cm, but the deepest structure is skin only.');
    const ang = crossAngle(ctx.marks);
    if (ang != null && ang < 70) out.push('The width line is at ' + ang + '° to the length. Measure width at right angles to the length.');
    const L = num(v.size_length), W = num(v.size_width);
    if (L != null && W != null && W > L) out.push('Width is larger than length. Length is usually the longest dimension.');
    return out;
  }

  function progress(v, hasSize) {
    const done = Object.entries(REQUIRED).filter(([, keys]) => keys.every((k) => k === '_size' ? hasSize : filled(v[k])));
    return { done: done.length, total: Object.keys(REQUIRED).length, doneIds: done.map(([id]) => id) };
  }
  // The codes a confirmation applies to; if the answers change the codes, it no longer applies.
  const classKey = (cls) => [cls.ut && cls.ut.code, cls.wagner && cls.wagner.code].join('|');
  const filled = (x) => (Array.isArray(x) ? x.length > 0 : x !== undefined && x !== null && x !== '');

  /* ================================================================ 5. Form */
  // Tiny DOM helper: h('div', { class: 'x', onclick: fn }, child, 'text', ...)
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, val] of Object.entries(attrs || {})) {
      if (val == null || val === false) continue;
      if (k.startsWith('on')) el.addEventListener(k.slice(2), val);
      else if (k === 'class') el.className = val;
      else el.setAttribute(k, val === true ? '' : val);
    }
    kids.flat().forEach((c) => c != null && c !== false && el.append(c.nodeType ? c : String(c)));
    return el;
  }

  /* createForm(root, app)
   *   app.values           current answers (object, edited in place)
   *   app.onChange()       called after every edit (app saves and redraws the custom parts)
   *   app.renderSize(box)  draws the Size section (needs FootSnap's measurements)
   *   app.renderClass(box) draws the suggested classification
   * Returns refresh(): re-applies showIf, completion marks and the custom parts without
   * rebuilding inputs, so typing never loses focus.
   */
  function createForm(root, app) {
    const v = app.values;
    root.textContent = '';
    const rows = [];      // [{ field, row }] for showIf
    const marks = {};     // section id -> completion mark

    const change = () => { refresh(); app.onChange(); };

    SECTIONS.forEach((sec) => {
      const mark = h('span', { class: 'fs-mark', 'aria-hidden': 'true' });
      marks[sec.id] = mark;
      const body = h('div', { class: 'fs-body' });
      const box = h('section', { class: 'fs-sec', id: 'fs-' + sec.id, 'aria-labelledby': 'fs-h-' + sec.id },
        h('h3', { id: 'fs-h-' + sec.id }, mark, sec.title), body);
      if (sec.custom === 'size') body.append(h('div', { class: 'fs-custom', 'data-custom': 'size' }));
      (sec.fields || []).forEach((f) => {
        const row = field(f, v, change);
        rows.push({ f, row }); body.append(row);
      });
      if (sec.custom === 'classification') body.append(h('div', { class: 'fs-custom', 'data-custom': 'classification' }));
      root.append(box);
    });

    function refresh() {
      rows.forEach(({ f, row }) => {
        const visible = !f.showIf || f.showIf(v);
        row.hidden = !visible;
        if (!visible && filled(v[f.id])) { delete v[f.id]; reset(row); }   // a hidden answer no longer applies
      });
      app.renderSize(root.querySelector('[data-custom="size"]'), root);
      app.renderClass(root.querySelector('[data-custom="classification"]'), change);
      const p = progress(v, app.hasSize());
      Object.entries(marks).forEach(([id, m]) => { m.dataset.done = p.doneIds.includes(id); });
      app.onProgress && app.onProgress(p);
    }
    refresh();
    return refresh;
  }

  function reset(row) {
    row.querySelectorAll('[aria-pressed="true"]').forEach((b) => b.setAttribute('aria-pressed', 'false'));
    row.querySelectorAll('input, textarea').forEach((i) => { if (i.type !== 'range') i.value = ''; });
  }

  let uid = 0;
  function field(f, v, change) {
    const id = 'f-' + f.id + '-' + (++uid);
    const label = h('span', { class: 'fs-label', id: id + '-l' }, f.label);
    const row = h('div', { class: 'fs-field', 'data-field': f.id });

    if (f.type === 'one' || f.type === 'yesno' || f.type === 'many') {
      const opts = f.type === 'yesno' ? ['Yes', 'No'] : f.options;
      const group = h('div', { class: 'fs-chips', role: 'group', 'aria-labelledby': id + '-l' });
      const sync = () => group.querySelectorAll('button').forEach((b) => {
        const on = f.type === 'many' ? (v[f.id] || []).includes(b.dataset.v) : v[f.id] === b.dataset.v;
        b.setAttribute('aria-pressed', on);
      });
      opts.forEach((o) => group.append(h('button', { type: 'button', class: 'fs-chip', 'data-v': o, 'aria-pressed': 'false', onclick: () => {
        if (f.type === 'many') {
          let list = (v[f.id] || []).slice();
          list = list.includes(o) ? list.filter((x) => x !== o) : (o === f.only ? [o] : list.filter((x) => x !== f.only).concat(o));
          if (list.length) v[f.id] = list; else delete v[f.id];
        } else if (v[f.id] === o) delete v[f.id]; else v[f.id] = o;
        sync(); change();
      } }, o)));
      sync();
      row.append(label, group);
    } else if (f.type === 'pain') {
      const out = h('span', { class: 'fs-pain-val' });
      const input = h('input', { type: 'range', min: 0, max: 10, step: 1, id, 'aria-labelledby': id + '-l' });
      const show = () => { out.textContent = v[f.id] == null ? 'Not set' : v[f.id] + ' / 10'; out.dataset.set = v[f.id] != null; };
      input.value = v[f.id] == null ? 0 : v[f.id];
      input.addEventListener('input', () => { v[f.id] = Number(input.value); show(); change(); });
      show();
      row.append(h('div', { class: 'fs-row' }, label, out), input, h('div', { class: 'fs-scale', 'aria-hidden': 'true' }, h('span', {}, '0 none'), h('span', {}, '10 worst')));
    } else if (f.type === 'number' || f.type === 'date' || f.type === 'text') {
      const tag = f.multiline ? 'textarea' : 'input';
      const input = h(tag, { id, class: 'fs-input', type: f.multiline ? null : (f.type === 'text' ? 'text' : f.type),
        inputmode: f.type === 'number' ? 'decimal' : null, min: f.min, max: f.max, step: f.step, rows: f.multiline ? 4 : null, autocomplete: 'off' });
      input.value = v[f.id] == null ? '' : v[f.id];
      input.addEventListener('input', () => { const x = input.value.trim(); if (x === '') delete v[f.id]; else v[f.id] = f.type === 'number' ? Number(x) : input.value; change(); });
      row.append(h('label', { class: 'fs-label', for: id }, f.label),
        f.unit ? h('div', { class: 'fs-unit' }, input, h('span', {}, f.unit)) : input);
      if (f.hint) row.append(h('span', { class: 'fs-hint' }, f.hint));
    }
    return row;
  }

  /* ================================================================ 6. Report
   * data = { values, sizes, cls, confirmed, issues, image, maps: [{label, src}], sourceText,
   *         scaleText, reportId, generated }
   */
  const SOURCE_TEXT = {
    photo: 'Marked on photo by clinician (ruler scale)', footsnap: 'FootSnap traced outline (ruler scale)',
    clinician: 'Entered by clinician', ellipse: 'Ellipse from length and width', ellipsoid: 'Ellipsoid, π/6 × L × W × D' };
  const show = (x) => (Array.isArray(x) ? x.join(', ') : x == null || x === '' ? '—' : String(x));
  const val = (m, unit) => (m && m.value != null ? m.value.toFixed(1) + ' ' + unit : '—');
  const yes = (x) => (x == null ? '—' : x);

  // Section rows, shared by the report and the plain-text summary (AireForms order).
  function reportRows(d) {
    const v = d.values, s = d.sizes;
    const pain = (k) => (v[k] == null ? '—' : v[k] + ' / 10');
    return [
      ['Wound characteristics', [['Location', show(v.location)], ['Aetiology', show(v.aetiology)], ['Wound onset', show(v.onset)], ['Recurring ulcer', yes(v.recurring)]]],
      ['Measurements', [['Length', val(s.length, 'cm')], ['Width', val(s.width, 'cm')], ['Depth', val(s.depth, 'cm')], ['Area', val(s.area, 'cm²')], ['Perimeter', val(s.perimeter, 'cm')], ['Volume', val(s.volume, 'cm³')]]],
      ['Wound bed and edges', [['Tissue types', show(v.tissue)], ['Granulation present', v.tissue ? (v.tissue.includes('Granulation') ? 'Yes' : 'No') : '—'],
        ['Wound margins', show(v.margins)], ['Surrounding skin', show(v.periwound)], ['Odour', yes(v.odour)], ['Bleeding', show(v.bleeding)]]],
      ['Exudate', [['Amount', show(v.exudate_amount)], ['Type', v.exudate_amount === 'None' ? 'None' : show(v.exudate_type)]]],
      ['Infection and perfusion', [['Signs of infection', show(v.infection)], ['Ischaemia', show(v.ischaemia)], ['Oedema', yes(v.oedema)]]],
      ['Depth and classification', [['Deepest structure', show(v.reach)], ['Abscess or osteomyelitis', yes(v.abscess)], ['Gangrene', show(v.gangrene)],
        ['University of Texas', d.cls.ut ? d.cls.ut.code + ' — ' + d.cls.ut.text : 'Insufficient information'],
        ['Wagner', d.cls.wagner ? d.cls.wagner.code + ' — ' + d.cls.wagner.text : 'Insufficient information'],
        ['Classification status', d.confirmed ? 'Confirmed by clinician' : 'Suggested, not confirmed']]],
      ['Healing', [['Healing status', show(v.healing)]]],
      ['Pain', [['Frequency', show(v.pain_frequency)], ['Nature', show(v.pain_nature)], ['At night', pain('pain_night')], ['At dressing change', pain('pain_dressing')],
        ['On walking', pain('pain_walking')], ['Other times', pain('pain_other')], ['Current pain relief', show(v.pain_interventions)]]],
      ['Clinical notes', [['Notes', show(v.notes)]]],
    ];
  }

  function renderReport(root, d) {
    const v = d.values, s = d.sizes, rows = Object.fromEntries(reportRows(d));
    const dl = (items) => h('dl', { class: 'rp-dl' }, items.map(([k, x]) => h('div', {}, h('dt', {}, k), h('dd', {}, x))));
    let n = 0;
    const sec = (title, ...body) => h('section', { class: 'rp-sec' }, h('h3', {}, h('span', { class: 'rp-n' }, String(++n)), title), ...body);
    const dims = [s.length, s.width, s.depth].every((m) => m.value != null)
      ? s.length.value.toFixed(1) + ' × ' + s.width.value.toFixed(1) + ' × ' + s.depth.value.toFixed(1) + ' cm'
      : s.length.value != null && s.width.value != null ? s.length.value.toFixed(1) + ' × ' + s.width.value.toFixed(1) + ' cm (depth —)' : '—';
    const classTxt = [d.cls.ut && d.cls.ut.code, d.cls.wagner && d.cls.wagner.code].filter(Boolean).join(' · ') || '—';
    const tile = (k, x, sub) => h('div', { class: 'rp-tile' }, h('span', {}, k), h('b', {}, x), sub ? h('small', {}, sub) : null);

    root.textContent = '';
    root.append(h('article', { class: 'rp', 'aria-label': 'Wound assessment report' },
      // letterhead
      h('header', { class: 'rp-letter' },
        h('div', { class: 'rp-brand' }, h('img', { src: 'icon-192.png', alt: 'FootSnap logo', width: 56, height: 56 }),
          h('div', {}, h('b', {}, 'FootSnap'), h('span', {}, 'Wound imaging and assessment'))),
        h('div', { class: 'rp-title' }, h('h2', {}, 'Diabetic Foot Ulcer Assessment'), h('span', {}, 'Report ' + d.reportId))),
      h('p', { class: 'rp-conf' }, 'Confidential. Contains patient information.'),
      // who / when
      h('table', { class: 'rp-meta' }, h('tbody', {},
        h('tr', {}, h('th', {}, 'Patient reference'), h('td', {}, show(v.patient_ref)), h('th', {}, 'Assessment date'), h('td', {}, show(v.date))),
        h('tr', {}, h('th', {}, 'Assessed by'), h('td', {}, show(v.assessor)), h('th', {}, 'Results source'), h('td', {}, d.sourceText)),
        h('tr', {}, h('th', {}, 'Wound location'), h('td', {}, show(v.location)), h('th', {}, 'Report generated'), h('td', {}, d.generated)))),
      // key findings first
      h('section', { class: 'rp-summary' }, h('h3', {}, 'Clinical summary'),
        h('div', { class: 'rp-tiles' },
          tile('Size (L × W × D)', dims, s.length.source ? SOURCE_TEXT[s.length.source] : null),
          tile('Area', val(s.area, 'cm²'), s.area.source ? SOURCE_TEXT[s.area.source] : null),
          tile('Classification', classTxt, d.confirmed ? 'Confirmed by clinician' : 'Suggested, not confirmed'),
          tile('Infection', show(v.infection)),
          tile('Ischaemia', show(v.ischaemia)),
          tile('Healing status', show(v.healing)))),
      d.issues.length ? h('div', { class: 'rp-issues' }, h('b', {}, 'Items to review before signing'), h('ul', {}, d.issues.map((t) => h('li', {}, t)))) : null,
      // images
      sec('Wound images',
        h('figure', { class: 'rp-fig' }, h('img', { src: d.image, alt: 'Wound photograph with the segmented wound outline and measurements' }),
          h('figcaption', {}, h('b', {}, 'Figure 1. '), 'Wound boundary from ' + d.sourceText.toLowerCase() + ' (outline). ' + d.scaleText)),
        d.maps.length ? h('div', { class: 'rp-maps' }, d.maps.map((m, i) => h('figure', {}, h('img', { src: m.src, alt: m.label + ' map' }),
          h('figcaption', {}, h('b', {}, 'Figure ' + (i + 2) + '. '), m.label)))) : null),
      // measurements with method
      sec('Measurements', h('table', { class: 'rp-table' },
        h('thead', {}, h('tr', {}, h('th', {}, 'Measurement'), h('th', {}, 'Value'), h('th', {}, 'Method'))),
        h('tbody', {}, [['Length', s.length, 'cm'], ['Width', s.width, 'cm'], ['Depth', s.depth, 'cm'], ['Area', s.area, 'cm²'], ['Perimeter', s.perimeter, 'cm'], ['Volume', s.volume, 'cm³']]
          .map(([k, m, u]) => h('tr', {}, h('td', {}, k), h('td', { class: 'num' }, val(m, u)), h('td', {}, m.source ? SOURCE_TEXT[m.source] : 'Not measured')))))),
      sec('Wound characteristics', dl(rows['Wound characteristics']), dl(rows['Wound bed and edges']), dl(rows['Exudate'])),
      sec('Infection, perfusion and classification', dl(rows['Infection and perfusion']), dl(rows['Depth and classification'])),
      sec('Healing', dl(rows['Healing'])),
      sec('Pain assessment', dl(rows['Pain'].slice(0, 2)), h('table', { class: 'rp-table rp-pain' },
        h('thead', {}, h('tr', {}, h('th', {}, 'Situation'), h('th', {}, 'Score (0–10)'))),
        h('tbody', {}, rows['Pain'].slice(2, 6).map(([k, x]) => h('tr', {}, h('td', {}, k), h('td', { class: 'num' }, x))))),
        dl(rows['Pain'].slice(6))),
      sec('Clinical notes', h('p', { class: 'rp-notes' }, show(v.notes))),
      // sign-off
      h('section', { class: 'rp-signoff' }, h('h3', {}, 'Clinician sign-off'),
        h('p', {}, 'I have reviewed the images, measurements and suggested classification in this report.'),
        h('div', { class: 'rp-sign' },
          h('div', {}, h('span', {}, show(v.assessor) === '—' ? '' : v.assessor), h('small', {}, 'Name')),
          h('div', {}, h('span', {}, ''), h('small', {}, 'Role and registration number')),
          h('div', {}, h('span', {}, ''), h('small', {}, 'Signature')),
          h('div', {}, h('span', {}, ''), h('small', {}, 'Date')))),
      h('footer', { class: 'rp-foot' },
        h('p', {}, h('b', {}, 'Method. '), 'Wound boundary by SegFormer-B5 segmentation (RGB + curvature from Marigold normals). Sizes in cm use a ruler scale marked on the photo. Area and perimeter follow the traced outline; volume is an ellipsoid estimate. The 3D surface is relative and is not used for depth.'),
        h('p', {}, h('b', {}, 'Limitations. '), 'FootSnap is a research prototype and not a medical device. Suggested classifications must be confirmed by the assessing clinician.')),
      h('p', { class: 'rp-endline' }, 'FootSnap · Report ' + d.reportId + ' · Research prototype · Confidential')));
  }

  // Plain text in the AireForms field order, for pasting.
  function summaryText(d) {
    const v = d.values;
    const lines = ['DIABETIC FOOT ULCER ASSESSMENT (FootSnap report ' + d.reportId + ')',
      'Patient reference: ' + show(v.patient_ref), 'Assessment date: ' + show(v.date), 'Assessed by: ' + show(v.assessor), 'Results source: ' + d.sourceText];
    reportRows(d).forEach(([title, items]) => { lines.push('', title.toUpperCase()); items.forEach(([k, x]) => lines.push(k + ': ' + x)); });
    if (d.issues.length) lines.push('', 'ITEMS TO REVIEW', ...d.issues.map((t) => '- ' + t));
    return lines.join('\n');
  }

  window.FootSnapAssess = { classKey, crossAngle, dist, SECTIONS, measure, measureMask, classify, checks, progress, createForm, renderReport, summaryText, h, SOURCE_TEXT };
})();
