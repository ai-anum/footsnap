"""Export the segmentation model for the browser (ONNX Runtime Web).

    pip install "torch==2.7.0" "transformers<5" onnx onnxruntime
    python web/export_onnx.py --check app/demo/200285/photo.jpg

Same model and wrapper as the iPhone (ios/tools/convert_model.py): RGB 0..255 in, wound
probability out, colour only (the browser has no Marigold, so the curvature channels are zero).

The weights are stored as float16 to halve the download (~170 MB); a Cast node turns each one
back into float32 when the model loads, so the browser computes in float32 on WebGPU or WASM.
The file is cut into parts under 25 MB (static hosts limit file sizes: Cloudflare Pages 25 MB, GitHub 100 MB);
web/footsnap-browser.js joins them again. Writes web/model/segformer.onnx.partN + parts.json.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import onnx
import torch
from onnx import TensorProto, helper, numpy_helper

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "ios" / "tools"))
from convert_model import OnDevice, build          # noqa: E402

PART = 24 * 1024 * 1024        # under 25 MB: the smallest per-file limit of the free static hosts (Cloudflare Pages)


def weights_to_fp16(model):
    """float32 initializers -> float16 initializer + Cast(to float32), same names downstream."""
    graph = model.graph
    keep, casts = [], []
    for init in graph.initializer:
        if init.data_type == TensorProto.FLOAT and np.prod(init.dims) >= 256:
            arr = numpy_helper.to_array(init).astype(np.float16)
            half = numpy_helper.from_array(arr, init.name + "__fp16")
            keep.append(half)
            casts.append(helper.make_node("Cast", [half.name], [init.name], to=TensorProto.FLOAT, name=init.name + "__cast"))
        else:
            keep.append(init)
    del graph.initializer[:]
    graph.initializer.extend(keep)
    nodes = list(graph.node)
    del graph.node[:]
    graph.node.extend(casts + nodes)
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=str(ROOT / "server" / "model.pt"))
    ap.add_argument("--out", default=str(ROOT / "web" / "model"))
    ap.add_argument("--check", help="a photo to compare ONNX against PyTorch on")
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    full = out / "segformer.onnx"

    net, n_in = build(args.model)
    wrapped = OnDevice(net, n_in).eval()
    example = torch.rand(1, 3, 480, 640) * 255
    with torch.no_grad():
        torch.onnx.export(wrapped, example, str(full), input_names=["image"], output_names=["probability"],
                          dynamic_axes={"image": {2: "height", 3: "width"}, "probability": {2: "height", 3: "width"}},
                          opset_version=17, dynamo=False)
    model = weights_to_fp16(onnx.load(str(full)))
    onnx.save(model, str(full))
    data = full.read_bytes()
    print(f"saved {full} ({len(data) / 1e6:.0f} MB)")

    if args.check:
        import onnxruntime as ort
        from PIL import Image
        img = Image.open(args.check).convert("RGB")
        x = np.asarray(img, np.float32).transpose(2, 0, 1)[None]
        with torch.no_grad():
            ref = wrapped(torch.from_numpy(x)).numpy()
        got = ort.InferenceSession(str(full), providers=["CPUExecutionProvider"]).run(None, {"image": x})[0]
        a, b = ref > 0.5, got > 0.5
        print(f"max |diff| {np.abs(ref - got).max():.4f}, mask IoU torch vs ONNX {(a & b).sum() / max((a | b).sum(), 1):.4f}, "
              f"wound pixels {a.sum()} vs {b.sum()}")

    for old in out.glob("segformer.onnx.part*"):
        old.unlink()
    parts = []
    for i in range(0, len(data), PART):
        name = f"segformer.onnx.part{len(parts)}"
        (out / name).write_bytes(data[i:i + PART])
        parts.append(name)
    (out / "parts.json").write_text(json.dumps({"parts": parts, "bytes": len(data),
                                                "sha256": hashlib.sha256(data).hexdigest()[:16]}, indent=1))
    full.unlink()
    print(f"{len(parts)} parts in {out}")


if __name__ == "__main__":
    main()
