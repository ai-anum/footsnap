/* FootSnap in the browser: segments a wound photo on the viewer's own device, no server.
 *
 * The page (app.html) uses window.FootSnapLocal instead of the analysis server when no server
 * address is set. The model is web/model/segformer.onnx (export_onnx.py): SegFormer-B5, colour only,
 * RGB 0..255 in, wound probability out. It is downloaded once (~170 MB, in parts) and kept in the
 * browser's Cache Storage, then run with ONNX Runtime Web on the GPU (WebGPU) or the CPU (WASM).
 *
 * The outputs match server/pipeline/analyse.py (photo resized to 640 px, threshold 0.5, the same
 * measurements); there is no depth model in the browser, so new photos have no maps or 3D.
 */
(function () {
  'use strict';
  var ORT_VERSION = '1.22.0';
  var ORT_BASE = 'https://cdn.jsdelivr.net/npm/onnxruntime-web@' + ORT_VERSION + '/dist/';
  var MODEL_DIR = 'model/';
  var WORK_SIZE = 640, THRESHOLD = 0.5, WOUND = [255, 77, 109];

  var session = null, loading = null, backend = '';

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script'); s.src = src; s.crossOrigin = 'anonymous';
      s.onload = resolve; s.onerror = function () { reject(new Error('couldn’t load ONNX Runtime (' + src + ')')); };
      document.head.appendChild(s);
    });
  }

  /* The model parts, from Cache Storage when they were downloaded before. */
  async function modelBytes(progress) {
    var info = await (await fetch(MODEL_DIR + 'parts.json', { cache: 'no-cache' })).json();
    var cacheName = 'footsnap-model-' + info.sha256, cache = null;
    try { cache = await caches.open(cacheName); } catch (e) { /* private mode: download every time */ }
    try {                                                   // drop older model versions
      (await caches.keys()).forEach(function (k) { if (k.indexOf('footsnap-model-') === 0 && k !== cacheName) caches.delete(k); });
    } catch (e) {}
    var out = new Uint8Array(info.bytes), offset = 0, done = 0;
    for (var i = 0; i < info.parts.length; i++) {
      var url = MODEL_DIR + info.parts[i], res = cache && await cache.match(url);
      var fromCache = !!res;
      if (!res) {
        res = await fetch(url);
        if (!res.ok) throw new Error('model download failed (' + res.status + ')');
        if (cache) { try { await cache.put(url, res.clone()); } catch (e) {} }
      }
      var buf = new Uint8Array(await res.arrayBuffer());
      out.set(buf, offset); offset += buf.length; done += buf.length;
      if (!fromCache) progress('Downloading the model, once: ' + Math.round(done / info.bytes * 100) + '% of ' + Math.round(info.bytes / 1e6) + ' MB');
    }
    if (offset !== info.bytes) throw new Error('the model download is incomplete');
    return out;
  }

  async function getSession(progress) {
    if (session) return session;
    if (loading) return loading;
    loading = (async function () {
      progress('Loading the model…');
      if (!window.ort) await loadScript(ORT_BASE + 'ort.webgpu.min.js');
      ort.env.wasm.wasmPaths = ORT_BASE;
      var bytes = await modelBytes(progress);
      progress('Starting the model…');
      var tries = navigator.gpu ? [['webgpu'], ['wasm']] : [['wasm']];
      var last;
      for (var i = 0; i < tries.length; i++) {
        try {
          session = await ort.InferenceSession.create(bytes, { executionProviders: tries[i], graphOptimizationLevel: 'all' });
          backend = tries[i][0] === 'webgpu' ? 'ONNX Runtime Web (GPU)' : 'ONNX Runtime Web (CPU)';
          return session;
        } catch (e) { last = e; }
      }
      throw last;
    })();
    try { return await loading; } finally { loading = null; }
  }

  /* ---------- photo in ---------- */

  async function readPhoto(file) {
    var bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    var s = WORK_SIZE / Math.max(bmp.width, bmp.height);
    var w = Math.max(1, Math.round(bmp.width * s)), h = Math.max(1, Math.round(bmp.height * s));
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var g = c.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(bmp, 0, 0, w, h);
    return { canvas: c, w: w, h: h, rgba: g.getImageData(0, 0, w, h).data, original: [bmp.width, bmp.height] };
  }

  async function probability(sess, img) {
    var n = img.w * img.h, x = new Float32Array(3 * n), d = img.rgba;
    for (var i = 0; i < n; i++) { x[i] = d[4 * i]; x[n + i] = d[4 * i + 1]; x[2 * n + i] = d[4 * i + 2]; }
    var feeds = { image: new ort.Tensor('float32', x, [1, 3, img.h, img.w]) };
    var out = await sess.run(feeds);
    return out.probability.data;
  }

  /* ---------- measurements (as analyse.measurements, without depth) ---------- */

  var DX = [-1, -1, 0, 1, 1, 1, 0, -1], DY = [0, -1, -1, -1, 0, 1, 1, 1];   // W NW N NE E SE S SW (clockwise)

  /* Outer boundary of each 8-connected region, traced pixel by pixel (Moore neighbour tracing),
     like cv2.findContours(RETR_EXTERNAL, CHAIN_APPROX_NONE). */
  function contours(mask, w, h) {
    var seen = new Uint8Array(w * h), out = [];
    var at = function (x, y) { return x >= 0 && y >= 0 && x < w && y < h && mask[y * w + x]; };
    for (var i = 0; i < w * h; i++) {
      if (!mask[i] || seen[i]) continue;
      var stack = [i]; seen[i] = 1;                     // flood the region so it is traced once
      while (stack.length) {
        var p = stack.pop(), px = p % w, py = (p - px) / w;
        for (var k = 0; k < 8; k++) {
          var qx = px + DX[k], qy = py + DY[k];
          if (at(qx, qy) && !seen[qy * w + qx]) { seen[qy * w + qx] = 1; stack.push(qy * w + qx); }
        }
      }
      var sx = i % w, sy = (i - sx) / w, pts = [[sx, sy]];
      // `back` = direction from the current pixel to the last background pixel checked; the start
      // pixel is the region's first in raster order, so its west neighbour is background
      var cx = sx, cy = sy, back = 0, guard = 0;
      for (;;) {
        var found = -1;
        for (var j = 1; j <= 8; j++) { var kk = (back + j) % 8; if (at(cx + DX[kk], cy + DY[kk])) { found = kk; break; } }
        if (found < 0) break;                           // a single pixel
        var nx = cx + DX[found], ny = cy + DY[found];
        // stop when leaving the start pixel the same way as the first time
        if (cx === sx && cy === sy && pts.length > 1 && nx === pts[1][0] && ny === pts[1][1]) break;
        var bx = cx + DX[(found + 7) % 8], by = cy + DY[(found + 7) % 8];
        for (var b = 0; b < 8; b++) if (nx + DX[b] === bx && ny + DY[b] === by) { back = b; break; }
        cx = nx; cy = ny;
        if (++guard > 4 * w * h) break;
        if (cx !== sx || cy !== sy) pts.push([cx, cy]);
      }
      out.push(pts);
    }
    return out;
  }

  function arcLength(p) {
    var t = 0;
    for (var i = 0; i < p.length; i++) { var a = p[i], b = p[(i + 1) % p.length]; t += Math.hypot(b[0] - a[0], b[1] - a[1]); }
    return t;
  }
  function polyArea(p) {
    var s = 0;
    for (var i = 0; i < p.length; i++) { var a = p[i], b = p[(i + 1) % p.length]; s += a[0] * b[1] - b[0] * a[1]; }
    return Math.abs(s) / 2;
  }
  function hull(points) {
    var p = points.slice().sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
    if (p.length < 3) return p;
    var cross = function (o, a, b) { return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]); };
    var lo = [], up = [];
    p.forEach(function (q) { while (lo.length >= 2 && cross(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); });
    p.slice().reverse().forEach(function (q) { while (up.length >= 2 && cross(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); });
    return lo.slice(0, -1).concat(up.slice(0, -1));
  }
  /* sides of the smallest rotated rectangle around the points (cv2.minAreaRect) */
  function minAreaRect(points) {
    var hp = hull(points), best = [Infinity, 0, 0];
    for (var i = 0; i < hp.length; i++) {
      var a = hp[i], b = hp[(i + 1) % hp.length], len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (len < 1e-9) continue;
      var ux = (b[0] - a[0]) / len, uy = (b[1] - a[1]) / len, u0 = Infinity, u1 = -Infinity, v0 = Infinity, v1 = -Infinity;
      hp.forEach(function (q) {
        var u = q[0] * ux + q[1] * uy, v = -q[0] * uy + q[1] * ux;
        u0 = Math.min(u0, u); u1 = Math.max(u1, u); v0 = Math.min(v0, v); v1 = Math.max(v1, v);
      });
      if ((u1 - u0) * (v1 - v0) < best[0]) best = [(u1 - u0) * (v1 - v0), u1 - u0, v1 - v0];
    }
    return [best[1], best[2]];
  }
  var r1 = function (v) { return Math.round(v * 10) / 10; };

  function measurements(mask, prob, w, h) {
    var area = 0, conf = 0, x0 = w, y0 = h, x1 = 0, y1 = 0;
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
      var i = y * w + x; if (!mask[i]) continue;
      area++; conf += prob[i];
      if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
    }
    var cs = contours(mask, w, h);
    var out = { wound_pixels: area, image_pixels: w * h, wound_percent: Math.round(10000 * area / (w * h)) / 100, regions: cs.length };
    if (!area) return out;
    out.bbox = [x0, y0, x1, y1];
    out.mean_confidence = Math.round(conf / area * 1000) / 1000;
    out.perimeter_pixels = r1(cs.reduce(function (t, c) { return t + arcLength(c); }, 0));
    var big = cs.reduce(function (a, c) { return polyArea(c) > polyArea(a) ? c : a; }, cs[0]);
    if (big.length >= 5) { var s = minAreaRect(big); out.length_pixels = r1(Math.max(s[0], s[1])); out.width_pixels = r1(Math.min(s[0], s[1])); }
    return out;
  }

  /* ---------- pictures out ---------- */

  function toBlob(canvas, type, q) { return new Promise(function (r) { canvas.toBlob(r, type, q); }); }

  async function maskPNG(mask, w, h) {
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var g = c.getContext('2d'), im = g.createImageData(w, h), d = im.data;
    for (var i = 0; i < w * h; i++) { var v = mask[i] ? 255 : 0; d[4 * i] = d[4 * i + 1] = d[4 * i + 2] = v; d[4 * i + 3] = 255; }
    g.putImageData(im, 0, 0);
    return toBlob(c, 'image/png');
  }

  /* ---------- the analysis the app calls ---------- */

  async function analyse(file, step) {
    step = step || function () {};
    var t0 = performance.now(), timings = {};
    step('preparing', 'Preparing the photo…');
    var sess = await getSession(function (text) { step('preparing', text); });
    var img = await readPhoto(file);
    timings.prepare = Math.round(performance.now() - t0) / 1000;
    step('segmenting', 'Finding the wound boundary…');
    t0 = performance.now();
    var prob = await probability(sess, img);
    var mask = new Uint8Array(img.w * img.h);
    for (var i = 0; i < mask.length; i++) mask[i] = prob[i] > THRESHOLD ? 1 : 0;
    timings.segmentation = Math.round(performance.now() - t0) / 1000;

    var urls = {
      'photo.jpg': URL.createObjectURL(await toBlob(img.canvas, 'image/jpeg', 0.92)),
      'mask.png': URL.createObjectURL(await maskPNG(mask, img.w, img.h))
    };
    var m = measurements(mask, prob, img.w, img.h);
    var notes = ['Segmented in this browser (' + backend + '). The wound was found from colour only; there is no depth model in the browser, so no depth maps or 3D surface.'];
    if (!m.wound_pixels) notes.push('No wound was found in this photo.');
    return {
      urls: urls,
      result: {
        size: [img.w, img.h], original_size: img.original, measurements: m,
        files: { photo: 'photo.jpg', mask: 'mask.png' }, notes: notes, timings: timings,
        model: { backend: backend, threshold: THRESHOLD, channels: ['R', 'G', 'B', 'curv_mean', 'shape_index'], curvature_used: false }
      }
    };
  }

  window.FootSnapLocal = {
    health: { ok: true, segmentation: 'this browser', marigold: false, curvature_stats: false, token_required: false, in_browser: true },
    analyse: analyse,
    _measurements: measurements      // for tests
  };
})();
