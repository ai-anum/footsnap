"""Build the public FootSnap web app: a folder of static files any web host can serve.

    python web/export_onnx.py          # once (or after retraining): web/model/
    python web/build_web.py            # -> web/dist/

Open web/dist/ on GitHub Pages, Netlify, Cloudflare Pages or any static host (it must be served
over https: browsers only allow the camera, WebGPU and the model cache there). No server is
needed: photos are segmented in the viewer's browser by web/footsnap-browser.js, and the image
gallery (app/demo/) carries its own precomputed maps and 3D.

To try it on this computer:  cd web/dist && python3 -m http.server 8080  ->  http://localhost:8080
"""
import os
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP, WEB = ROOT / "app", ROOT / "web"
DIST = WEB / "dist"


def page():
    """index.html: the skeleton server.py serves, plus the in-browser analysis."""
    server = (ROOT / "server" / "server.py").read_text(encoding="utf-8")
    skeleton = re.search(r'PAGE = """(.*?)"""', server, re.S).group(1)
    skeleton = skeleton.replace("<title>FootSnap</title>",
                                '<title>FootSnap</title>\n<script src="footsnap-browser.js"></script>')
    return skeleton.replace("{{APP}}", (APP / "app.html").read_text(encoding="utf-8"))


def link_or_copy(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(src, dst)            # the model parts are big: share them instead of copying
    except OSError:
        shutil.copy2(src, dst)


def main():
    parts = sorted((WEB / "model").glob("segformer.onnx.part*"))
    if not parts or not (WEB / "model" / "parts.json").is_file():
        raise SystemExit("run web/export_onnx.py first (web/model/ is empty)")
    shutil.rmtree(DIST, ignore_errors=True)
    shutil.copytree(APP, DIST, ignore=shutil.ignore_patterns(".DS_Store", "app.html"))
    (DIST / "index.html").write_text(page(), encoding="utf-8")
    shutil.copy2(WEB / "footsnap-browser.js", DIST / "footsnap-browser.js")
    for p in parts + [WEB / "model" / "parts.json"]:
        link_or_copy(p, DIST / "model" / p.name)
    (DIST / ".nojekyll").write_text("")          # GitHub Pages: serve files as they are
    size = sum(f.stat().st_size for f in DIST.rglob("*") if f.is_file())
    print(f"built {DIST} ({size / 1e6:.0f} MB, {sum(1 for f in DIST.rglob('*') if f.is_file())} files)")


if __name__ == "__main__":
    main()
