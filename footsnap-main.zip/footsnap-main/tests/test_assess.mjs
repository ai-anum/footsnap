// Checks for the assessment logic in app/assess.js (sizes, classification, answer checks).
//
//   node tests/test_assess.mjs
//
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

globalThis.window = {};
new Function(readFileSync(new URL('../app/assess.js', import.meta.url), 'utf8'))();
const A = window.FootSnapAssess;
const test = (name, fn) => { fn(); console.log('ok ', name); };

test('sizes from the AireForms example (3.5 x 2.5 x 1.4 cm)', () => {
  const s = A.measure(null, {}, { size_length: 3.5, size_width: 2.5, size_depth: 1.4 });
  assert.equal(s.volume.value, 6.4);          // ellipsoid; the old L x W x D box gave 12.25
  assert.equal(s.perimeter.value, 9.5);       // ellipse; the form recorded 12
  assert.equal(s.area.value, 6.9);
});

test('length and width marked on the photo use the ruler scale', () => {
  const marks = { scale: { pxPerCm: 30 }, length: [[100, 100], [205, 100]], width: [[150, 60], [150, 135]] };
  const s = A.measure({ length: 108, width: 86, area: 7067, perimeter: 325 }, marks, {});
  assert.deepEqual([s.length.value, s.length.source], [3.5, 'photo']);
  assert.deepEqual([s.width.value, s.width.source], [2.5, 'photo']);
  assert.deepEqual([s.area.value, s.area.source], [7.9, 'footsnap']);     // traced outline
  assert.equal(A.crossAngle(marks), 90);
});

test('a typed size replaces the measured one', () => {
  const s = A.measure(null, { scale: { pxPerCm: 30 }, length: [[0, 0], [90, 0]] }, { size_length: 4 });
  assert.deepEqual([s.length.value, s.length.source], [4, 'clinician']);
});

test('University of Texas and Wagner', () => {
  const c = (v) => { const r = A.classify(v); return [r.ut && r.ut.code, r.wagner && r.wagner.code]; };
  assert.deepEqual(c({ reach: 'Skin only', infection: ['None'], ischaemia: 'No', gangrene: 'None' }), ['UT 1A', 'Wagner 1']);
  assert.deepEqual(c({ reach: 'Skin only', infection: ['Swelling'], ischaemia: 'Yes', gangrene: 'None' }), ['UT 1D', 'Wagner 1']);
  assert.deepEqual(c({ reach: 'Tendon or capsule', infection: ['None'], ischaemia: 'No', gangrene: 'None', abscess: 'Yes' }), ['UT 2A', 'Wagner 3']);
  assert.deepEqual(c({ reach: 'Bone or joint', infection: ['Warmth'], ischaemia: 'No', gangrene: 'Forefoot' }), ['UT 3B', 'Wagner 4']);
  assert.ok(A.classify({ reach: 'Skin only' }).missing.length > 0);       // never guesses missing answers
});

test('contradicting answers are flagged', () => {
  const issues = A.checks({ exudate_type: 'Purulent', infection: ['None'], healing: 'Healed' }, { woundFound: true });
  assert.equal(issues.length, 2);
  const skew = A.checks({}, { marks: { length: [[0, 0], [100, 0]], width: [[50, 0], [90, 40]] } });
  assert.match(skew[0], /right angles/);
});
