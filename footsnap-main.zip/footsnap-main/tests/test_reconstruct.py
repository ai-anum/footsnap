"""Checks for the 3D reconstruction and the mesh files the app reads.

    python -m pytest tests          (or: python tests/test_reconstruct.py)

Uses a synthetic depth map (a gentle cone), so no photos, model or GPU are needed.
"""
import base64
import json
import struct
import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))
from pipeline import reconstruct as R  # noqa: E402


def bowl(h=48, w=64):
    y, x = np.mgrid[0:h, 0:w]
    return np.hypot(x - w / 2, y - h / 2).astype(np.float32)              # a gentle cone: deeper towards the edges


def test_surface_grid():
    depth = bowl()
    colours = np.full((*depth.shape, 3), 200, np.uint8)
    verts, cols, faces, pix = R.surface(depth, colours)
    h, w = depth.shape
    assert len(verts) == (h - 2) * (w - 2)                 # every pixel except the 1-px border
    assert len(faces) == 2 * (h - 3) * (w - 3)             # smooth surface: no squares cut
    assert faces.max() < len(verts)
    assert (verts[:, 2] < 0).all()                         # camera looks down -z
    z = -verts[:, 2]
    assert np.isclose(z.min(), 1, atol=0.05) and np.isclose(z.max(), np.e, atol=0.05)   # z = exp(t), t in 0..1


def test_depth_edge_is_cut():
    depth = bowl()
    depth[:, 32:] += 1e6                                    # a cliff down the middle
    _, _, faces, pix = R.surface(depth, np.zeros((*depth.shape, 3), np.uint8))
    crossing = (pix[faces][:, :, 0] < 32).any(1) & (pix[faces][:, :, 0] >= 32).any(1)
    assert not crossing.any()


def test_closeup_keeps_the_wound():
    depth = bowl()
    mask = np.zeros(depth.shape, bool)
    mask[20:28, 28:36] = True
    verts, cols, faces, pix = R.surface(depth, np.zeros((*depth.shape, 3), np.uint8))
    part = R.closeup(verts, cols, faces, pix, mask, margin=0.3)      # small image: keep the box inside it
    assert part is not None and len(part[2]) < len(faces)
    u, v = part[3][:, 0], part[3][:, 1]
    assert mask[v, u].any()


def test_glb_is_valid():
    verts, cols, faces, _ = R.surface(bowl(), np.full((48, 64, 3), 128, np.uint8))
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "mesh.glb"
        R.write_glb(path, verts, cols, faces)
        data = path.read_bytes()
    magic, version, total = struct.unpack("<III", data[:12])
    assert magic == 0x46546C67 and version == 2 and total == len(data)
    length, kind = struct.unpack("<II", data[12:20])
    gltf = json.loads(data[20:20 + length])
    assert gltf["accessors"][0]["count"] == len(verts)
    assert gltf["accessors"][2]["count"] == faces.size


def test_viewer_mesh_round_trip():
    verts, cols, faces, _ = R.surface(bowl(), np.full((48, 64, 3), 90, np.uint8))
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "viewer.json"
        R.write_viewer_mesh(path, verts, cols, faces, extra={"depth": cols})
        j = json.loads(path.read_text())
    pos = np.frombuffer(base64.b64decode(j["p"]), np.int16).reshape(-1, 3) * j["scale"]
    assert len(pos) == j["n"] == len(verts)
    assert np.isclose(max(np.ptp(pos[:, 0]), np.ptp(pos[:, 1])), 2, atol=1e-3)     # wider side spans 2
    assert len(base64.b64decode(j["c_depth"])) == len(verts) * 3


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok ", name)
