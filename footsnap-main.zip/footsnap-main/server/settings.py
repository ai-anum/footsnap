"""Server settings. Edit here or override with environment variables of the same name.

Point these at the research project (config.PROJECT) so the app uses the same files:
    MODEL_PATH          runs/segformer_curvature_seed0/model.pt (5 input channels: RGB + curvature)
    STATS_JSON          features/stats.json  (curvature mean/std and normal-axis signs, from training)
    MARIGOLD_CODE       marigold-v2 folder (the one with scripts/infer.py)
    MARIGOLD_PYTHON     python of the environment Marigold runs in
    MARIGOLD_MAPS       optional: folders of precomputed maps (marigold/maps/<split>),
                        separated by ';' on Windows and ':' on Linux/macOS (os.pathsep)

On Windows set them in the Anaconda Prompt with  set NAME=value  (no quotes, no spaces around =),
or edit start_server.bat.
"""
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = os.environ.get("PROJECT", "/home/staff/fatimafa/Documents/Anum/Experiments/0003-Depth_Segmentation")
SEP = os.pathsep                # ';' on Windows, so drive letters such as C:\ are not split apart


def _get(name, default):
    return os.environ.get(name, default)


MODEL_PATH = _get("MODEL_PATH", str(HERE / "model.pt"))
STATS_JSON = _get("STATS_JSON", f"{PROJECT}/features/stats.json")
MARIGOLD_CODE = _get("MARIGOLD_CODE", f"{PROJECT}/marigold-v2")
MARIGOLD_PYTHON = _get("MARIGOLD_PYTHON", sys.executable or "python")   # default: this same conda env
MARIGOLD_MAPS = [p.strip() for p in _get("MARIGOLD_MAPS", f"{PROJECT}/marigold/maps/test{SEP}{PROJECT}/marigold/maps/train").split(SEP) if p.strip()]

CASES_DIR = Path(_get("CASES_DIR", str(HERE / "cases")))      # one folder per analysed photo
APP_DIR = Path(_get("APP_DIR", str(HERE.parent / "app")))       # the mobile web app
WORK_SIZE = int(_get("WORK_SIZE", "640"))      # long side in pixels; DFUC2022 photos are 640x480
THRESHOLD = float(_get("THRESHOLD", "0.5"))    # as in test.py
DEPTH_STRENGTH = float(_get("DEPTH_STRENGTH", "1.0"))
CLOSEUP_MARGIN = float(_get("CLOSEUP_MARGIN", "1.0"))
ACCESS_TOKEN = _get("ACCESS_TOKEN", "")        # if set, the app must send it (Authorization: Bearer ...)
HOST = _get("HOST", "0.0.0.0")
PORT = int(_get("PORT", "8000"))
