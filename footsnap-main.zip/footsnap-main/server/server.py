"""FootSnap server: serves the clinician app and runs the analysis.

    python server.py                      # http://<this machine>:8000 on the phone

API
    GET    /api/health                 what is set up (model backend, Marigold, stats.json)
    POST   /api/cases                  multipart field "image" -> {"id", "status"}
    GET    /api/cases/<id>             status while running, full result when done
    GET    /api/cases/<id>/<file>      pictures and meshes listed in result["files"]
    GET    /api/cases                  recent cases
    POST   /api/cases/<id>/sample      save an analysed photo to the sample library {label, note}
    DELETE /api/samples/<id>           remove a sample
    GET    /api/cases/<id>/assessment  the saved assessment (or null)
    PUT    /api/cases/<id>/assessment  save the assessment {values, scale}
    DELETE /api/cases/<id>             remove a case and its files
"""
import json
import queue
import shutil
import threading
import time
import traceback
import uuid
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_from_directory

import settings as cfg
from pipeline.analyse import analyse
from pipeline.marigold import Marigold
from pipeline.segment import Segmenter
from build_samples import COPY as SAMPLE_FILES, LIB as SAMPLE_DIR, read_index, thumbnail, write_index

app = Flask(__name__, static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024
cfg.CASES_DIR.mkdir(parents=True, exist_ok=True)

print(f"Loading {cfg.MODEL_PATH} ...")
segmenter = Segmenter(cfg.MODEL_PATH)
print(f"  segmentation backend: {segmenter.backend}, {segmenter.in_channels} input channels")
stats = json.loads(Path(cfg.STATS_JSON).read_text(encoding="utf-8")) if Path(cfg.STATS_JSON).is_file() else None
print(f"  curvature stats: {'found' if stats else 'NOT found - colour only'} ({cfg.STATS_JSON})")
marigold = Marigold(cfg.MARIGOLD_CODE, cfg.MARIGOLD_PYTHON, cfg.MARIGOLD_MAPS)
print(f"  Marigold: {'ready' if marigold.available else 'NOT found'} ({cfg.MARIGOLD_CODE})")

jobs = {}                      # id -> {"status", "step", ...}
work = queue.Queue()           # one photo at a time: the GPU is shared


def worker():
    while True:
        case_id, photo = work.get()
        job = jobs[case_id]
        job["status"] = "running"
        try:
            def progress(step):
                job["step"] = step
            result = analyse(photo, cfg.CASES_DIR / case_id, segmenter, marigold, stats, cfg, progress)
            job.update(status="done", step="done", result=result)
        except Exception as e:                    # report, keep serving
            traceback.print_exc()
            job.update(status="failed", error=str(e))
            (cfg.CASES_DIR / case_id / "error.txt").write_text(traceback.format_exc(), encoding="utf-8")


threading.Thread(target=worker, daemon=True).start()


def valid_id(case_id):
    try:
        return str(uuid.UUID(case_id)) == case_id
    except ValueError:
        return False


@app.before_request
def check_token():
    if cfg.ACCESS_TOKEN and request.path.startswith("/api/") and request.path != "/api/health":
        token = request.headers.get("Authorization", "").removeprefix("Bearer ") or request.args.get("token", "")
        if token != cfg.ACCESS_TOKEN:
            abort(401)


@app.after_request
def headers(resp):
    resp.headers["Cache-Control"] = "no-store" if request.path.startswith("/api/") else "no-cache"
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    return resp


@app.get("/api/health")
def health():
    return jsonify(ok=True, segmentation=segmenter.backend, marigold=marigold.available,
                   precomputed_maps=[str(p) for p in marigold.maps_dirs if p.is_dir()],
                   curvature_stats=stats is not None, token_required=bool(cfg.ACCESS_TOKEN),
                   queue=work.qsize())


@app.route("/api/cases", methods=["POST", "OPTIONS"])
def create_case():
    if request.method == "OPTIONS":
        return "", 204
    f = request.files.get("image")
    if not f or not f.filename:
        abort(400, "send the photo in the 'image' field")
    case_id = str(uuid.uuid4())
    folder = cfg.CASES_DIR / case_id
    folder.mkdir(parents=True)
    suffix = Path(f.filename).suffix.lower() if Path(f.filename).suffix.lower() in {
        ".jpg", ".jpeg", ".png", ".heic", ".webp", ".bmp", ".tif", ".tiff"} else ".jpg"
    # keep the original name's stem so precomputed DFUC maps (e.g. 200001.npz) are found
    stem = "".join(ch for ch in Path(f.filename).stem if ch.isalnum() or ch in "-_")[:64] or "photo"
    photo = folder / f"{stem}{suffix}"
    f.save(photo)
    meta = {"id": case_id, "created": time.time(), "label": request.form.get("label", "")[:80],
            "filename": f.filename[:120]}
    (folder / "meta.json").write_text(json.dumps(meta), encoding="utf-8")
    jobs[case_id] = {**meta, "status": "queued", "step": "queued"}
    work.put((case_id, photo))
    return jsonify(id=case_id, status="queued"), 202


@app.get("/api/cases/<case_id>")
def get_case(case_id):
    if not valid_id(case_id):
        abort(404)
    if case_id in jobs:
        return jsonify(jobs[case_id])
    folder = cfg.CASES_DIR / case_id
    if (folder / "result.json").is_file():          # finished before a restart
        meta = json.loads((folder / "meta.json").read_text(encoding="utf-8"))
        return jsonify(**meta, status="done", step="done", result=json.loads((folder / "result.json").read_text(encoding="utf-8")))
    abort(404)


@app.get("/api/cases")
def list_cases():
    rows = []
    for folder in cfg.CASES_DIR.iterdir():
        if (folder / "meta.json").is_file():
            meta = json.loads((folder / "meta.json").read_text(encoding="utf-8"))
            meta["status"] = jobs.get(meta["id"], {}).get("status") or (
                "done" if (folder / "result.json").is_file() else "failed")
            rows.append(meta)
    rows.sort(key=lambda r: r["created"], reverse=True)
    return jsonify(rows[:50])


@app.delete("/api/cases/<case_id>")
def delete_case(case_id):
    if not valid_id(case_id):
        abort(404)
    shutil.rmtree(cfg.CASES_DIR / case_id, ignore_errors=True)
    jobs.pop(case_id, None)
    return "", 204


@app.route("/api/cases/<case_id>/assessment", methods=["GET", "PUT", "OPTIONS"])
def assessment(case_id):
    """The clinician's assessment for a case, saved as assessment.json beside its results."""
    if request.method == "OPTIONS":
        return "", 204
    folder = cfg.CASES_DIR / case_id
    if not valid_id(case_id) or not (folder / "meta.json").is_file():
        abort(404)
    path = folder / "assessment.json"
    if request.method == "GET":
        return jsonify(assessment=json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None)
    if (request.content_length or 0) > 256 * 1024:
        abort(413)
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not isinstance(body.get("values"), dict):
        abort(400, "send {values: {...}, scale: {...}}")
    body["saved_at"] = time.time()
    path.write_text(json.dumps(body, indent=1), encoding="utf-8")
    return jsonify(ok=True)


@app.get("/api/cases/<case_id>/<name>")
def case_file(case_id, name):
    allowed = {"photo.jpg", "overlay.jpg", "mask.png", "mask_layer.png", "confidence.png", "depth.png",
               "mesh.glb", "closeup.glb", "mesh.ply", "closeup.ply", "depth.npy",
               "viewer_full.json", "viewer_closeup.json", "albedo.jpg", "normals.jpg", "depth.jpg"}
    if not valid_id(case_id) or name not in allowed:
        abort(404)
    as_file = name.endswith((".ply", ".npy"))
    return send_from_directory(cfg.CASES_DIR / case_id, name, as_attachment=as_file,
                               mimetype="model/gltf-binary" if name.endswith(".glb") else None)


# ---------------- sample library (the app's "Choose a sample image") ----------------
SAMPLE_LOCK = threading.Lock()


def sample_id_for(name, taken):
    """A short, safe folder name from the photo's file name, unique in the library."""
    base = "".join(ch for ch in Path(name).stem if ch.isalnum() or ch in "-_")[:40] or "sample"
    sid, n = base, 2
    while sid in taken:
        sid, n = f"{base}-{n}", n + 1
    return sid


@app.route("/api/cases/<case_id>/sample", methods=["POST", "OPTIONS"])
def save_sample(case_id):
    """Copy an analysed photo and its results into the sample library (same layout as
    build_samples.py), so it can be chosen again later as a sample image."""
    if request.method == "OPTIONS":
        return "", 204
    folder = cfg.CASES_DIR / case_id
    if not valid_id(case_id) or not (folder / "result.json").is_file():
        abort(404, "analyse the photo first")
    body = request.get_json(silent=True) or {}
    result = json.loads((folder / "result.json").read_text(encoding="utf-8"))
    meta = json.loads((folder / "meta.json").read_text(encoding="utf-8"))
    with SAMPLE_LOCK:
        index = read_index()
        sid = sample_id_for(meta.get("filename") or case_id, {s["id"] for s in index["samples"]})
        out = SAMPLE_DIR / sid
        out.mkdir(parents=True)
        for name in SAMPLE_FILES:
            if (folder / name).is_file():
                shutil.copy(folder / name, out / name)
        result["files"] = {k: v for k, v in result["files"].items() if v in SAMPLE_FILES}
        result["notes"] = [f"Saved from FootSnap on {time.strftime('%d %b %Y')}. Outputs from the same pipeline as live photos."] + result.get("notes", [])
        (out / "result.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
        thumbnail(out / "photo.jpg", out / "thumb.jpg")
        entry = {"id": sid, "label": str(body.get("label") or f"Case {sid}")[:80], "note": str(body.get("note") or "")[:200],
                 "outputs": True, "photo": f"{sid}/photo.jpg", "thumb": f"{sid}/thumb.jpg", "result": f"{sid}/result.json",
                 "wound_found": result["measurements"]["wound_pixels"] > 0, "saved_from": case_id}
        index["samples"].append(entry)
        write_index(index)
    return jsonify(sample=entry), 201


@app.route("/api/samples/<sample_id>", methods=["DELETE", "OPTIONS"])
def delete_sample(sample_id):
    if request.method == "OPTIONS":
        return "", 204
    with SAMPLE_LOCK:
        index = read_index()
        if sample_id not in {s["id"] for s in index["samples"]}:
            abort(404)
        index["samples"] = [s for s in index["samples"] if s["id"] != sample_id]
        write_index(index)
        shutil.rmtree(SAMPLE_DIR / sample_id, ignore_errors=True)   # only ids listed in samples.json are removed
    return "", 204


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#14284B"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="FootSnap"><meta name="apple-mobile-web-app-status-bar-style" content="default"><meta name="format-detection" content="telephone=no">
<link rel="manifest" href="manifest.webmanifest"><link rel="icon" href="icon-192.png"><link rel="apple-touch-icon" href="apple-touch-icon.png">
<title>FootSnap</title>
<style>:root{padding-top:env(safe-area-inset-top,0px)}
body{margin:0}img{max-width:100%}[hidden]{display:none!important}</style>
</head><body>
{{APP}}
</body></html>"""


@app.get("/")
def index():
    return PAGE.replace("{{APP}}", (cfg.APP_DIR / "app.html").read_text(encoding="utf-8"))


@app.get("/<path:path>")
def static_app(path):
    if path.startswith("api/") or not (cfg.APP_DIR / path).is_file():
        abort(404)
    return send_from_directory(cfg.APP_DIR, path)


if __name__ == "__main__":
    print(f"\nOpen http://<this computer's address>:{cfg.PORT} on the phone (same network)\n")
    app.run(host=cfg.HOST, port=cfg.PORT, threaded=True)
