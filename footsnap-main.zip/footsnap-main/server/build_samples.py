"""Fill the app's sample image library (app/demo/).

Every sample is built by the SAME pipeline the server runs on a live photo, so what the
app shows as "Sample outputs" is exactly what the model produces for that image.

    # full samples (outputs included) from the DFUC2022 test set
    python build_samples.py --images $PROJECT/datasets/dfuc2022/test/images \
        --reference $PROJECT/datasets/dfuc2022/test/masks \
        --ids 200001 200528 200745

    # labels and notes for the gallery (CSV with columns: id,label,note)
    python build_samples.py --images ... --ids ... --labels samples.csv

    # photos only: stored in the app, segmented live by the server when chosen
    python build_samples.py --images /path/to/photos --ids 300001 300002 --photos-only

    python build_samples.py --list              # what is in the library
    python build_samples.py --remove 200745     # take one out

Writes app/demo/<id>/ and keeps app/demo/samples.json in step. Uses settings.py for the model,
features/stats.json and Marigold (or your saved marigold/maps/<split>/<id>.npz).
"""
import argparse
import csv
import json
import shutil
import sys
import tempfile
from pathlib import Path

import cv2
import numpy as np

import settings as cfg

LIB = cfg.APP_DIR / "demo"
INDEX = LIB / "samples.json"
IMAGE_TYPES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp", ".heic"}
COPY = ["photo.jpg", "mask.png", "albedo.jpg", "depth.jpg", "normals.jpg", "viewer_closeup.json", "viewer_full.json"]


def read_index():
    if INDEX.is_file():
        return json.loads(INDEX.read_text(encoding="utf-8"))
    return {"version": 1, "samples": []}


def write_index(index):
    LIB.mkdir(parents=True, exist_ok=True)
    INDEX.write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")


def find(folder, stem):
    for p in Path(folder).iterdir():
        if p.stem == stem and p.suffix.lower() in IMAGE_TYPES:
            return p
    return None


def thumbnail(src, dst, width=560):     # sharp as a square tile in the 3-column picker
    img = cv2.imread(str(src))
    h, w = img.shape[:2]
    img = cv2.resize(img, (width, round(h * width / w)), interpolation=cv2.INTER_AREA)
    cv2.imwrite(str(dst), img, [cv2.IMWRITE_JPEG_QUALITY, 82])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--images", help="folder with the photos")
    ap.add_argument("--ids", nargs="+", help="image names without extension")
    ap.add_argument("--reference", help="folder of reference masks (white = wound), e.g. the DFUC2022 masks")
    ap.add_argument("--labels", help="CSV with id,label,note")
    ap.add_argument("--photos-only", action="store_true", help="store the photo only; the server segments it live")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--remove", nargs="+")
    args = ap.parse_args()

    index = read_index()
    by_id = {s["id"]: s for s in index["samples"]}

    if args.list:
        for s in index["samples"]:
            print(f"{s['id']:>10}  {'outputs' if s['outputs'] else 'photo only':10}  {s['label']}")
        return
    if args.remove:
        for i in args.remove:
            shutil.rmtree(LIB / i, ignore_errors=True)
            by_id.pop(i, None)
        index["samples"] = [s for s in index["samples"] if s["id"] in by_id]
        write_index(index)
        print(f"Removed {args.remove}")
        return
    if not args.images or not args.ids:
        ap.error("give --images and --ids (or --list / --remove)")

    labels = {}
    if args.labels:
        with open(args.labels, newline="", encoding="utf-8") as fh:
            labels = {r["id"]: r for r in csv.DictReader(fh)}

    segmenter = marigold = stats = None
    if not args.photos_only:
        from pipeline.analyse import analyse
        from pipeline.marigold import Marigold
        from pipeline.segment import Segmenter
        print(f"Loading {cfg.MODEL_PATH}")
        segmenter = Segmenter(cfg.MODEL_PATH)
        stats = json.loads(Path(cfg.STATS_JSON).read_text(encoding="utf-8")) if Path(cfg.STATS_JSON).is_file() else None
        if stats is None:
            print(f"  warning: {cfg.STATS_JSON} not found - samples will be segmented from colour only")
        marigold = Marigold(cfg.MARIGOLD_CODE, cfg.MARIGOLD_PYTHON, cfg.MARIGOLD_MAPS)

    for sid in args.ids:
        src = find(args.images, sid)
        if src is None:
            print(f"{sid}: no image in {args.images}, skipped")
            continue
        out = LIB / sid
        shutil.rmtree(out, ignore_errors=True)
        out.mkdir(parents=True)
        entry = {"id": sid, "label": labels.get(sid, {}).get("label") or f"Case {sid}",
                 "note": labels.get(sid, {}).get("note", ""), "outputs": not args.photos_only,
                 "photo": f"{sid}/photo.jpg", "thumb": f"{sid}/thumb.jpg"}

        if args.photos_only:
            from pipeline.analyse import load_photo
            rgb, _ = load_photo(src, cfg.WORK_SIZE)
            cv2.imwrite(str(out / "photo.jpg"), cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 90])
        else:
            with tempfile.TemporaryDirectory() as tmp:
                result = analyse(src, tmp, segmenter, marigold, stats, cfg, progress=lambda step: None)
                for name in COPY:
                    if (Path(tmp) / name).is_file():
                        shutil.copy(Path(tmp) / name, out / name)
            result["files"] = {k: v for k, v in result["files"].items() if v in COPY}
            result["notes"] = [f"Sample case {sid}. Outputs were made in advance by the same pipeline as live photos."] + result["notes"]
            entry["wound_found"] = result["measurements"]["wound_pixels"] > 0
            entry["result"] = f"{sid}/result.json"
            (out / "result.json").write_text(json.dumps(result, indent=1), encoding="utf-8")

        if args.reference:
            ref = find(args.reference, sid)
            if ref is not None:
                h, w = cv2.imread(str(out / "photo.jpg")).shape[:2]
                m = cv2.imread(str(ref), cv2.IMREAD_GRAYSCALE)
                m = cv2.resize(m, (w, h), interpolation=cv2.INTER_NEAREST)
                cv2.imwrite(str(out / "reference.png"), ((m > 127) * 255).astype(np.uint8))
                entry["reference"] = f"{sid}/reference.png"

        thumbnail(out / "photo.jpg", out / "thumb.jpg")
        by_id[sid] = entry
        print(f"{sid}: {'outputs' if entry['outputs'] else 'photo only'} -> {out}")

    order = [s["id"] for s in index["samples"]] + [i for i in args.ids if i not in {s["id"] for s in index["samples"]}]
    index["samples"] = [by_id[i] for i in order if i in by_id]
    write_index(index)
    print(f"{len(index['samples'])} samples in {INDEX}")


if __name__ == "__main__":
    sys.exit(main())
