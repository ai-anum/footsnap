"""3D surface from Marigold depth, matching the research reconstruction outputs.

Reverse-engineered from reconstruction/<split>/<stem>/{depth.npy, points.ply, mesh.ply}
and checked against them (case 200001: identical vertex grid and colours, 99.99% of faces):

    t      = clip((depth - p2) / (p98 - p2), 0, 1)       2nd-98th percentile stretch
    z      = exp(strength * t)                           distance from camera, 1..e
    camera = pinhole, 60 degree horizontal field of view, looking down -z
    x      = (u - (w-1)/2) * z / f,   y = -(v - (h-1)/2) * z / f,   f = 0.5 w / tan(30 deg)
    grid   = every pixel except the 1-pixel border; two triangles per pixel square
    cuts   = a square is dropped when its farthest/nearest corner ratio > 1.08 (depth edges)

The close-up keeps the wound and the skin around it, cut out AFTER reconstruction so the
relief is not exaggerated (same logic as closeup() in reconstruct_3d.py).
Depth is relative: the mesh shows shape, not millimetres.
"""
import json
import struct

import cv2
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

FOV = 60.0
EDGE_RATIO = 1.08


def surface(depth, colours, strength=1.0, step=1):
    """depth [H,W], colours uint8 [H,W,3] -> vertices [N,3], colours [N,3], faces [M,3], pixel (u,v) [N,2]"""
    h, w = depth.shape
    f = 0.5 * w / np.tan(np.radians(FOV / 2))
    low, high = np.percentile(depth, [2, 98])
    z = np.exp(strength * np.clip((depth.astype(np.float64) - low) / max(high - low, 1e-6), 0, 1))

    rows, cols = np.arange(1, h - 1, step), np.arange(1, w - 1, step)
    vv, uu = np.meshgrid(rows, cols, indexing="ij")
    zz = z[vv, uu]
    verts = np.stack([(uu - (w - 1) / 2) * zz / f, -(vv - (h - 1) / 2) * zz / f, -zz], -1).reshape(-1, 3)
    H, W = vv.shape
    idx = np.arange(H * W).reshape(H, W)
    a, b, c, d = idx[:-1, :-1].ravel(), idx[1:, :-1].ravel(), idx[1:, 1:].ravel(), idx[:-1, 1:].ravel()
    zf = zz.ravel()
    q = np.stack([zf[a], zf[b], zf[c], zf[d]], 1)
    keep = q.max(1) / q.min(1) <= EDGE_RATIO ** step
    faces = np.concatenate([np.stack([a, b, c], 1)[keep], np.stack([a, c, d], 1)[keep]])

    used = np.unique(faces)                                   # drop vertices no face uses
    remap = np.full(len(verts), -1)
    remap[used] = np.arange(len(used))
    pix = np.stack([uu.ravel(), vv.ravel()], 1)[used]
    return (verts[used].astype(np.float32), colours[pix[:, 1], pix[:, 0]],
            remap[faces].astype(np.uint32), pix)


def foot_mask(rgb, depth, wound, edge_trim=3):
    """The foot (and leg) in the photo, so the 3D surface leaves out the sheet, bed and wall.

    A pixel belongs to the foot when it
      1. does not look like the background: not bright and colourless (sheets, walls), and
      2. is nearer than the background: depth below Otsu's split of the depth map (+ a margin),
    and it is connected to the wound. Holes are filled and the outline is smoothed, then a thin
    band is trimmed off the outline, because Marigold's depth blurs across it and that blur is
    what makes spikes at the edge of a mesh. Returns None when no wound is given."""
    from scipy import ndimage as ndi
    if wound is None or not wound.any():
        return None
    low, high = np.percentile(depth, [2, 98])
    t = np.clip((depth - low) / max(high - low, 1e-6), 0, 1).astype(np.float32)
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    background_colour = (hsv[..., 1] < 40) & (hsv[..., 2] > 150)
    split, _ = cv2.threshold((t * 255).astype(np.uint8), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    near = t < split / 255 + 0.15
    candidate = cv2.morphologyEx((~background_colour & near).astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    candidate[wound] = 1
    labels, _ = ndi.label(candidate)
    counts = np.bincount(labels[wound & (labels > 0)])
    if counts.size == 0 or counts.max() == 0:
        return None
    foot = ndi.binary_fill_holes(labels == counts.argmax())
    round_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    foot = cv2.morphologyEx(foot.astype(np.uint8), cv2.MORPH_CLOSE, round_kernel)       # smooth the outline
    foot = cv2.morphologyEx(foot, cv2.MORPH_OPEN, round_kernel)
    foot = cv2.erode(foot, np.ones((2 * edge_trim + 1, 2 * edge_trim + 1), np.uint8)).astype(bool)
    return foot | wound


def keep_region(verts, cols, faces, pix, region, seed):
    """Keep the triangles whose corners all fall inside `region` (a pixel mask), then the
    edge-connected piece of surface with most `seed` pixels on it (like trimesh's split)."""
    u, v = pix[:, 0], pix[:, 1]
    faces = faces[region[v, u][faces].all(1)]
    if len(faces) == 0:
        return None
    # drop stretched triangles (spikes where depth jumps): longest edge over 4x the typical edge
    tri = verts[faces]
    longest = np.max([np.linalg.norm(tri[:, a] - tri[:, b], axis=1) for a, b in ((0, 1), (1, 2), (2, 0))], axis=0)
    faces = faces[longest <= 4 * np.median(longest)]
    n, m = len(verts), len(faces)
    edges = np.sort(np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]), 1)
    owner = np.tile(np.arange(m), 3)
    key = edges[:, 0].astype(np.int64) * n + edges[:, 1]
    order = np.argsort(key, kind="stable")
    key, owner = key[order], owner[order]
    same = np.nonzero(key[1:] == key[:-1])[0]
    graph = coo_matrix((np.ones(len(same)), (owner[same], owner[same + 1])), shape=(m, m))
    _, face_label = connected_components(graph, directed=False)
    score = np.zeros(face_label.max() + 1)
    for lab in np.unique(face_label):
        vs = np.unique(faces[face_label == lab])
        score[lab] = seed[v[vs], u[vs]].sum()
    faces = faces[face_label == score.argmax()]
    used = np.unique(faces)
    remap = np.full(n, -1)
    remap[used] = np.arange(len(used))
    return verts[used], cols[used], remap[faces].astype(np.uint32), pix[used]


def closeup(verts, cols, faces, pix, mask, margin=1.0, foot=None):
    """Wound + surrounding skin: a box of margin x wound size around the wound (as closeup() in
    reconstruct_3d.py), limited to the foot when a foot mask is given."""
    ys, xs = np.nonzero(mask)
    pad = margin * max(ys.max() - ys.min(), xs.max() - xs.min(), 30)
    box = np.zeros(mask.shape, bool)
    box[max(int(ys.min() - pad) + 1, 0):int(ys.max() + pad), max(int(xs.min() - pad) + 1, 0):int(xs.max() + pad)] = True
    return keep_region(verts, cols, faces, pix, box & foot if foot is not None else box, mask)


def centre(verts):
    """Move the mesh so its middle is at the origin (easier to orbit in the viewer)."""
    return verts - (verts.min(0) + verts.max(0)) / 2


def write_glb(path, verts, cols, faces):
    """Minimal binary glTF: positions, vertex colours, triangles, unlit double-sided material
    (photo colours shown as they are, like the research previews)."""
    verts = np.ascontiguousarray(verts, np.float32)
    rgba = np.concatenate([cols, np.full((len(cols), 1), 255, np.uint8)], 1).astype(np.uint8)
    idx = np.ascontiguousarray(faces, np.uint32).ravel()
    blobs = [verts.tobytes(), rgba.tobytes(), idx.tobytes()]
    offsets, buf = [], b""
    for blob in blobs:
        offsets.append(len(buf))
        buf += blob + b"\0" * (-len(blob) % 4)
    gltf = {
        "asset": {"version": "2.0", "generator": "FootSnap"},
        "extensionsUsed": ["KHR_materials_unlit"],
        "scene": 0, "scenes": [{"nodes": [0]}], "nodes": [{"mesh": 0}],
        "meshes": [{"primitives": [{"attributes": {"POSITION": 0, "COLOR_0": 1}, "indices": 2,
                                    "material": 0, "mode": 4}]}],
        "materials": [{"pbrMetallicRoughness": {"baseColorFactor": [1, 1, 1, 1], "metallicFactor": 0,
                                                "roughnessFactor": 1},
                       "doubleSided": True, "extensions": {"KHR_materials_unlit": {}}}],
        "buffers": [{"byteLength": len(buf)}],
        "bufferViews": [{"buffer": 0, "byteOffset": offsets[0], "byteLength": len(blobs[0]), "target": 34962},
                        {"buffer": 0, "byteOffset": offsets[1], "byteLength": len(blobs[1]), "target": 34962},
                        {"buffer": 0, "byteOffset": offsets[2], "byteLength": len(blobs[2]), "target": 34963}],
        "accessors": [
            {"bufferView": 0, "componentType": 5126, "count": len(verts), "type": "VEC3",
             "min": verts.min(0).tolist(), "max": verts.max(0).tolist()},
            {"bufferView": 1, "componentType": 5121, "normalized": True, "count": len(rgba), "type": "VEC4"},
            {"bufferView": 2, "componentType": 5125, "count": len(idx), "type": "SCALAR"}],
    }
    js = json.dumps(gltf, separators=(",", ":")).encode()
    js += b" " * (-len(js) % 4)
    total = 12 + 8 + len(js) + 8 + len(buf)
    with open(path, "wb") as fh:
        fh.write(struct.pack("<III", 0x46546C67, 2, total))
        fh.write(struct.pack("<II", len(js), 0x4E4F534A) + js)
        fh.write(struct.pack("<II", len(buf), 0x004E4942) + buf)


def write_ply(path, verts, cols, faces):
    """Binary .ply (MeshLab, CloudCompare, Blender), same layout as the research mesh.ply."""
    header = (f"ply\nformat binary_little_endian 1.0\nelement vertex {len(verts)}\n"
              "property float x\nproperty float y\nproperty float z\n"
              "property uchar red\nproperty uchar green\nproperty uchar blue\nproperty uchar alpha\n"
              f"element face {len(faces)}\nproperty list uchar int vertex_indices\nend_header\n").encode()
    vd = np.dtype([("p", "<f4", 3), ("c", "u1", 4)])
    v = np.empty(len(verts), vd)
    v["p"] = verts
    v["c"] = np.concatenate([cols, np.full((len(cols), 1), 255, np.uint8)], 1)
    fd = np.dtype([("n", "u1"), ("i", "<i4", 3)])
    fc = np.empty(len(faces), fd)
    fc["n"] = 3
    fc["i"] = faces
    with open(path, "wb") as fh:
        fh.write(header + v.tobytes() + fc.tobytes())


def write_viewer_mesh(path, verts, cols, faces, extra=None):
    """Compact mesh for the app's built-in WebGL viewer (no three.js needed):
    centred, scaled so the wider of x/y spans 2, positions as int16 (x 1e-4), colours as uint8,
    triangles as uint16, each base64-encoded in one small JSON file.
    extra = {"albedo": colours, "depth": colours, ...}: other colourings of the SAME vertices,
    shown by the viewer's Surface colour control."""
    import base64
    if len(verts) >= 65535:
        raise ValueError("viewer mesh must have fewer than 65535 vertices; build it with a larger step")
    v = verts.astype(np.float64)
    v -= (v.min(0) + v.max(0)) / 2
    v *= 2 / max(np.ptp(v[:, 0]), np.ptp(v[:, 1]), 1e-9)
    q = np.round(np.clip(v, -3.2, 3.2) * 10000).astype(np.int16)
    out = {"n": int(len(v)), "t": int(len(faces)), "scale": 1e-4,
           "p": base64.b64encode(q.tobytes()).decode(),
           "c": base64.b64encode(np.ascontiguousarray(cols, np.uint8).tobytes()).decode(),
           "f": base64.b64encode(np.ascontiguousarray(faces, np.uint16).tobytes()).decode()}
    for name, c in (extra or {}).items():
        if len(c) != len(v):
            raise ValueError(f"colour set {name} has {len(c)} colours for {len(v)} vertices")
        out["c_" + name] = base64.b64encode(np.ascontiguousarray(c, np.uint8).tobytes()).decode()
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, separators=(",", ":"))


_SPECTRAL = np.array([[158, 1, 66], [213, 62, 79], [244, 109, 67], [253, 174, 97], [254, 224, 139],
                      [255, 255, 191], [230, 245, 152], [171, 221, 164], [102, 194, 165],
                      [50, 136, 189], [94, 79, 162]], np.float32)


def depth_picture(depth):
    """Depth as colours (2nd-98th percentile, red = near, blue = far), like utils.depth_picture."""
    low, high = np.percentile(depth, [2, 98])
    level = np.clip((depth - low) / max(high - low, 1e-6), 0, 1) * (len(_SPECTRAL) - 1)
    i = np.minimum(level.astype(int), len(_SPECTRAL) - 2)
    t = (level - i)[..., None]
    return ((1 - t) * _SPECTRAL[i] + t * _SPECTRAL[i + 1]).astype(np.uint8)
