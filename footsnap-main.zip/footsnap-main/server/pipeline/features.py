"""Curvature input channels for the segmentation model.

The functions below are copied unchanged from the research code (extract_features.py) so the
app feeds the model exactly what it was trained on:
    RGB (ImageNet-normalised) + curv_mean + shape_index (normalised with features/stats.json)
"""
import cv2
import numpy as np
from scipy.ndimage import gaussian_filter

SMOOTH = 1.5        # pixels of blur before measuring slopes and bends
IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], np.float32)
IMAGENET_STD = np.array([0.229, 0.224, 0.225], np.float32)


# ---------- copied from extract_features.py ----------

def find_stamp(rgb):
    """The orange date stamp: a row of small bright orange digits in the bottom 15% of the photo."""
    h, w, _ = rgb.shape
    top = int(h * 0.85)
    hsv = cv2.cvtColor(rgb[top:], cv2.COLOR_RGB2HSV)
    hue, sat, val = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    thin = (cv2.morphologyEx(val, cv2.MORPH_TOPHAT, kernel) >= 25) | \
           (cv2.morphologyEx(sat, cv2.MORPH_TOPHAT, kernel) >= 40)
    strokes = ((hue >= 8) & (hue <= 35) & (sat >= 120) & (val >= 160) & thin).astype(np.uint8)
    strokes = cv2.morphologyEx(strokes, cv2.MORPH_CLOSE, np.ones((2, 2), np.uint8))

    n, _, stats, centres = cv2.connectedComponentsWithStats(strokes, connectivity=8)
    digits = [(x, y, bw, bh, centres[i][1]) for i, (x, y, bw, bh, area) in enumerate(stats)
              if i > 0 and 5 <= area <= 600 and 6 <= bh <= 35 and bw <= 40]
    stamp = np.zeros((h, w), bool)
    if len(digits) < 4:
        return stamp

    line = np.median([d[4] for d in digits])
    digits = sorted([d for d in digits if abs(d[4] - line) <= 15], key=lambda d: d[0])
    groups, current = [], []
    for d in digits:
        if current and d[0] - (current[-1][0] + current[-1][2]) > 40:
            groups.append(current)
            current = []
        current.append(d)
    groups.append(current)
    best = max(groups, key=len)
    if len(best) < 4:
        return stamp

    pad = 6
    x1, x2 = max(min(d[0] for d in best) - pad, 0), min(max(d[0] + d[2] for d in best) + pad, w)
    y1 = max(min(d[1] for d in best) + top - pad, 0)
    y2 = min(max(d[1] + d[3] for d in best) + top + pad, h)
    stamp[y1:y2, x1:x2] = True
    return stamp


def curvature(normals, signs):
    """Mean curvature and shape index from the normals (cup positive)."""
    nx = signs[0] * gaussian_filter(normals[0], SMOOTH)
    ny = signs[1] * gaussian_filter(normals[1], SMOOTH)
    a = -np.gradient(nx, axis=1)
    c = -np.gradient(ny, axis=0)
    b = -(np.gradient(nx, axis=0) + np.gradient(ny, axis=1)) / 2
    curv_mean = (a + c) / 2
    spread = np.sqrt(((a - c) / 2) ** 2 + b ** 2)
    k1, k2 = curv_mean + spread, curv_mean - spread
    shape_index = (2 / np.pi) * np.arctan2(k1 + k2, k1 - k2 + 1e-12)
    return curv_mean, shape_index

# ---------- end of copied code ----------


def model_input(rgb, normals, stats, channels=("curv_mean", "shape_index")):
    """Build the [C,H,W] float32 input exactly like train.WoundData.__getitem__.

    rgb      uint8 [H,W,3]
    normals  float32 [3,H,W] Marigold normals (unit length) or None
    stats    contents of features/stats.json or None
    Returns (x, stamp, notes)."""
    notes = []
    photo = (rgb.astype(np.float32) / 255 - IMAGENET_MEAN) / IMAGENET_STD
    stamp = find_stamp(rgb)
    h, w = rgb.shape[:2]

    if normals is None or stats is None:
        extra = np.zeros((h, w, len(channels)), np.float32)
        notes.append("Curvature channels unavailable "
                     + ("(no Marigold normals)" if normals is None else "(features/stats.json not found)")
                     + "; segmenting from colour only.")
    else:
        signs = tuple(stats["normal_signs"])
        curv_mean, shape_index = curvature(normals.astype(np.float32), signs)
        layers = {"curv_mean": curv_mean, "shape_index": shape_index}
        extra = []
        for name in channels:
            layer = np.nan_to_num(layers[name])
            layer[stamp] = 0
            layer = layer.astype(np.float16).astype(np.float32)        # stored as float16 in training
            extra.append((layer - stats["channels"][name]["mean"]) / stats["channels"][name]["std"])
        extra = np.stack(extra, -1)
    x = np.concatenate([photo, extra], -1).transpose(2, 0, 1).astype(np.float32)
    return x, stamp, notes
