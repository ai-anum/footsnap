"""One photo in, everything the app shows out.

    photo -> resize to DFUC scale -> Marigold depth + normals -> curvature channels
          -> SegFormer-B5 mask -> overlay pictures + measurements -> 3D mesh + close-up
"""
import json
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageOps

try:                                    # iPhone HEIC photos, if pillow-heif is installed (pip install pillow-heif)
    from pillow_heif import register_heif_opener
    register_heif_opener()
except ImportError:
    pass

from . import reconstruct as R
from .features import model_input

OUTLINE_OPACITY = 0.6           # as in reconstruct_3d.py
WOUND_COLOUR = (255, 77, 109)   # overlay fill in the app pictures


def load_photo(path, work_size):
    """Read any phone photo, apply its EXIF rotation, and bring it to DFUC2022 scale.
    The model, the stamp finder and the curvature blur were all tuned on ~640x480 photos."""
    img = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
    rgb = np.asarray(img)
    h, w = rgb.shape[:2]
    scale = work_size / max(h, w)
    if abs(scale - 1) > 1e-3:
        size = (round(w * scale), round(h * scale))
        rgb = cv2.resize(rgb, size, interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC)
    return np.ascontiguousarray(rgb), (w, h)


def tint(image, area, colour, strength):
    out = image.copy()
    out[area] = ((1 - strength) * out[area] + strength * np.array(colour)).astype(np.uint8)
    return out


def outline(mask, width=2):
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    line = np.zeros(mask.shape, np.uint8)
    cv2.drawContours(line, contours, -1, 1, width)
    return line.astype(bool), contours


def measurements(mask, prob, contours, depth):
    h, w = mask.shape
    area = int(mask.sum())
    out = {"wound_pixels": area, "image_pixels": h * w,
           "wound_percent": round(100 * area / (h * w), 2), "regions": len(contours)}
    if area:
        ys, xs = np.nonzero(mask)
        out["bbox"] = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]
        out["mean_confidence"] = round(float(prob[mask].mean()), 3)
        out["perimeter_pixels"] = round(float(sum(cv2.arcLength(c, True) for c in contours)), 1)
        biggest = max(contours, key=cv2.contourArea)
        if len(biggest) >= 5:
            (_, _), (a, b), _ = cv2.minAreaRect(biggest)
            out["length_pixels"], out["width_pixels"] = round(max(a, b), 1), round(min(a, b), 1)
        if depth is not None:
            # relative relief: how much deeper the wound sits than a ring of skin around it (0..1 scale)
            low, high = np.percentile(depth, [2, 98])
            t = np.clip((depth - low) / max(high - low, 1e-6), 0, 1)
            ring = cv2.dilate(mask.astype(np.uint8), np.ones((25, 25), np.uint8)).astype(bool) & ~mask
            if ring.any():
                out["relative_depth"] = round(float(np.median(t[mask]) - np.median(t[ring])), 4)
    return out


def analyse(photo_path, out_dir, segmenter, marigold, stats, cfg, progress=lambda step: None):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    timings, notes = {}, []

    def clock(name, t0):
        timings[name] = round(time.time() - t0, 2)

    progress("preparing")
    t0 = time.time()
    rgb, original_size = load_photo(photo_path, cfg.WORK_SIZE)
    h, w = rgb.shape[:2]
    cv2.imwrite(str(out / "photo.jpg"), cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 92])
    clock("prepare", t0)

    progress("geometry")
    t0 = time.time()
    maps = marigold.run(rgb, stem=Path(photo_path).stem)
    depth, normals, albedo = maps if maps is not None else (None, None, None)
    if maps is None:
        notes.append("Marigold is not set up on the server: no 3D surface, and segmentation uses colour only.")
    clock("marigold", t0)

    progress("segmenting")
    t0 = time.time()
    x, stamp, n = model_input(rgb, normals, stats)
    notes += n
    prob = segmenter.probability(x)
    mask = prob > cfg.THRESHOLD
    clock("segmentation", t0)

    line, contours = outline(mask)
    cv2.imwrite(str(out / "mask.png"), mask.astype(np.uint8) * 255)
    overlay = tint(rgb, mask, WOUND_COLOUR, 0.45)
    overlay = tint(overlay, line, (255, 255, 255), 0.9)
    cv2.imwrite(str(out / "overlay.jpg"), cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 92])
    # mask as a transparent PNG so the app can fade it over the photo
    rgba = np.zeros((h, w, 4), np.uint8)
    rgba[mask] = (*WOUND_COLOUR, 150)
    rgba[line] = (255, 255, 255, 255)
    cv2.imwrite(str(out / "mask_layer.png"), cv2.cvtColor(rgba, cv2.COLOR_RGBA2BGRA))
    cv2.imwrite(str(out / "confidence.png"), (prob * 255).astype(np.uint8))

    files = {"photo": "photo.jpg", "overlay": "overlay.jpg", "mask": "mask.png",
             "mask_layer": "mask_layer.png", "confidence": "confidence.png"}

    if depth is not None:
        progress("reconstructing")
        t0 = time.time()
        np.save(out / "depth.npy", depth)
        # the Marigold maps as pictures, the same size as the photo so the mask lines up on each
        layers = {"depth": R.depth_picture(depth),
                  "normals": ((np.clip(normals.transpose(1, 2, 0), -1, 1) + 1) / 2 * 255).astype(np.uint8)}
        if albedo is not None:
            layers["albedo"] = (np.clip(albedo.transpose(1, 2, 0), 0, 1) * 255).astype(np.uint8)
        for name, pic in layers.items():
            cv2.imwrite(str(out / f"{name}.jpg"), cv2.cvtColor(pic, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 90])
            files[name] = f"{name}.jpg"
        # Mesh colour = photo with a white see-through outline of the PREDICTED wound
        textured = tint(rgb, line, (255, 255, 255), OUTLINE_OPACITY)
        # Only the foot is reconstructed for the app; the sheet, bed and wall are left out
        foot = R.foot_mask(rgb, depth, mask)
        if foot is not None:
            cv2.imwrite(str(out / "foot.png"), foot.astype(np.uint8) * 255)
        def build(pic, step):
            v, c, f, p = R.surface(depth, pic, cfg.DEPTH_STRENGTH, step=step)
            if foot is not None:
                kept = R.keep_region(v, c, f, p, foot, mask)
                if kept is not None:
                    v, c, f, p = kept
            return v, c, f, p
        verts, cols, faces, pix = build(textured, 1)
        R.write_ply(out / "mesh.ply", verts, cols, faces)
        files["mesh_ply"] = "mesh.ply"
        # phones get a half-resolution whole-photo mesh (4x fewer triangles, looks the same on screen)
        R.write_glb(out / "mesh.glb", *build(textured, 2)[:3])
        files["mesh"] = "mesh.glb"
        # viewer meshes for the app (half / quarter resolution keeps them light on phones), each
        # carrying one colour set per map so the 3D view can be painted with photo, albedo, depth or normals
        paints = {k: tint(pic, line, (255, 255, 255), OUTLINE_OPACITY) for k, pic in layers.items()}
        def colour_sets(step, cut):
            sets = {}
            for k, pic in paints.items():
                v, c, f, p = build(pic, step)
                if cut:
                    v, c, f, p = R.closeup(v, c, f, p, mask, cfg.CLOSEUP_MARGIN, foot)
                sets[k] = c
            return sets
        full_step = 3 if foot is not None else 4      # the foot alone is smaller, so it can use a finer grid
        full = build(textured, full_step)
        R.write_viewer_mesh(out / "viewer_full.json", *full[:3], extra=colour_sets(full_step, False))
        files["viewer_full"] = "viewer_full.json"
        if mask.any():
            part = R.closeup(verts, cols, faces, pix, mask, cfg.CLOSEUP_MARGIN, foot)
            if part is not None:
                R.write_glb(out / "closeup.glb", *part[:3])
                R.write_ply(out / "closeup.ply", *part[:3])
                files["closeup"], files["closeup_ply"] = "closeup.glb", "closeup.ply"
            for step in (2, 3, 4, 6):
                small = R.closeup(*build(textured, step), mask, cfg.CLOSEUP_MARGIN, foot)
                if small is not None and len(small[0]) < 60000:
                    R.write_viewer_mesh(out / "viewer_closeup.json", *small[:3], extra=colour_sets(step, True))
                    files["viewer_closeup"] = "viewer_closeup.json"
                    break
        clock("reconstruction", t0)

    if not mask.any():
        notes.append("No wound was found in this photo.")
    if stamp.any():
        notes.append("Date stamp detected and ignored.")

    result = {"size": [w, h], "original_size": list(original_size),
              "measurements": measurements(mask, prob, contours, depth),
              "files": files, "notes": notes, "timings": timings,
              "model": {"backend": segmenter.backend, "threshold": cfg.THRESHOLD,
                        "channels": ["R", "G", "B", "curv_mean", "shape_index"],
                        "curvature_used": normals is not None and stats is not None}}
    (out / "result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result
