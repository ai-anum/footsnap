"""SegFormer-B5 forward pass in numpy (no torch), matching HuggingFace
SegformerForSemanticSegmentation + the SegFormer wrapper in models.py.

Used to verify the checkpoint and as a CPU fallback when torch is not installed.
Slower than torch (tens of seconds per 640x480 image) but gives the same answer.
"""
import cv2
import numpy as np
from scipy.special import erf

DEPTHS = (3, 6, 40, 3)          # mit-b5
HIDDEN = (64, 128, 320, 512)
HEADS = (1, 2, 5, 8)
SR = (8, 4, 2, 1)
PATCH = (7, 3, 3, 3)
STRIDE = (4, 2, 2, 2)
EPS = 1e-5                      # nn.LayerNorm default, as used by HF Segformer


def layer_norm(x, w, b):
    m = x.mean(-1, keepdims=True)
    v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + EPS) * w + b


def gelu(x):
    return 0.5 * x * (1 + erf(x / np.sqrt(2)))


def conv2d(x, w, b, stride, pad):
    """x [C,H,W], w [O,C,k,k] -> [O,H',W'] via im2col."""
    c, h, wd = x.shape
    o, _, k, _ = w.shape
    x = np.pad(x, ((0, 0), (pad, pad), (pad, pad)))
    ho, wo = (h + 2 * pad - k) // stride + 1, (wd + 2 * pad - k) // stride + 1
    s = x.strides
    cols = np.lib.stride_tricks.as_strided(
        x, (c, k, k, ho, wo), (s[0], s[1], s[2], s[1] * stride, s[2] * stride))
    out = w.reshape(o, -1) @ cols.reshape(c * k * k, ho * wo)
    if b is not None:
        out += b[:, None]
    return out.reshape(o, ho, wo)


def depthwise3x3(x, w, b):
    """x [C,H,W], w [C,1,3,3]"""
    c, h, wd = x.shape
    p = np.pad(x, ((0, 0), (1, 1), (1, 1)))
    out = np.zeros_like(x)
    for i in range(3):
        for j in range(3):
            out += w[:, 0, i, j][:, None, None] * p[:, i:i + h, j:j + wd]
    return out + b[:, None, None]


def resize_bilinear(x, h, w):
    """[C,H,W] -> [C,h,w], same as F.interpolate(mode='bilinear', align_corners=False)."""
    out = np.empty((x.shape[0], h, w), np.float32)
    for s in range(0, x.shape[0], 4):                # cv2 resizes at most 4 channels at once
        chunk = np.ascontiguousarray(x[s:s + 4].transpose(1, 2, 0).astype(np.float32))
        r = cv2.resize(chunk, (w, h), interpolation=cv2.INTER_LINEAR)
        out[s:s + 4] = r.reshape(h, w, -1).transpose(2, 0, 1)
    return out


class NumpySegFormer:
    def __init__(self, state_dict):
        self.p = {k[4:] if k.startswith('net.') else k: v.astype(np.float32)
                  for k, v in state_dict.items() if v.dtype != np.int64}
        self.in_channels = self.p['segformer.encoder.patch_embeddings.0.proj.weight'].shape[1]

    def __call__(self, x):
        """x [C,H,W] float32 (already normalised) -> logits [H,W]"""
        P = self.p
        feats, h = [], x.astype(np.float32)
        for s in range(4):
            e = f'segformer.encoder.patch_embeddings.{s}.'
            h = conv2d(h, P[e + 'proj.weight'], P[e + 'proj.bias'], STRIDE[s], PATCH[s] // 2)
            _, H, W = h.shape
            t = layer_norm(h.reshape(HIDDEN[s], -1).T, P[e + 'layer_norm.weight'], P[e + 'layer_norm.bias'])
            for i in range(DEPTHS[s]):
                t = self._block(t, H, W, s, f'segformer.encoder.block.{s}.{i}.')
            t = layer_norm(t, P[f'segformer.encoder.layer_norm.{s}.weight'], P[f'segformer.encoder.layer_norm.{s}.bias'])
            h = t.T.reshape(HIDDEN[s], H, W)
            feats.append(h)

        # all-MLP decode head
        H0, W0 = feats[0].shape[1:]
        ups = []
        for s, f in enumerate(feats):
            c = f'decode_head.linear_c.{s}.proj.'
            y = (f.reshape(f.shape[0], -1).T @ P[c + 'weight'].T + P[c + 'bias']).T
            y = y.reshape(-1, *f.shape[1:])
            ups.append(resize_bilinear(y, H0, W0) if y.shape[1:] != (H0, W0) else y)
        y = np.concatenate(ups[::-1], 0)
        y = np.tensordot(P['decode_head.linear_fuse.weight'][:, :, 0, 0], y, 1)
        bn = 'decode_head.batch_norm.'
        y = (y - P[bn + 'running_mean'][:, None, None]) / np.sqrt(P[bn + 'running_var'][:, None, None] + 1e-5)
        y = np.maximum(y * P[bn + 'weight'][:, None, None] + P[bn + 'bias'][:, None, None], 0)
        logits = np.tensordot(P['decode_head.classifier.weight'][:, :, 0, 0], y, 1) + P['decode_head.classifier.bias'][:, None, None]
        return resize_bilinear(logits, *x.shape[1:])[0]

    def _block(self, t, H, W, s, k):
        P = self.p
        C, nh = HIDDEN[s], HEADS[s]
        a = k + 'attention.self.'
        n = layer_norm(t, P[k + 'layer_norm_1.weight'], P[k + 'layer_norm_1.bias'])
        q = n @ P[a + 'query.weight'].T + P[a + 'query.bias']
        kv = n
        if SR[s] > 1:
            img = n.T.reshape(C, H, W)
            r = SR[s]
            img = conv2d(img, P[a + 'sr.weight'], P[a + 'sr.bias'], r, 0)
            kv = layer_norm(img.reshape(C, -1).T, P[a + 'layer_norm.weight'], P[a + 'layer_norm.bias'])
        key = kv @ P[a + 'key.weight'].T + P[a + 'key.bias']
        val = kv @ P[a + 'value.weight'].T + P[a + 'value.bias']
        d = C // nh
        q = q.reshape(-1, nh, d).transpose(1, 0, 2)
        key = key.reshape(-1, nh, d).transpose(1, 2, 0)
        val = val.reshape(-1, nh, d).transpose(1, 0, 2)
        att = (q @ key) / np.sqrt(d)
        att = np.exp(att - att.max(-1, keepdims=True))
        att /= att.sum(-1, keepdims=True)
        ctx = (att @ val).transpose(1, 0, 2).reshape(-1, C)
        t = t + ctx @ P[k + 'attention.output.dense.weight'].T + P[k + 'attention.output.dense.bias']

        m = k + 'mlp.'
        n = layer_norm(t, P[k + 'layer_norm_2.weight'], P[k + 'layer_norm_2.bias'])
        h1 = n @ P[m + 'dense1.weight'].T + P[m + 'dense1.bias']
        h1 = depthwise3x3(h1.T.reshape(-1, H, W), P[m + 'dwconv.dwconv.weight'], P[m + 'dwconv.dwconv.bias'])
        h1 = gelu(h1.reshape(h1.shape[0], -1).T)
        return t + h1 @ P[m + 'dense2.weight'].T + P[m + 'dense2.bias']
