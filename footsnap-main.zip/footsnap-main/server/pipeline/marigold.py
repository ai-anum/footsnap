"""Marigold V2 depth + normals for one photo.

Runs the same command as the research marigold.py (scripts/infer.py, seed 2025) on a folder
holding just this photo, then post-processes the maps the same way (resize to the photo,
unit-length normals, float16 round trip).

If a precomputed map exists (<maps dir>/<image name>.npz, as written by marigold.py) it is used
instead, which is handy for DFUC images that were already processed.
"""
import subprocess
import tempfile
from pathlib import Path

import cv2
import numpy as np


def _resize(array, size):
    h, w = size
    if array.shape[-2:] == (h, w):
        return array
    if array.ndim == 2:
        return cv2.resize(array, (w, h), interpolation=cv2.INTER_LINEAR)
    return np.stack([cv2.resize(c, (w, h), interpolation=cv2.INTER_LINEAR) for c in array])


def _finish(depth, normals, size, albedo=None):
    depth = _resize(depth.astype(np.float32), size)
    normals = _resize(normals.astype(np.float32), size)
    normals /= np.maximum(np.linalg.norm(normals, axis=0), 1e-6)
    if albedo is not None:
        albedo = np.clip(_resize(albedo.astype(np.float32), size), 0, 1).astype(np.float16).astype(np.float32)
    # marigold.py stores the maps as float16; mimic it so features match training exactly
    return depth.astype(np.float16).astype(np.float32), normals.astype(np.float16).astype(np.float32), albedo


class Marigold:
    def __init__(self, code_dir=None, python="python", maps_dirs=(), timeout=900):
        self.code_dir = Path(code_dir) if code_dir else None
        self.python = python
        self.maps_dirs = [Path(p) for p in maps_dirs if p]
        self.timeout = timeout

    @property
    def available(self):
        return bool(self.code_dir and (self.code_dir / "scripts" / "infer.py").is_file())

    def precomputed(self, stem, size):
        for folder in self.maps_dirs:
            f = folder / f"{stem}.npz"
            if f.is_file():
                with np.load(f) as m:
                    return _finish(m["depth"], m["normals"], size, m["albedo"] if "albedo" in m.files else None)
        return None

    def run(self, rgb, stem="photo", log=print):
        """rgb uint8 [H,W,3] -> (depth [H,W], normals [3,H,W], albedo [3,H,W] or None), or None if
        Marigold is not set up. Albedo is only shown in the app, so if it fails the rest still runs."""
        size = rgb.shape[:2]
        found = self.precomputed(stem, size)
        if found is not None:
            log("Using precomputed Marigold maps")
            return found
        if not self.available:
            return None
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            (tmp / "images").mkdir()
            cv2.imwrite(str(tmp / "images" / f"{stem}.png"), cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
            maps = {}
            for task in ("depth", "normals", "albedo"):
                log(f"Marigold {task}")
                try:
                    done = subprocess.run([self.python, str(Path("scripts") / "infer.py"), "--modality", task,
                                           "--image_dir", str(tmp / "images"), "--output_dir", str(tmp / task),
                                           "--seed", "2025"],
                                          cwd=self.code_dir, timeout=self.timeout,
                                          stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
                    if done.returncode != 0:      # show Marigold's own error, not just the exit code
                        tail = done.stderr.decode("utf-8", "replace").strip().splitlines()[-15:]
                        raise RuntimeError(f"Marigold {task} failed (exit {done.returncode}):\n" + "\n".join(tail))
                    files = list((tmp / task).rglob(f"predictions_npy/{stem}.npy"))
                    if not files:
                        raise RuntimeError(f"Marigold produced no {task} map")
                    maps[task] = np.load(files[0])
                except Exception:
                    if task != "albedo":
                        raise
                    log("Marigold albedo failed; continuing without it")
        return _finish(maps["depth"], maps["normals"], size, maps.get("albedo"))
