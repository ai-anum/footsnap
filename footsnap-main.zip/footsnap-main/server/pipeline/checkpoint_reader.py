"""Read a PyTorch state_dict (.pt, zip format) into numpy arrays WITHOUT torch.

Used by the numpy SegFormer (CPU fallback / verification). With torch installed the
server loads model.pt the normal way instead.
"""
import collections
import pickle
import zipfile

import numpy as np

_DTYPES = {'FloatStorage': np.float32, 'HalfStorage': np.float16, 'DoubleStorage': np.float64,
           'LongStorage': np.int64, 'IntStorage': np.int32, 'ByteStorage': np.uint8,
           'BoolStorage': np.bool_, 'BFloat16Storage': 'bf16'}


class _TensorRef:
    def __init__(self, storage, offset, size, stride):
        self.storage, self.offset, self.size, self.stride = storage, offset, tuple(size), tuple(stride)


def _rebuild_tensor_v2(storage, offset, size, stride, *args):
    return _TensorRef(storage, offset, size, stride)


def _rebuild_parameter(data, *args):
    return data


class _Unpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if name == '_rebuild_tensor_v2':
            return _rebuild_tensor_v2
        if name == '_rebuild_parameter':
            return _rebuild_parameter
        if name in _DTYPES:
            return type(name, (), {'dtype': _DTYPES[name]})
        if module.startswith('collections'):
            return getattr(collections, name)
        if module == 'torch._utils' or module.startswith('torch'):
            raise pickle.UnpicklingError(f'unsupported object in checkpoint: {module}.{name}')
        raise pickle.UnpicklingError(f'refusing to load {module}.{name}')   # never run arbitrary code

    def persistent_load(self, pid):
        return pid[1], pid[2]          # (storage type, key)


def load_state_dict(path):
    """{name: np.ndarray} for every tensor in the checkpoint."""
    archive = zipfile.ZipFile(path)
    prefix = archive.namelist()[0].split('/')[0]
    refs = _Unpickler(archive.open(f'{prefix}/data.pkl')).load()
    cache, out = {}, {}
    for name, ref in refs.items():
        storage_type, key = ref.storage
        if key not in cache:
            raw = archive.read(f'{prefix}/data/{key}')
            if storage_type.dtype == 'bf16':
                cache[key] = (np.frombuffer(raw, np.uint16).astype(np.uint32) << 16).view(np.float32)
            else:
                cache[key] = np.frombuffer(raw, storage_type.dtype)
        flat = cache[key]
        out[name] = np.lib.stride_tricks.as_strided(
            flat[ref.offset:], shape=ref.size, strides=[s * flat.itemsize for s in ref.stride]).copy()
    return out
