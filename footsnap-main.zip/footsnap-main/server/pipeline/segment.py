"""Load model.pt once and predict a wound mask.

With torch + transformers installed (the research environment) it rebuilds the exact
SegFormer-B5 from models.py, offline, and runs on the GPU like test.py.
Without torch it falls back to the numpy implementation (same weights, same answer, slower).
"""
import numpy as np


class Segmenter:
    def __init__(self, model_path, device=None):
        self.backend = None
        try:
            import torch
            import torch.nn as nn
            import torch.nn.functional as F
            from transformers import SegformerConfig, SegformerForSemanticSegmentation

            state = torch.load(model_path, map_location="cpu", weights_only=True)
            n_in = state["net.segformer.encoder.patch_embeddings.0.proj.weight"].shape[1]
            # mit-b5 architecture, built locally so no download is needed
            cfg = SegformerConfig(num_channels=n_in, num_labels=1, depths=[3, 6, 40, 3],
                                  hidden_sizes=[64, 128, 320, 512], num_attention_heads=[1, 2, 5, 8],
                                  sr_ratios=[8, 4, 2, 1], decoder_hidden_size=768)

            class SegFormer(nn.Module):                      # same wrapper as models.py
                def __init__(self):
                    super().__init__()
                    self.net = SegformerForSemanticSegmentation(cfg)

                def forward(self, x):
                    logits = self.net(pixel_values=x).logits
                    return [F.interpolate(logits, size=x.shape[-2:], mode="bilinear")]

            model = SegFormer()
            model.load_state_dict(state)
            self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
            self.model = model.to(self.device).eval()
            self.torch = torch
            self.in_channels = n_in
            self.backend = f"torch ({self.device})"
        except ImportError:
            from .checkpoint_reader import load_state_dict
            from .numpy_segformer import NumpySegFormer
            self.model = NumpySegFormer(load_state_dict(model_path))
            self.in_channels = self.model.in_channels
            self.backend = "numpy (CPU)"

    def probability(self, x):
        """x [C,H,W] float32 -> wound probability [H,W]"""
        if x.shape[0] != self.in_channels:
            raise ValueError(f"model expects {self.in_channels} input channels, got {x.shape[0]}")
        if self.backend.startswith("torch"):
            torch = self.torch
            t = torch.from_numpy(x)[None].to(self.device)
            with torch.no_grad():
                if self.device == "cuda":
                    with torch.autocast("cuda", dtype=torch.bfloat16):     # as in test.py
                        logit = self.model(t)[-1].float()
                else:
                    logit = self.model(t)[-1].float()
            return torch.sigmoid(logit)[0, 0].cpu().numpy()
        logit = self.model(x)
        return 1 / (1 + np.exp(-np.clip(logit, -50, 50)))
