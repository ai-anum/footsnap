"""Add images with ready-made Marigold maps (and optionally masks) to the app's sample library.

    python import_samples.py ~/Downloads/footsnap_data            # every photo in images/
    python import_samples.py ~/Downloads/footsnap_data --ids 200149 200154

Input folder (files named by image id):

    images/<id>.jpg                       the RGB photo - the only thing the gallery shows
    masks/<id>.png                        optional: segmentation (white = wound). Without it the
                                          model segments the photo (colour only if stats.json is missing)
    marigold/runs/depth/<id>.png          Marigold depth as its Spectral colour picture (or <id>.npy raw)
    marigold/runs/normals/<id>.png        Marigold normals picture, rgb = (n + 1) / 2 (or <id>.npy)
    marigold/runs/albedo/<id>.png         Marigold albedo picture (or <id>.npy, 0..1)
    reconstructions/<id>/depth.npy        optional: raw depth, used instead of the depth picture

The depth picture is turned back into depth by looking each colour up in matplotlib's Spectral
colour map (256 levels, red = near). The 3D surface only uses depth relative to itself (2nd-98th
percentile stretch), so this gives the same surface as the raw depth: on case 200086 the median
difference is 0.09 %.

Everything else - foot-only 3D, close-up, viewer meshes, measurements, result.json - is made by
the same analyse() the server runs on a live photo, and written to app/demo/<id>/ like
build_samples.py. The app downloads the thumbnails for the gallery and the rest only when an
image is chosen.
"""
import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path

import cv2
import numpy as np

import settings as cfg
from build_samples import COPY, LIB, read_index, thumbnail, write_index
from pipeline.analyse import analyse
from pipeline.marigold import _finish

IMAGE_TYPES = (".jpg", ".jpeg", ".png")


def spectral_lut():
    """matplotlib's Spectral colour map, 256 entries, as packed RGB ints -> level 0..255."""
    try:
        import matplotlib
        rgb = matplotlib.colormaps["Spectral"](np.linspace(0, 1, 256))[:, :3]
    except ImportError:
        sys.exit("pip install matplotlib (needed to read the depth pictures)")
    rgb = np.round(rgb * 255).astype(np.int64)
    return (rgb[:, 0] << 16) | (rgb[:, 1] << 8) | rgb[:, 2]


def depth_from_picture(path, lut):
    """Spectral colour picture -> depth 0 (near) .. 1 (far). Colours not on the map take the nearest one."""
    rgb = cv2.cvtColor(cv2.imread(str(path)), cv2.COLOR_BGR2RGB).astype(np.int64)
    keys = (rgb[..., 0] << 16) | (rgb[..., 1] << 8) | rgb[..., 2]
    order = np.argsort(lut)
    pos = np.clip(np.searchsorted(lut[order], keys), 0, 255)
    level = order[pos].astype(np.float32)
    exact = lut[order][pos] == keys
    if not exact.all():                       # e.g. a re-saved JPEG: nearest colour on the map
        cols = np.stack([(lut >> 16) & 255, (lut >> 8) & 255, lut & 255], 1)
        miss = rgb[~exact]
        level[~exact] = np.argmin(((miss[:, None, :] - cols[None]) ** 2).sum(-1), 1)
    return level / 255, float(exact.mean())


def find(folder, stem, types):
    for t in types:
        p = Path(folder) / f"{stem}{t}"
        if p.is_file():
            return p
    return None


def load_maps(root, sid, size, lut):
    """(depth [H,W], normals [3,H,W], albedo [3,H,W] or None, notes), or None if no depth/normals."""
    runs = root / "marigold" / "runs"
    notes = []
    raw = root / "reconstructions" / sid / "depth.npy"
    if raw.is_file():
        depth = np.load(raw).astype(np.float32)
        notes.append("Depth: raw depth.npy from the reconstruction.")
    else:
        f = find(runs / "depth", sid, (".npy",)) or find(runs / "depth", sid, IMAGE_TYPES)
        if f is None:
            return None
        if f.suffix == ".npy":
            depth = np.load(f).astype(np.float32)
        else:
            depth, exact = depth_from_picture(f, lut)
            if exact < 0.99:
                print(f"  {sid}: {100 - exact * 100:.1f}% of depth colours aren't on the Spectral map (matched to the nearest)")
    f = find(runs / "normals", sid, (".npy",)) or find(runs / "normals", sid, IMAGE_TYPES)
    if f is None:
        return None
    if f.suffix == ".npy":
        normals = np.load(f).astype(np.float32)
    else:
        normals = cv2.cvtColor(cv2.imread(str(f)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255 * 2 - 1
    if normals.shape[-1] == 3:
        normals = normals.transpose(2, 0, 1)
    albedo = None
    f = find(runs / "albedo", sid, (".npy",)) or find(runs / "albedo", sid, IMAGE_TYPES)
    if f is not None:
        albedo = np.load(f).astype(np.float32) if f.suffix == ".npy" else \
            cv2.cvtColor(cv2.imread(str(f)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
        if albedo.shape[-1] == 3:
            albedo = albedo.transpose(2, 0, 1)
    if depth.ndim == 3:
        depth = depth.squeeze()
    return (*_finish(depth, normals, size, albedo), notes)


class GivenMaps:
    """Stands in for Marigold in analyse(): returns the maps from the input folder."""
    available = True
    maps_dirs = []

    def __init__(self, maps):
        self.maps = maps

    def run(self, rgb, stem="photo", log=print):
        return self.maps


class GivenMask:
    """Stands in for the model in analyse(): the clinician's / dataset mask as the segmentation."""
    backend = "provided mask"

    def __init__(self, mask_path, in_channels):
        self.mask_path, self.in_channels = mask_path, in_channels

    def probability(self, x):
        h, w = x.shape[1:]
        m = cv2.imread(str(self.mask_path), cv2.IMREAD_GRAYSCALE)
        m = cv2.resize(m, (w, h), interpolation=cv2.INTER_NEAREST)
        return (m > 127).astype(np.float32)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("data", type=Path, help="folder with images/, masks/, marigold/runs/, reconstructions/")
    ap.add_argument("--ids", nargs="+", help="only these images (default: every photo in images/)")
    args = ap.parse_args()
    root = args.data.expanduser()

    photos = sorted(p for p in (root / "images").iterdir() if p.suffix.lower() in IMAGE_TYPES)
    if args.ids:
        photos = [p for p in photos if p.stem in args.ids]
    lut = spectral_lut()
    stats = json.loads(Path(cfg.STATS_JSON).read_text(encoding="utf-8")) if Path(cfg.STATS_JSON).is_file() else None
    model = None
    index = read_index()
    by_id = {s["id"]: s for s in index["samples"]}

    for photo in photos:
        sid = photo.stem
        rgb = cv2.cvtColor(cv2.imread(str(photo)), cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        if max(h, w) != cfg.WORK_SIZE:
            print(f"{sid}: photo is {w}x{h}; maps are matched to it after resizing to {cfg.WORK_SIZE} px")
            s = cfg.WORK_SIZE / max(h, w)
            h, w = round(h * s), round(w * s)
        maps = load_maps(root, sid, (h, w), lut)
        if maps is None:
            print(f"{sid}: no depth/normals in marigold/runs - skipped")
            continue
        *maps, notes = maps
        mask = find(root / "masks", sid, (".png", ".jpg", ".bmp", ".tif"))
        if mask is not None:
            segmenter = GivenMask(mask, 5)
            notes.append("Segmentation: provided mask.")
        else:
            if model is None:
                from pipeline.segment import Segmenter
                print(f"Loading {cfg.MODEL_PATH}")
                model = Segmenter(cfg.MODEL_PATH)
            segmenter = model
            notes.append("Segmentation: SegFormer-B5" + (" with curvature channels." if stats else ", colour only (features/stats.json not found)."))

        out = LIB / sid
        with tempfile.TemporaryDirectory() as tmp:
            result = analyse(photo, tmp, segmenter, GivenMaps(tuple(maps)), stats, cfg, progress=lambda step: None)
            shutil.rmtree(out, ignore_errors=True)
            out.mkdir(parents=True)
            for name in COPY:
                if (Path(tmp) / name).is_file():
                    shutil.copy(Path(tmp) / name, out / name)
        result["files"] = {k: v for k, v in result["files"].items() if v in COPY}
        result["notes"] = [f"Sample case {sid}. Marigold maps made in advance; 3D surface built from them by the FootSnap pipeline."] \
            + notes + [n for n in result["notes"] if not n.startswith("Marigold is not set up")]
        (out / "result.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
        thumbnail(out / "photo.jpg", out / "thumb.jpg")
        old = by_id.get(sid, {})
        by_id[sid] = {"id": sid, "label": old.get("label") or f"Case {sid}", "note": old.get("note", ""), "outputs": True,
                      "photo": f"{sid}/photo.jpg", "thumb": f"{sid}/thumb.jpg", "result": f"{sid}/result.json",
                      "wound_found": result["measurements"]["wound_pixels"] > 0}
        size = sum(f.stat().st_size for f in out.iterdir()) / 1e6
        print(f"{sid}: {'mask provided' if mask else 'mask from model'}, wound {result['measurements']['wound_pixels']} px, "
              f"3D {'full + close-up' if 'viewer_closeup' in result['files'] else ('full' if 'viewer_full' in result['files'] else 'none')}, "
              f"{size:.1f} MB -> {out}")

    order = [s["id"] for s in index["samples"]] + [i for i in by_id if i not in {s["id"] for s in index["samples"]}]
    index["samples"] = [by_id[i] for i in order]
    write_index(index)
    print(f"{len(index['samples'])} samples in {LIB / 'samples.json'}")


if __name__ == "__main__":
    sys.exit(main())
