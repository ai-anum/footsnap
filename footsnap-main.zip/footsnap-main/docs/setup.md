# Setup

## 1. Server

Run it on the machine that has the research project (`config.PROJECT`) and the GPU.

```bash
cd server
pip install -r requirements.txt
cp /path/to/runs/segformer_curvature_seed0/model.pt .
export PROJECT=/home/staff/fatimafa/Documents/Anum/Experiments/0003-Depth_Segmentation
export MARIGOLD_PYTHON=/path/to/marigold/env/bin/python    # only if Marigold has its own environment
python server.py
```

The start-up log should say:

```
segmentation backend: torch (cuda), 5 input channels
curvature stats: found (.../features/stats.json)
Marigold: ready (.../marigold-v2)
```

Anything **NOT found**: fix the path in `settings.py` or with an environment variable, then restart.

| Setting | Default | Why it matters |
|---|---|---|
| `MODEL_PATH` | `server/model.pt` | the 5-channel checkpoint (RGB + `curv_mean` + `shape_index`) |
| `STATS_JSON` | `$PROJECT/features/stats.json` | curvature mean/std and normal signs from training. Without it the curvature channels are zero and the app says so |
| `MARIGOLD_CODE` | `$PROJECT/marigold-v2` | depth, normals, albedo. Without it: colour-only segmentation, no 3D |
| `MARIGOLD_MAPS` | `$PROJECT/marigold/maps/test:…/train` | saved maps are reused when a photo is named like a DFUC image |
| `ACCESS_TOKEN` | none | if set, the app asks for this access code |
| `PORT` | 8000 | |

Photos and results are stored per case in `server/cases/` (git-ignored).

## 2. Phone, iPad or desktop

Open `http://<machine address>:8000` (find it with `hostname -I`) on a device on the same network.
In Safari: Share → **Add to Home Screen**. In Chrome: menu → **Install app**.

- Works in Safari on iOS 16+ (iPhone 16 Pro included) and current Chrome, Edge and Firefox.
- Take photo opens the rear camera. Photos are scaled to 1600 px on the device before upload.
- iOS converts HEIC to JPEG for the app. For HEIC files from elsewhere: `pip install pillow-heif`.
- Guest and eduroam networks often block device-to-device traffic. Use the hospital network or VPN.
- For use beyond the research group, put the server behind HTTPS.

## 3. Sample library

**From the app.** After a photo is analysed, tap **Save as sample** in Review, give it a name and an
optional note, and it is added to "Choose a sample image" with all its results. In the gallery,
**Remove** (tap twice) takes a sample out. Samples are stored in `app/demo/` on the server and are
visible to everyone who opens FootSnap, so don't save photos that identify a patient.

**From the command line,** for a set of dataset images:

```bash
cd server
python build_samples.py --images $PROJECT/datasets/dfuc2022/test/images \
    --reference $PROJECT/datasets/dfuc2022/test/masks \
    --labels samples.csv --ids 200001 200528 200745

python build_samples.py --images /path/to/photos --ids 300001 --photos-only   # segmented live
python build_samples.py --list
python build_samples.py --remove 200745
```

`samples.csv` has columns `id,label,note`. Aim for 5–6 test-split cases: a typical ulcer, a small
one, several wounds, heel or toes, darker skin, and one the model gets partly wrong.

## 4. Troubleshooting

| What you see | What to do |
|---|---|
| Page won't open on the phone | Same network? Firewall on port 8000? Try `PORT=8080 python server.py` |
| "Segmentation couldn't run" | The error is shown in the app and saved in `server/cases/<id>/error.txt` |
| "Curvature channels unavailable" note | `STATS_JSON` not found |
| "3D surface not available" | Marigold not set up and no saved map for this photo |
| Sizes show "—" | Set the ruler scale in Assess → Size |
