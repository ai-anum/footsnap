# Running the FootSnap server on Windows (Anaconda)

All commands are typed in the **Anaconda Prompt** (Start menu › Anaconda Prompt).

## 1. One-time setup

```bat
cd C:\path\to\footsnap
setup_windows.bat
```

This creates a conda environment called `footsnap` (Python 3.11, Flask, NumPy, SciPy, OpenCV,
Pillow, HEIC support) and installs PyTorch with CUDA if an NVIDIA GPU is found (CPU otherwise),
plus Hugging Face Transformers.

Then copy the trained weights into the server folder:

```bat
copy C:\path\to\runs\segformer_curvature_seed0\model.pt server\
```

## 2. Point it at the research project

Open `start_server.bat` in Notepad and edit the lines near the top:

```bat
set "PROJECT=C:\Research\0003-Depth_Segmentation"
set "MARIGOLD_PYTHON=%USERPROFILE%\anaconda3\envs\marigold\python.exe"
```

- `PROJECT` is where `features\stats.json`, `marigold-v2\` and `marigold\maps\` are.
- `MARIGOLD_PYTHON` is only needed if Marigold has its own environment (recommended: its
  `diffusers` version can clash with `transformers`). Default: the `footsnap` environment.
- Several folders in `MARIGOLD_MAPS` are separated with **`;`** on Windows.

## 3. Start

```bat
start_server.bat
```

Check the start-up lines:

```
segmentation backend: torch (cuda), 5 input channels
curvature stats: found (...\features\stats.json)
Marigold: ready (...\marigold-v2)
```

The script also prints this computer's **IPv4 Address**. Enter it in the iPhone app.

## 4. Let the iPhone reach the computer

- The first time Python listens, **Windows Firewall** asks for permission: tick **Private networks**
  and allow it. If you missed it, run this once in an *Administrator* prompt:
  ```bat
  netsh advfirewall firewall add rule name="FootSnap 8000" dir=in action=allow protocol=TCP localport=8000 profile=private
  ```
- The Wi-Fi or Ethernet connection must be set to **Private** (Settings › Network & internet ›
  your network › Network profile type). On *Public* the firewall blocks the phone.
- Phone and computer must be on the same network. Guest Wi-Fi and eduroam often block
  device-to-device traffic. Use the hospital network or a VPN.
- Quick test from the iPhone: open Safari at `http://<IPv4 address>:8000/api/health`.

## 5. Tests

```bat
conda activate footsnap
python tests\test_reconstruct.py
```

## Changes made for Windows

- File reads and writes use UTF-8 explicitly. Windows defaults to cp1252, which garbled or
  rejected non-English sample labels and notes.
- `MARIGOLD_MAPS` is split with `os.pathsep` (`;` on Windows). Splitting on `:` broke
  drive letters such as `C:\`.
- `MARIGOLD_PYTHON` defaults to the Python that runs the server, not whatever `python` is first
  on the PATH.
- When Marigold fails, its own error message is shown, not only the exit code.
