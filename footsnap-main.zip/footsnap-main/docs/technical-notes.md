# Technical notes

## 1. Segmentation input

The checkpoint's first convolution takes **5 channels**, so it is the `curvature` run from `train.py`:

| Channel | Source | Scaling |
|---|---|---|
| R, G, B | photo, 0–1 | ImageNet mean/std |
| `curv_mean` | Marigold normals → `curvature()` (copied from `extract_features.py`) | mean/std from `features/stats.json` |
| `shape_index` | same | same |

As in training: the date stamp is found and zeroed, features are rounded through float16, the
photo is used at native DFUC scale (long side 640 px; phone photos are resized to this), and the
mask is `sigmoid(logit) > 0.5` as in `test.py`.

## 2. Checking the checkpoint without a GPU

`pipeline/checkpoint_reader.py` reads `model.pt` without torch (it refuses any pickled code).
`pipeline/numpy_segformer.py` is SegFormer-B5 written in numpy, matching Hugging Face
`SegformerForSemanticSegmentation` plus the wrapper in `models.py`. On case 200001 (curvature
channels set to zero, as their first-layer weights are small) it gives **Dice 0.998** against
the supplied mask. The server uses torch when available and this numpy model otherwise.

## 3. 3D surface

`reconstruct.py` from the reconstruction code was not available, so it was rebuilt from the
outputs of case 200001 (`depth.npy`, `points.ply`, `mesh.ply`):

```
t      = clip((depth - p2) / (p98 - p2), 0, 1)        2nd–98th percentile stretch
z      = exp(strength · t)                            distance from camera, 1..e
camera : pinhole, 60° horizontal field of view, looking down -z
x      = (u - (w-1)/2) · z / f      y = -(v - (h-1)/2) · z / f      f = 0.5·w / tan(30°)
grid   : every pixel except the 1-pixel border, two triangles per pixel square
cuts   : a square is dropped when its farthest/nearest corner ratio > 1.08 (depth edges)
```

This reproduces the research vertex grid and colours exactly and 99.99 % of its faces. The
close-up follows `closeup()` in `reconstruct_3d.py`: a box of `margin × wound size` around the
wound, then the edge-connected piece of surface with most wound on it.

**Foot only (app).** The app's meshes keep only the foot. `foot_mask()` keeps pixels that are not
background-coloured (bright and colourless: sheets, walls) and are nearer than Otsu's split of the
depth map, then the connected region containing the wound, with holes filled and the outline
smoothed. A 3-pixel band is trimmed off the outline, where Marigold's depth blurs into the
background. `keep_region()` then keeps triangles inside the foot, drops stretched triangles
(longest edge over 4× the median) and keeps the connected piece with the wound. The foot mask is
saved per case as `foot.png`. The full-photo research mesh can still be made with
`reconstruct_3d.py`.

The app's viewer reads a compact JSON mesh (`viewer_closeup.json`, `viewer_full.json`):
positions as int16, colours as uint8 (one set each for photo, albedo, depth, normals) and
triangles as uint16, rendered with plain WebGL so it works offline. `.glb` and `.ply` are also
written for Blender or MeshLab.

## 4. API

| Method | Path | |
|---|---|---|
| GET | `/api/health` | model backend, Marigold, stats.json |
| POST | `/api/cases` | photo in field `image` → `{id}` |
| GET | `/api/cases/<id>` | status while running; result when done |
| GET | `/api/cases/<id>/<file>` | pictures, meshes |
| GET/PUT | `/api/cases/<id>/assessment` | the clinician's assessment |
| POST | `/api/cases/<id>/sample` | save an analysed photo to the sample library `{label, note}` |
| DELETE | `/api/samples/<id>` | remove a sample |
| GET / DELETE | `/api/cases`, `/api/cases/<id>` | list, remove |

One photo is analysed at a time (the GPU is shared); others queue.

## 5. Assessment

Defined in `app/assess.js`; the questions are the `SECTIONS` list at the top.

- **Length and width:** marked on the photo after a ruler scale (two points + distance). A typed
  value replaces the marked one; FootSnap's outline (OpenCV minimum-area rectangle) is shown for
  comparison.
- **Area, perimeter:** FootSnap's traced outline with the same scale.
- **Volume:** ellipsoid, π/6 × L × W × D. The form's L × W × D box overstates it by about 1.9×.
- **University of Texas:** grade = deepest structure (1 skin, 2 tendon or capsule, 3 bone or joint);
  stage A clean, B infected, C ischaemic, D both.
- **Wagner:** 1 superficial, 2 to tendon or capsule, 3 with abscess, osteomyelitis or bone,
  4 forefoot gangrene, 5 whole-foot gangrene.
- A classification confirmation is tied to the exact grades it confirmed and clears if answers change.
- Checks flag contradictions (e.g. purulent exudate with "no signs of infection", a width line not
  at right angles to the length).

## 6. Result labels

| Label | When |
|---|---|
| Model results | produced by the server for this photo |
| Imported outputs | a mask PNG loaded by the clinician (white = wound); no 3D |
| Sample outputs | pre-computed by `build_samples.py`, sample library only |

If the server is unreachable or the analysis fails, the app shows "Segmentation couldn't run" and
nothing in its place.
