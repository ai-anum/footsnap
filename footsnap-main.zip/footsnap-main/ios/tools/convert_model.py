"""Convert server/model.pt (SegFormer-B5, 5 input channels) to Core ML for on-iPhone segmentation.

    pip install torch transformers coremltools
    python ios/tools/convert_model.py                 # writes ios/FootSnap/WoundSegmenter.mlpackage

The iPhone has no Marigold, so the curvature channels are zero, exactly like the server when
Marigold is missing ("segmenting from colour only"). The Core ML model therefore takes only the
photo and does the rest itself:

    input  "image"        float [1, 3, H, W], RGB 0..255
    output "probability"  float [1, 1, H, W], wound probability (sigmoid of the logit)

ImageNet normalisation and the two zero curvature channels are inside the model.
H x W must be one of SHAPES (the app resizes the photo to the nearest one).
"""
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import SegformerConfig, SegformerForSemanticSegmentation

ROOT = Path(__file__).resolve().parents[2]
# (height, width): DFUC2022 is 640x480; phones also take 1:1, 16:9 and 3:2 photos
SHAPES = [(480, 640), (640, 480), (640, 640), (352, 640), (640, 352), (416, 640), (640, 416)]
MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]


def build(model_path):
    state = torch.load(model_path, map_location="cpu", weights_only=True)
    n_in = state["net.segformer.encoder.patch_embeddings.0.proj.weight"].shape[1]
    cfg = SegformerConfig(num_channels=n_in, num_labels=1, depths=[3, 6, 40, 3],
                          hidden_sizes=[64, 128, 320, 512], num_attention_heads=[1, 2, 5, 8],
                          sr_ratios=[8, 4, 2, 1], decoder_hidden_size=768)

    class SegFormer(nn.Module):                      # same wrapper as models.py / segment.py
        def __init__(self):
            super().__init__()
            self.net = SegformerForSemanticSegmentation(cfg)

    model = SegFormer()
    model.load_state_dict(state)
    return model.eval(), n_in


class OnDevice(nn.Module):
    """RGB 0..255 -> wound probability, colour only (curvature channels zero)."""

    def __init__(self, model, n_in):
        super().__init__()
        self.net = model.net
        self.n_extra = n_in - 3
        self.register_buffer("mean", torch.tensor(MEAN).view(1, 3, 1, 1) * 255)
        self.register_buffer("std", torch.tensor(STD).view(1, 3, 1, 1) * 255)

    def forward(self, image):
        x = (image - self.mean) / self.std
        if self.n_extra:
            x = torch.cat([x, torch.zeros_like(x[:, :1]).repeat(1, self.n_extra, 1, 1)], 1)
        logits = self.net(pixel_values=x).logits
        logits = F.interpolate(logits, size=image.shape[-2:], mode="bilinear", align_corners=False)
        return torch.sigmoid(logits)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=str(ROOT / "server" / "model.pt"))
    ap.add_argument("--out", default=str(ROOT / "ios" / "FootSnap" / "WoundSegmenter.mlpackage"))
    ap.add_argument("--check", help="a photo to compare Core ML against PyTorch on")
    args = ap.parse_args()

    import coremltools as ct

    model, n_in = build(args.model)
    wrapped = OnDevice(model, n_in).eval()
    example = torch.rand(1, 3, *SHAPES[0]) * 255
    # Core ML can't resize to a size read from a flexible input shape. Every SHAPES entry is a
    # multiple of 32, so each SegFormer resize is an exact integer scale: trace it as one.
    original = F.interpolate

    def by_scale(input, size=None, scale_factor=None, mode="nearest", align_corners=None, **kw):
        if size is not None and scale_factor is None:
            (sh, sw), (ih, iw) = (int(s) for s in size), input.shape[-2:]
            if sh % ih == 0 and sw % iw == 0 and sh // ih == sw // iw:
                return original(input, scale_factor=float(sh // ih), mode=mode, align_corners=align_corners)
        return original(input, size=size, scale_factor=scale_factor, mode=mode, align_corners=align_corners, **kw)

    F.interpolate = by_scale
    try:
        with torch.no_grad():
            traced = torch.jit.trace(wrapped, example)
    finally:
        F.interpolate = original

    shapes = ct.EnumeratedShapes(shapes=[(1, 3, h, w) for h, w in SHAPES], default=(1, 3, *SHAPES[0]))
    ml = ct.convert(traced, inputs=[ct.TensorType(name="image", shape=shapes)],
                    outputs=[ct.TensorType(name="probability")],
                    convert_to="mlprogram", compute_precision=ct.precision.FLOAT16,
                    minimum_deployment_target=ct.target.iOS17)
    ml.short_description = "FootSnap wound segmentation (SegFormer-B5, DFUC2022), colour only"
    ml.input_description["image"] = "RGB photo, 0..255, [1,3,H,W]"
    ml.output_description["probability"] = "Wound probability per pixel, [1,1,H,W]"
    ml.save(args.out)
    print("saved", args.out)

    if args.check:
        from PIL import Image
        img = Image.open(args.check).convert("RGB").resize((SHAPES[0][1], SHAPES[0][0]))
        x = np.asarray(img, np.float32).transpose(2, 0, 1)[None]
        with torch.no_grad():
            ref = wrapped(torch.from_numpy(x)).numpy()
        got = ml.predict({"image": x})["probability"]
        a, b = ref > 0.5, got > 0.5
        iou = (a & b).sum() / max((a | b).sum(), 1)
        print(f"max |diff| {np.abs(ref - got).max():.4f}, mask IoU torch vs Core ML {iou:.4f}, "
              f"wound pixels {a.sum()} vs {b.sum()}")


if __name__ == "__main__":
    main()
