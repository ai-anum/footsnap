# FootSnap for iPhone

A native iPhone app (SwiftUI, iOS 17+, made for iPhone 16 Pro) for the FootSnap server.
The analysis still runs on the server (Marigold + SegFormer-B5 on the GPU). The app hosts the
same clinician screens as the web app (capture → review → 3D → assess → report) and adds:

| | Web app in Safari | iPhone app |
|---|---|---|
| Server address | typed into the web page | saved in the app, with a **Test connection** check showing GPU, Marigold and curvature status |
| Report | Safari print dialog | **native A4 PDF** → Save to Files, AirDrop, Mail or Print, named `FootSnap report FS-….pdf` |
| Copy summary for AireForms | blocked on plain `http` | copies straight to the iPhone clipboard |
| Server not reachable | blank page | a screen saying what to check, with Retry |
| Page runs out of memory | white screen | reloads by itself; saved assessments are kept |
| Camera | file picker | native camera (rear) or photo library |

## Build and install (Mac + Xcode + free Apple ID)

1. **Mac:** Xcode 16 or later. Copy the whole `ios` folder to the Mac.
   The on-phone model `FootSnap/WoundSegmenter.mlpackage` is not in git (162 MB). Make it once from
   `server/model.pt`: `pip install "torch==2.7.0" "transformers<5" coremltools` then
   `python ios/tools/convert_model.py`.
2. Open `ios/FootSnap.xcodeproj`.
3. Xcode › Settings › Accounts › add your Apple ID.
4. Select the **FootSnap** target › **Signing & Capabilities** › Team: *Your Name (Personal Team)*.
   If Xcode says the bundle identifier is taken, change `org.footsnap.research.FootSnap` to
   something unique, e.g. `org.footsnap.research.yourname`.
5. **iPhone:** connect it with a cable, tap *Trust*. Turn on Settings › Privacy & Security ›
   **Developer Mode** (the iPhone restarts).
6. In Xcode pick your iPhone as the run destination and press **Run** (⌘R).
7. The first time: on the iPhone, Settings › General › **VPN & Device Management** › your Apple ID ›
   *Trust*. Then open FootSnap.
8. Allow **Local Network** when asked. Without it the app can't reach the server.

With a free Apple ID the app **stops opening after 7 days**. Connect the iPhone and press Run
again to renew it. A paid Apple Developer Program membership removes the limit and allows TestFlight.

If the project won't open in your Xcode version, regenerate it: `brew install xcodegen`, then
`cd ios && xcodegen` (uses `project.yml`).

## Using it

1. On the Windows computer start the server: `start_server.bat` in the Anaconda Prompt
   (see [../docs/windows.md](../docs/windows.md)). It prints the computer's IPv4 address.
2. In the app enter that address, e.g. `192.168.1.20` (port 8000 is added), tap **Test connection**,
   then **Open FootSnap**.
3. The gear icon (top right) opens the server settings again.
4. On the report, **Print or save as PDF** opens the iPhone share sheet with the PDF.

## Files

```
ios/
  FootSnap.xcodeproj    Xcode project (every file in FootSnap/ is included automatically)
  project.yml           XcodeGen fallback for the project
  Info.plist            allows plain http to the lab server (see below)
  FootSnap/
    FootSnapApp.swift   app entry, root screen, "can't reach the server" screen
    ServerStore.swift   saved address and access code, /api/health check, error messages
    SetupView.swift     server settings screen
    AppWebView.swift    the FootSnap page in a WKWebView; messages from bridge.js
    bridge.js           injected into the page: print -> PDF, clipboard, gear -> native settings
    ReportPDF.swift     A4 PDF from the report's print layout, share sheet
    Assets.xcassets     app icon, logo, accent colour
```

## Debugging

In Debug builds the page can be inspected from the Mac: Safari › Settings › Advanced › *Show
features for web developers*, then Safari › Develop › *your iPhone* › FootSnap.

## Before using it beyond the research group

- The server is plain `http`, so `Info.plist` allows insecure connections. Put the server behind
  HTTPS (e.g. a hospital reverse proxy) and remove `NSAllowsArbitraryLoads`.
- The access code is stored in the app's settings, not the Keychain.
- PDFs are written to the app's private temporary folder and deleted after sharing, but anything
  saved to Files, Mail or AirDrop leaves the app. Follow your information-governance rules.
