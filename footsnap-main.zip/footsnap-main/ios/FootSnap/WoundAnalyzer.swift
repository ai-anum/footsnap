import CoreML
import Foundation
import ImageIO
import UIKit
import UniformTypeIdentifiers
import Vision

/// Segments a wound photo on the iPhone with the Core ML SegFormer-B5 (WoundSegmenter.mlpackage)
/// and writes the same files and result.json as server/pipeline/analyse.py, so the app's screens
/// work unchanged. There is no Marigold on the phone: colour only, no depth maps, no 3D surface.
final class WoundAnalyzer {
    static let shared = WoundAnalyzer()

    static let workSize = 640                  // settings.WORK_SIZE: DFUC2022 scale
    static let threshold: Float = 0.5          // settings.THRESHOLD
    static let woundColour: (UInt8, UInt8, UInt8) = (255, 77, 109)
    /// (width, height) the Core ML model accepts; see ios/tools/convert_model.py SHAPES
    static let modelShapes = [(640, 480), (480, 640), (640, 640), (640, 352), (352, 640), (640, 416), (416, 640)]

    private var model: MLModel?
    private let lock = NSLock()

    enum Failure: LocalizedError {
        case noModel, badPhoto, noOutput(String), cantWrite(String)
        var errorDescription: String? {
            switch self {
            case .noModel: return "the segmentation model is missing from the app"
            case .badPhoto: return "the photo couldn’t be read"
            case .noOutput(let detail): return "the segmentation model gave no result (\(detail))"
            case .cantWrite(let name): return "couldn’t save \(name)"
            }
        }
    }

    private func loadModel() throws -> MLModel {
        lock.lock(); defer { lock.unlock() }
        if let model { return model }
        guard let url = Bundle.main.url(forResource: "WoundSegmenter", withExtension: "mlmodelc") else { throw Failure.noModel }
        let config = MLModelConfiguration()
        config.computeUnits = .all
        let m = try MLModel(contentsOf: url, configuration: config)
        model = m
        return m
    }

    /// Load the model in the background so the first photo doesn't wait for it.
    func warmUp() {
        DispatchQueue.global(qos: .utility).async { _ = try? self.loadModel() }
    }

    // MARK: - Analysis

    func analyse(photo data: Data, into out: URL, progress: (String) -> Void) throws -> [String: Any] {
        var timings: [String: Double] = [:]
        var notes: [String] = []
        func clock(_ name: String, _ t0: Date) { timings[name] = (Date().timeIntervalSince(t0) * 100).rounded() / 100 }

        progress("preparing")
        var t0 = Date()
        guard let photo = UIImage(data: data) else { throw Failure.badPhoto }
        let originalSize = [Int(photo.size.width * photo.scale), Int(photo.size.height * photo.scale)]
        let rgb = try Self.resized(photo, longSide: Self.workSize)
        let w = rgb.width, h = rgb.height
        try Self.writeJPEG(rgb.pixels, w, h, to: out.appendingPathComponent("photo.jpg"), quality: 0.92)
        clock("prepare", t0)

        progress("segmenting")
        t0 = Date()
        let prob = try probability(rgb)
        var mask = [Bool](repeating: false, count: w * h)
        for i in 0..<(w * h) where prob[i] > Self.threshold { mask[i] = true }
        clock("segmentation", t0)
        notes.append("Segmented on this iPhone. The phone has no depth model (Marigold), so the wound was found from colour only and no 3D surface was made. Connect to the lab server for depth and 3D.")

        let line = Self.outline(mask, w, h)
        try Self.writeGray(mask.map { $0 ? 255 : 0 }, w, h, to: out.appendingPathComponent("mask.png"))
        var overlay = rgb.pixels
        let (cr, cg, cb) = Self.woundColour
        for i in 0..<(w * h) {
            if mask[i] { Self.tint(&overlay, i, cr, cg, cb, 0.45) }
            if line[i] { Self.tint(&overlay, i, 255, 255, 255, 0.9) }
        }
        try Self.writeJPEG(overlay, w, h, to: out.appendingPathComponent("overlay.jpg"), quality: 0.92)
        var layer = [UInt8](repeating: 0, count: w * h * 4)
        for i in 0..<(w * h) {
            if line[i] { layer[4 * i] = 255; layer[4 * i + 1] = 255; layer[4 * i + 2] = 255; layer[4 * i + 3] = 255 }
            else if mask[i] { layer[4 * i] = cr; layer[4 * i + 1] = cg; layer[4 * i + 2] = cb; layer[4 * i + 3] = 150 }
        }
        try Self.writeRGBA(layer, w, h, to: out.appendingPathComponent("mask_layer.png"))
        try Self.writeGray(prob.map { UInt8(max(0, min(255, $0 * 255))) }, w, h, to: out.appendingPathComponent("confidence.png"))

        let measurements = Self.measurements(mask, prob, w, h)
        if (measurements["wound_pixels"] as? Int ?? 0) == 0 { notes.append("No wound was found in this photo.") }

        return [
            "size": [w, h], "original_size": originalSize,
            "measurements": measurements,
            "files": ["photo": "photo.jpg", "overlay": "overlay.jpg", "mask": "mask.png",
                      "mask_layer": "mask_layer.png", "confidence": "confidence.png"],
            "notes": notes, "timings": timings,
            "model": ["backend": "Core ML (this iPhone)", "threshold": Double(Self.threshold),
                      "channels": ["R", "G", "B", "curv_mean", "shape_index"], "curvature_used": false],
        ]
    }

    /// Wound probability per pixel of the working-size photo.
    private func probability(_ rgb: RGBImage) throws -> [Float] {
        let model = try loadModel()
        let aspect = Double(rgb.width) / Double(rgb.height)
        let (mw, mh) = Self.modelShapes.min { abs(log(Double($0.0) / Double($0.1) / aspect)) < abs(log(Double($1.0) / Double($1.1) / aspect)) }!
        let input = (mw == rgb.width && mh == rgb.height) ? rgb : try Self.resized(rgb.cgImage(), width: mw, height: mh)

        let array = try MLMultiArray(shape: [1, 3, NSNumber(value: mh), NSNumber(value: mw)], dataType: .float32)
        let plane = mw * mh
        array.withUnsafeMutableBytes { raw, _ in
            let p = raw.bindMemory(to: Float.self)
            for i in 0..<plane {
                p[i] = Float(input.pixels[3 * i])
                p[plane + i] = Float(input.pixels[3 * i + 1])
                p[2 * plane + i] = Float(input.pixels[3 * i + 2])
            }
        }
        let features = try MLDictionaryFeatureProvider(dictionary: ["image": MLFeatureValue(multiArray: array)])
        let prediction = try model.prediction(from: features)
        guard let output = prediction.featureValue(for: "probability")?.multiArrayValue else {
            throw Failure.noOutput("outputs: \(prediction.featureNames.sorted().joined(separator: ", "))")
        }
        var prob = [Float](repeating: 0, count: plane)
        let sy = output.strides[2].intValue, sx = output.strides[3].intValue
        if output.dataType == .float16 {
            output.withUnsafeBytes { raw in
                let p = raw.bindMemory(to: Float16.self)
                for y in 0..<mh { for x in 0..<mw { prob[y * mw + x] = Float(p[y * sy + x * sx]) } }
            }
        } else {
            output.withUnsafeBytes { raw in
                let p = raw.bindMemory(to: Float.self)
                for y in 0..<mh { for x in 0..<mw { prob[y * mw + x] = p[y * sy + x * sx] } }
            }
        }
        if mw == rgb.width && mh == rgb.height { return prob }
        return Self.bilinear(prob, mw, mh, rgb.width, rgb.height)
    }

    // MARK: - Measurements (as analyse.measurements, without depth)

    static func measurements(_ mask: [Bool], _ prob: [Float], _ w: Int, _ h: Int) -> [String: Any] {
        let area = mask.reduce(0) { $0 + ($1 ? 1 : 0) }
        var out: [String: Any] = ["wound_pixels": area, "image_pixels": w * h,
                                  "wound_percent": round2(100 * Double(area) / Double(w * h))]
        let contours = Self.contours(mask, w, h)
        out["regions"] = contours.count
        guard area > 0 else { return out }
        var x0 = w, y0 = h, x1 = 0, y1 = 0
        var conf = 0.0
        for y in 0..<h { for x in 0..<w where mask[y * w + x] {
            x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y)
            conf += Double(prob[y * w + x])
        } }
        out["bbox"] = [x0, y0, x1, y1]
        out["mean_confidence"] = (conf / Double(area) * 1000).rounded() / 1000
        out["perimeter_pixels"] = (contours.map(arcLength).reduce(0, +) * 10).rounded() / 10
        if let biggest = contours.max(by: { polygonArea($0) < polygonArea($1) }), biggest.count >= 5 {
            let (a, b) = minAreaRect(biggest)
            out["length_pixels"] = (max(a, b) * 10).rounded() / 10
            out["width_pixels"] = (min(a, b) * 10).rounded() / 10
        }
        return out
    }

    private static func round2(_ v: Double) -> Double { (v * 100).rounded() / 100 }

    /// Outer contours of the mask in pixel coordinates (Vision's contour detector).
    static func contours(_ mask: [Bool], _ w: Int, _ h: Int) -> [[CGPoint]] {
        guard mask.contains(true), let image = grayImage(mask.map { $0 ? 255 : 0 }, w, h) else { return [] }
        let request = VNDetectContoursRequest()
        request.detectsDarkOnLight = false          // white wound on black
        request.contrastAdjustment = 1
        request.maximumImageDimension = max(w, h)
        do { try VNImageRequestHandler(cgImage: image, options: [:]).perform([request]) } catch { return [] }
        guard let result = request.results?.first else { return [] }
        return result.topLevelContours.map { c in
            c.normalizedPoints.map { CGPoint(x: CGFloat($0.x) * CGFloat(w), y: (1 - CGFloat($0.y)) * CGFloat(h)) }
        }.filter { $0.count >= 3 }
    }

    static func arcLength(_ pts: [CGPoint]) -> Double {
        var total = 0.0
        for i in 0..<pts.count {
            let a = pts[i], b = pts[(i + 1) % pts.count]
            total += Double(hypot(b.x - a.x, b.y - a.y))
        }
        return total
    }

    static func polygonArea(_ pts: [CGPoint]) -> Double {
        var s = 0.0
        for i in 0..<pts.count {
            let a = pts[i], b = pts[(i + 1) % pts.count]
            s += Double(a.x * b.y - b.x * a.y)
        }
        return abs(s) / 2
    }

    /// Side lengths of the smallest rotated rectangle around the points (cv2.minAreaRect).
    static func minAreaRect(_ pts: [CGPoint]) -> (Double, Double) {
        let hull = convexHull(pts)
        guard hull.count >= 3 else { return (0, 0) }
        var best = (Double.infinity, 0.0, 0.0)
        for i in 0..<hull.count {
            let a = hull[i], b = hull[(i + 1) % hull.count]
            let len = Double(hypot(b.x - a.x, b.y - a.y))
            guard len > 1e-9 else { continue }
            let ux = Double(b.x - a.x) / len, uy = Double(b.y - a.y) / len
            var minU = Double.infinity, maxU = -Double.infinity, minV = Double.infinity, maxV = -Double.infinity
            for p in hull {
                let u = Double(p.x) * ux + Double(p.y) * uy, v = -Double(p.x) * uy + Double(p.y) * ux
                minU = min(minU, u); maxU = max(maxU, u); minV = min(minV, v); maxV = max(maxV, v)
            }
            let area = (maxU - minU) * (maxV - minV)
            if area < best.0 { best = (area, maxU - minU, maxV - minV) }
        }
        return (best.1, best.2)
    }

    static func convexHull(_ points: [CGPoint]) -> [CGPoint] {
        let p = points.sorted { $0.x == $1.x ? $0.y < $1.y : $0.x < $1.x }
        guard p.count > 2 else { return p }
        func cross(_ o: CGPoint, _ a: CGPoint, _ b: CGPoint) -> CGFloat { (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x) }
        var lower: [CGPoint] = [], upper: [CGPoint] = []
        for q in p {
            while lower.count >= 2 && cross(lower[lower.count - 2], lower[lower.count - 1], q) <= 0 { lower.removeLast() }
            lower.append(q)
        }
        for q in p.reversed() {
            while upper.count >= 2 && cross(upper[upper.count - 2], upper[upper.count - 1], q) <= 0 { upper.removeLast() }
            upper.append(q)
        }
        return Array(lower.dropLast() + upper.dropLast())
    }

    /// About 2 px wide boundary of the mask, like cv2.drawContours(..., 2).
    static func outline(_ mask: [Bool], _ w: Int, _ h: Int) -> [Bool] {
        var line = [Bool](repeating: false, count: w * h)
        func inside(_ x: Int, _ y: Int) -> Bool { x >= 0 && y >= 0 && x < w && y < h && mask[y * w + x] }
        for y in 0..<h { for x in 0..<w {
            let m = mask[y * w + x]
            // pixels on both sides of the boundary: one inside, one outside
            if inside(x - 1, y) != m || inside(x + 1, y) != m || inside(x, y - 1) != m || inside(x, y + 1) != m {
                line[y * w + x] = true
            }
        } }
        return line
    }

    // MARK: - Pixels

    struct RGBImage {
        let width: Int, height: Int
        var pixels: [UInt8]               // RGB, row-major

        func cgImage() -> CGImage {
            var rgba = [UInt8](repeating: 255, count: width * height * 4)
            for i in 0..<(width * height) { rgba[4 * i] = pixels[3 * i]; rgba[4 * i + 1] = pixels[3 * i + 1]; rgba[4 * i + 2] = pixels[3 * i + 2] }
            let ctx = CGContext(data: &rgba, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width * 4,
                                space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue)!
            return ctx.makeImage()!
        }
    }

    /// The photo upright (EXIF orientation applied), long side `longSide` pixels.
    static func resized(_ photo: UIImage, longSide: Int) throws -> RGBImage {
        let pw = photo.size.width * photo.scale, ph = photo.size.height * photo.scale
        guard pw > 0, ph > 0 else { throw Failure.badPhoto }
        let s = Double(longSide) / Double(max(pw, ph))
        let w = max(1, Int((Double(pw) * s).rounded())), h = max(1, Int((Double(ph) * s).rounded()))
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = true
        let upright = UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: format).image { _ in
            photo.draw(in: CGRect(x: 0, y: 0, width: w, height: h))
        }
        guard let cg = upright.cgImage else { throw Failure.badPhoto }
        return try resized(cg, width: w, height: h)
    }

    static func resized(_ image: CGImage, width w: Int, height h: Int) throws -> RGBImage {
        var rgba = [UInt8](repeating: 0, count: w * h * 4)
        guard let ctx = CGContext(data: &rgba, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { throw Failure.badPhoto }
        ctx.interpolationQuality = .high
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
        var rgb = [UInt8](repeating: 0, count: w * h * 3)
        for i in 0..<(w * h) { rgb[3 * i] = rgba[4 * i]; rgb[3 * i + 1] = rgba[4 * i + 1]; rgb[3 * i + 2] = rgba[4 * i + 2] }
        return RGBImage(width: w, height: h, pixels: rgb)
    }

    /// F.interpolate(mode="bilinear", align_corners=False) for one channel.
    static func bilinear(_ src: [Float], _ sw: Int, _ sh: Int, _ dw: Int, _ dh: Int) -> [Float] {
        var out = [Float](repeating: 0, count: dw * dh)
        let rx = Float(sw) / Float(dw), ry = Float(sh) / Float(dh)
        for y in 0..<dh {
            let fy = max(0, (Float(y) + 0.5) * ry - 0.5)
            let y0 = min(Int(fy), sh - 1), y1 = min(y0 + 1, sh - 1), wy = fy - Float(y0)
            for x in 0..<dw {
                let fx = max(0, (Float(x) + 0.5) * rx - 0.5)
                let x0 = min(Int(fx), sw - 1), x1 = min(x0 + 1, sw - 1), wx = fx - Float(x0)
                let top = src[y0 * sw + x0] * (1 - wx) + src[y0 * sw + x1] * wx
                let bottom = src[y1 * sw + x0] * (1 - wx) + src[y1 * sw + x1] * wx
                out[y * dw + x] = top * (1 - wy) + bottom * wy
            }
        }
        return out
    }

    private static func tint(_ px: inout [UInt8], _ i: Int, _ r: UInt8, _ g: UInt8, _ b: UInt8, _ k: Float) {
        px[3 * i] = UInt8((1 - k) * Float(px[3 * i]) + k * Float(r))
        px[3 * i + 1] = UInt8((1 - k) * Float(px[3 * i + 1]) + k * Float(g))
        px[3 * i + 2] = UInt8((1 - k) * Float(px[3 * i + 2]) + k * Float(b))
    }

    // MARK: - Files

    static func grayImage(_ gray: [UInt8], _ w: Int, _ h: Int) -> CGImage? {
        guard let provider = CGDataProvider(data: Data(gray) as CFData) else { return nil }
        return CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 8, bytesPerRow: w,
                       space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.none.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)
    }

    static func writeGray(_ gray: [UInt8], _ w: Int, _ h: Int, to url: URL) throws {
        guard let image = grayImage(gray, w, h) else { throw Failure.cantWrite(url.lastPathComponent) }
        try write(image, to: url, type: .png)
    }

    static func writeRGBA(_ rgba: [UInt8], _ w: Int, _ h: Int, to url: URL) throws {
        guard let provider = CGDataProvider(data: Data(rgba) as CFData),
              let image = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4,
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
                                  provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)
        else { throw Failure.cantWrite(url.lastPathComponent) }
        try write(image, to: url, type: .png)
    }

    static func writeJPEG(_ rgb: [UInt8], _ w: Int, _ h: Int, to url: URL, quality: Double) throws {
        try write(RGBImage(width: w, height: h, pixels: rgb).cgImage(), to: url, type: .jpeg, quality: quality)
    }

    static func write(_ image: CGImage, to url: URL, type: UTType, quality: Double? = nil) throws {
        guard let dest = CGImageDestinationCreateWithURL(url as CFURL, type.identifier as CFString, 1, nil) else { throw Failure.cantWrite(url.lastPathComponent) }
        var props: [CFString: Any] = [:]
        if let quality { props[kCGImageDestinationLossyCompressionQuality] = quality }
        CGImageDestinationAddImage(dest, image, props as CFDictionary)
        guard CGImageDestinationFinalize(dest) else { throw Failure.cantWrite(url.lastPathComponent) }
    }

    /// A small copy for the picker (build_samples.thumbnail, 560 px wide).
    static func writeThumbnail(from src: URL, to dst: URL, width: Int = 560) {
        guard let image = UIImage(contentsOfFile: src.path), image.size.width > 0 else { return }
        let h = Int((Double(width) * Double(image.size.height / image.size.width)).rounded())
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let thumb = UIGraphicsImageRenderer(size: CGSize(width: width, height: h), format: format).image { _ in
            image.draw(in: CGRect(x: 0, y: 0, width: width, height: h))
        }
        try? thumb.jpegData(compressionQuality: 0.85)?.write(to: dst)
    }
}
