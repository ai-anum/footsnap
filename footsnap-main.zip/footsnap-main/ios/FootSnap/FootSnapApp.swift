import SwiftUI

/// FootSnap for iPhone.
///
/// By default everything runs on the iPhone: the clinician screens are bundled in the app and
/// SegFormer-B5 segments photos with Core ML (colour only; no depth or 3D for new photos).
/// Optionally the app connects to the FootSnap server on a lab computer, which adds Marigold
/// depth, curvature channels and the 3D surface. Either way it adds a native A4 PDF of the
/// report, copying the AireForms summary, and recovery if the web view runs out of memory.
@main
struct FootSnapApp: App {
    @StateObject private var server = ServerStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(server)
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var server: ServerStore
    @State private var showSettings = false
    @State private var loadError: String?

    var body: some View {
        // No server address: FootSnap runs entirely on this iPhone (LocalServer + Core ML).
        let url = server.baseURL ?? LocalServer.rootURL
        AppWebView(url: url,
                   token: server.token,
                   reloadID: server.reloadID,
                   loadError: $loadError,
                   onSettings: { showSettings = true })
            .ignoresSafeArea()
            .overlay {
                if let message = loadError {
                    UnreachableView(message: message,
                                    address: url.absoluteString,
                                    retry: { loadError = nil; server.reload() },
                                    settings: { showSettings = true })
                }
            }
            .onAppear { WoundAnalyzer.shared.warmUp() }
        .sheet(isPresented: $showSettings) {
            SetupView(isSheet: true)
                .environmentObject(server)
        }
    }
}

/// Shown instead of a blank page when the server can't be reached.
struct UnreachableView: View {
    let message: String
    let address: String
    let retry: () -> Void
    let settings: () -> Void

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 44, weight: .regular))
                .foregroundStyle(.secondary)
            Text("Can’t reach the FootSnap server")
                .font(.title3.weight(.semibold))
                .multilineTextAlignment(.center)
            Text(message)
                .font(.callout)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Text(address)
                .font(.footnote.monospaced())
                .foregroundStyle(.secondary)
            VStack(alignment: .leading, spacing: 6) {
                Label("Is server.py running on the computer?", systemImage: "terminal")
                Label("Are the phone and computer on the same Wi-Fi?", systemImage: "wifi")
                Label("Has Windows Firewall allowed Python on Private networks?", systemImage: "shield")
                Label("Settings › FootSnap › Local Network is on?", systemImage: "iphone")
            }
            .font(.footnote)
            .foregroundStyle(.secondary)
            .padding(.top, 4)
            HStack(spacing: 12) {
                Button("Try again", action: retry)
                    .buttonStyle(.borderedProminent)
                Button("Settings", action: settings)
                    .buttonStyle(.bordered)
            }
            .controlSize(.large)
            .padding(.top, 6)
        }
        .padding(28)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }
}
