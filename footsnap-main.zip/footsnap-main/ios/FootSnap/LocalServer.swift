import Foundation
import UIKit
import WebKit

/// FootSnap without a computer: serves the web app bundled in the app (footsnap://app/) and
/// answers the same API as server/server.py, with segmentation done on the iPhone by WoundAnalyzer.
///
/// Requests without a body (pages, pictures, GET, DELETE) arrive through the URL scheme handler.
/// Requests with a body (photo upload, assessment, save sample) come from bridge.js through the
/// "footsnapAPI" message handler, because WebKit doesn't pass FormData bodies to scheme handlers.
final class LocalServer: NSObject, WKURLSchemeHandler {
    static let shared = LocalServer()
    static let scheme = "footsnap"
    static let rootURL = URL(string: "footsnap://app/")!

    struct Reply {
        var status: Int
        var data: Data
        var type: String

        static func json(_ object: Any, status: Int = 200) -> Reply {
            let data = (try? JSONSerialization.data(withJSONObject: object, options: [.fragmentsAllowed])) ?? Data("null".utf8)
            return Reply(status: status, data: data, type: "application/json")
        }
        static func empty(_ status: Int) -> Reply { Reply(status: status, data: Data(), type: "text/plain") }
        static func text(_ message: String, _ status: Int) -> Reply { Reply(status: status, data: Data(message.utf8), type: "text/plain") }
    }

    struct Upload { let name: String; let data: Data }

    enum Body {
        case form([String: Upload], [String: String])
        case text(Data)

        var json: [String: Any]? {
            guard case .text(let data) = self else { return nil }
            return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        }
    }

    // Storage: Application Support/FootSnap/{cases,samples}
    private let root: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("FootSnap", isDirectory: true)
    }()
    private var casesDir: URL { root.appendingPathComponent("cases", isDirectory: true) }
    private var samplesDir: URL { root.appendingPathComponent("samples", isDirectory: true) }
    private var webDir: URL? { Bundle.main.url(forResource: "web", withExtension: nil) }

    private let state = DispatchQueue(label: "footsnap.local.state")         // guards `jobs`
    private let work = DispatchQueue(label: "footsnap.local.work", qos: .userInitiated)   // one photo at a time
    private var jobs: [String: [String: Any]] = [:]
    private var activeTasks = Set<ObjectIdentifier>()                         // main thread only

    static let sampleFiles = ["photo.jpg", "mask.png", "albedo.jpg", "depth.jpg", "normals.jpg",
                              "viewer_closeup.json", "viewer_full.json"]       // build_samples.COPY
    private static let caseFiles: Set<String> = ["photo.jpg", "overlay.jpg", "mask.png", "mask_layer.png", "confidence.png",
                                                 "depth.png", "mesh.glb", "closeup.glb", "viewer_full.json",
                                                 "viewer_closeup.json", "albedo.jpg", "normals.jpg", "depth.jpg"]

    override init() {
        super.init()
        try? FileManager.default.createDirectory(at: casesDir, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: samplesDir, withIntermediateDirectories: true)
        var resources = root
        var values = URLResourceValues()
        values.isExcludedFromBackup = true          // patient photos stay on this phone
        try? resources.setResourceValues(values)
    }

    // MARK: - WKURLSchemeHandler

    func webView(_ webView: WKWebView, start task: WKURLSchemeTask) {
        let id = ObjectIdentifier(task)
        activeTasks.insert(id)
        let request = task.request
        guard let url = request.url else { return }
        let method = (request.httpMethod ?? "GET").uppercased()
        let body = request.httpBody.map { Body.text($0) }
        DispatchQueue.global(qos: .userInitiated).async {
            let reply = self.respond(path: url.path, method: method, body: body)
            DispatchQueue.main.async {
                guard self.activeTasks.remove(id) != nil else { return }      // the page cancelled it
                let response = HTTPURLResponse(url: url, statusCode: reply.status, httpVersion: "HTTP/1.1", headerFields: [
                    "Content-Type": reply.type, "Content-Length": String(reply.data.count), "Cache-Control": "no-store"])!
                task.didReceive(response)
                task.didReceive(reply.data)
                task.didFinish()
            }
        }
    }

    func webView(_ webView: WKWebView, stop task: WKURLSchemeTask) {
        activeTasks.remove(ObjectIdentifier(task))
    }

    /// A request from bridge.js: {method, path, body: {kind: "form", fields} | {kind: "text", text}}.
    func handleMessage(_ message: [String: Any], completion: @escaping (Reply) -> Void) {
        let method = (message["method"] as? String ?? "GET").uppercased()
        let path = message["path"] as? String ?? ""
        var body: Body?
        if let b = message["body"] as? [String: Any] {
            if b["kind"] as? String == "form" {
                var files: [String: Upload] = [:], fields: [String: String] = [:]
                for (key, value) in b["fields"] as? [String: Any] ?? [:] {
                    if let f = value as? [String: Any], let b64 = f["base64"] as? String, let data = Data(base64Encoded: b64) {
                        files[key] = Upload(name: f["name"] as? String ?? "photo.jpg", data: data)
                    } else if let s = value as? String {
                        fields[key] = s
                    }
                }
                body = .form(files, fields)
            } else {
                body = .text(Data((b["text"] as? String ?? "").utf8))
            }
        }
        DispatchQueue.global(qos: .userInitiated).async {
            let reply = self.respond(path: path, method: method, body: body)
            DispatchQueue.main.async { completion(reply) }
        }
    }

    // MARK: - Routing

    func respond(path rawPath: String, method: String, body: Body?) -> Reply {
        let path = rawPath.hasPrefix("/") ? String(rawPath.dropFirst()) : rawPath
        let parts = path.split(separator: "/", omittingEmptySubsequences: true).map(String.init)
        guard !parts.contains(".."), !parts.contains(".") else { return .empty(404) }
        if parts.first == "api" { return api(Array(parts.dropFirst()), method: method, body: body) }
        guard method == "GET" else { return .empty(405) }
        if parts.isEmpty || parts == ["index.html"] { return page() }
        if parts == ["demo", "samples.json"] { return .json(sampleIndex()) }
        if parts.count >= 2, parts[0] == "demo" {
            let user = samplesDir.appendingPathComponent(parts.dropFirst().joined(separator: "/"))
            if FileManager.default.fileExists(atPath: user.path) { return file(user) }
        }
        guard let web = webDir else { return .empty(404) }
        return file(web.appendingPathComponent(parts.joined(separator: "/")))
    }

    private func api(_ p: [String], method: String, body: Body?) -> Reply {
        switch (method, p.count) {
        case ("GET", 1) where p[0] == "health":
            return .json(["ok": true, "segmentation": "Core ML (this iPhone)", "marigold": false, "curvature_stats": false,
                          "token_required": false, "precomputed_maps": [String](), "queue": 0, "on_device": true])
        case ("GET", 1) where p[0] == "cases":
            return .json(listCases())
        case ("POST", 1) where p[0] == "cases":
            return createCase(body)
        case ("GET", 2) where p[0] == "cases":
            return getCase(p[1])
        case ("DELETE", 2) where p[0] == "cases":
            guard valid(p[1]) else { return .empty(404) }
            state.sync { _ = jobs.removeValue(forKey: p[1]) }
            try? FileManager.default.removeItem(at: casesDir.appendingPathComponent(p[1]))
            return .empty(204)
        case ("GET", 3) where p[0] == "cases" && p[2] == "assessment",
             ("PUT", 3) where p[0] == "cases" && p[2] == "assessment":
            return assessment(p[1], method: method, body: body)
        case ("POST", 3) where p[0] == "cases" && p[2] == "sample":
            return saveSample(p[1], body: body)
        case ("GET", 3) where p[0] == "cases":
            guard valid(p[1]), Self.caseFiles.contains(p[2]) else { return .empty(404) }
            return file(casesDir.appendingPathComponent(p[1]).appendingPathComponent(p[2]))
        case ("DELETE", 2) where p[0] == "samples":
            return deleteSample(p[1])
        case ("OPTIONS", _):
            return .empty(204)
        default:
            return .empty(404)
        }
    }

    // MARK: - Cases

    private func valid(_ id: String) -> Bool { UUID(uuidString: id)?.uuidString.lowercased() == id }

    private func createCase(_ body: Body?) -> Reply {
        guard case .form(let files, let fields)? = body, let image = files["image"], !image.data.isEmpty else {
            return .text("send the photo in the 'image' field", 400)
        }
        let id = UUID().uuidString.lowercased()
        let folder = casesDir.appendingPathComponent(id)
        do { try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true) }
        catch { return .text("couldn’t save the photo", 500) }
        let ext = (image.name as NSString).pathExtension.lowercased()
        let stem = String((image.name as NSString).deletingPathExtension.filter { $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" }.prefix(64))
        let photo = folder.appendingPathComponent((stem.isEmpty ? "photo" : stem) + "." + (["jpg", "jpeg", "png", "heic", "webp"].contains(ext) ? ext : "jpg"))
        try? image.data.write(to: photo)
        let meta: [String: Any] = ["id": id, "created": Date().timeIntervalSince1970,
                                   "label": String((fields["label"] ?? "").prefix(80)), "filename": String(image.name.prefix(120))]
        writeJSON(meta, to: folder.appendingPathComponent("meta.json"))
        state.sync { jobs[id] = meta.merging(["status": "queued", "step": "queued"]) { $1 } }

        work.async {
            self.update(id, ["status": "running"])
            do {
                let result = try autoreleasepool {
                    try WoundAnalyzer.shared.analyse(photo: Data(contentsOf: photo), into: folder) { step in
                        self.update(id, ["step": step])
                    }
                }
                self.writeJSON(result, to: folder.appendingPathComponent("result.json"))
                self.update(id, ["status": "done", "step": "done", "result": result])
            } catch {
                try? "\(error)".write(to: folder.appendingPathComponent("error.txt"), atomically: true, encoding: .utf8)
                self.update(id, ["status": "failed", "error": error.localizedDescription])
            }
        }
        return .json(["id": id, "status": "queued"], status: 202)
    }

    private func update(_ id: String, _ fields: [String: Any]) {
        state.sync { if jobs[id] != nil { jobs[id]!.merge(fields) { $1 } } }
    }

    private func getCase(_ id: String) -> Reply {
        guard valid(id) else { return .empty(404) }
        if let job = state.sync(execute: { jobs[id] }) { return .json(job) }
        let folder = casesDir.appendingPathComponent(id)
        guard let meta = readJSON(folder.appendingPathComponent("meta.json")),
              let result = readJSON(folder.appendingPathComponent("result.json")) else { return .empty(404) }
        return .json(meta.merging(["status": "done", "step": "done", "result": result]) { $1 })
    }

    private func listCases() -> [[String: Any]] {
        let folders = (try? FileManager.default.contentsOfDirectory(at: casesDir, includingPropertiesForKeys: nil)) ?? []
        var rows: [[String: Any]] = folders.compactMap { folder in
            guard var meta = readJSON(folder.appendingPathComponent("meta.json")), let id = meta["id"] as? String else { return nil }
            let running = state.sync { jobs[id]?["status"] as? String }
            meta["status"] = running ?? (FileManager.default.fileExists(atPath: folder.appendingPathComponent("result.json").path) ? "done" : "failed")
            return meta
        }
        rows.sort { ($0["created"] as? Double ?? 0) > ($1["created"] as? Double ?? 0) }
        return Array(rows.prefix(50))
    }

    private func assessment(_ id: String, method: String, body: Body?) -> Reply {
        let folder = casesDir.appendingPathComponent(id)
        guard valid(id), FileManager.default.fileExists(atPath: folder.appendingPathComponent("meta.json").path) else { return .empty(404) }
        let path = folder.appendingPathComponent("assessment.json")
        if method == "GET" { return .json(["assessment": readJSON(path) as Any? ?? NSNull()]) }
        guard var value = body?.json, value["values"] is [String: Any] else { return .text("send {values: {...}}", 400) }
        value["saved_at"] = Date().timeIntervalSince1970
        writeJSON(value, to: path)
        return .json(["ok": true])
    }

    // MARK: - Sample library: bundled samples (read-only) + samples saved on this phone

    private func bundledIndex() -> [[String: Any]] {
        guard let web = webDir, let index = readJSON(web.appendingPathComponent("demo/samples.json")) else { return [] }
        return index["samples"] as? [[String: Any]] ?? []
    }

    private func userIndex() -> [[String: Any]] {
        readJSON(samplesDir.appendingPathComponent("samples.json"))?["samples"] as? [[String: Any]] ?? []
    }

    private func sampleIndex() -> [String: Any] {
        ["version": 1, "samples": bundledIndex() + userIndex()]
    }

    private func saveSample(_ caseID: String, body: Body?) -> Reply {
        let folder = casesDir.appendingPathComponent(caseID)
        guard valid(caseID), var result = readJSON(folder.appendingPathComponent("result.json")) else {
            return .text("analyse the photo first", 404)
        }
        let info = body?.json ?? [:]
        let meta = readJSON(folder.appendingPathComponent("meta.json")) ?? [:]
        return state.sync {
            var mine = userIndex()
            let taken = Set((bundledIndex() + mine).compactMap { $0["id"] as? String })
            let name = ((meta["filename"] as? String).map { ($0 as NSString).deletingPathExtension }) ?? caseID
            var base = String(name.filter { $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" }.prefix(40))
            if base.isEmpty { base = "sample" }
            var sid = base, n = 2
            while taken.contains(sid) { sid = "\(base)-\(n)"; n += 1 }

            let out = samplesDir.appendingPathComponent(sid)
            try? FileManager.default.createDirectory(at: out, withIntermediateDirectories: true)
            for f in Self.sampleFiles where FileManager.default.fileExists(atPath: folder.appendingPathComponent(f).path) {
                try? FileManager.default.copyItem(at: folder.appendingPathComponent(f), to: out.appendingPathComponent(f))
            }
            let files = (result["files"] as? [String: String] ?? [:]).filter { Self.sampleFiles.contains($0.value) }
            result["files"] = files
            let date = DateFormatter.localizedString(from: Date(), dateStyle: .medium, timeStyle: .none)
            result["notes"] = ["Saved from FootSnap on \(date). Outputs from the same pipeline as live photos."] + (result["notes"] as? [String] ?? [])
            writeJSON(result, to: out.appendingPathComponent("result.json"))
            WoundAnalyzer.writeThumbnail(from: out.appendingPathComponent("photo.jpg"), to: out.appendingPathComponent("thumb.jpg"))
            let wound = ((result["measurements"] as? [String: Any])?["wound_pixels"] as? Int ?? 0) > 0
            let label = (info["label"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? "Case \(sid)"
            let entry: [String: Any] = ["id": sid, "label": String(label.prefix(80)), "note": String((info["note"] as? String ?? "").prefix(200)),
                                        "outputs": true, "photo": "\(sid)/photo.jpg", "thumb": "\(sid)/thumb.jpg",
                                        "result": "\(sid)/result.json", "wound_found": wound, "saved_from": caseID]
            mine.append(entry)
            writeJSON(["version": 1, "samples": mine], to: samplesDir.appendingPathComponent("samples.json"))
            return .json(["sample": entry], status: 201)
        }
    }

    private func deleteSample(_ sid: String) -> Reply {
        state.sync {
            var mine = userIndex()
            guard mine.contains(where: { $0["id"] as? String == sid }) else {
                // samples that came with the app can't be removed
                return bundledIndex().contains(where: { $0["id"] as? String == sid }) ? .empty(403) : .empty(404)
            }
            mine.removeAll { $0["id"] as? String == sid }
            writeJSON(["version": 1, "samples": mine], to: samplesDir.appendingPathComponent("samples.json"))
            try? FileManager.default.removeItem(at: samplesDir.appendingPathComponent(sid))
            return .empty(204)
        }
    }

    // MARK: - Files

    /// The same page server.py serves at "/": app.html inside a small document skeleton.
    private func page() -> Reply {
        guard let web = webDir, let app = try? String(contentsOf: web.appendingPathComponent("app.html"), encoding: .utf8) else {
            return .text("FootSnap web app missing from the app bundle", 500)
        }
        let html = """
        <!doctype html><html lang="en"><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
        <meta name="theme-color" content="#14284B"><meta name="format-detection" content="telephone=no">
        <link rel="icon" href="icon-192.png">
        <title>FootSnap</title>
        <style>:root{padding-top:env(safe-area-inset-top,0px)}
        body{margin:0}img{max-width:100%}[hidden]{display:none!important}</style>
        </head><body>
        \(app)
        </body></html>
        """
        return Reply(status: 200, data: Data(html.utf8), type: "text/html; charset=utf-8")
    }

    private func file(_ url: URL) -> Reply {
        guard let data = try? Data(contentsOf: url) else { return .empty(404) }
        let types = ["html": "text/html; charset=utf-8", "js": "text/javascript; charset=utf-8", "mjs": "text/javascript; charset=utf-8",
                     "json": "application/json", "webmanifest": "application/manifest+json", "css": "text/css",
                     "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "svg": "image/svg+xml",
                     "glb": "model/gltf-binary", "webp": "image/webp"]
        return Reply(status: 200, data: data, type: types[url.pathExtension.lowercased()] ?? "application/octet-stream")
    }

    private func readJSON(_ url: URL) -> [String: Any]? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    private func writeJSON(_ object: Any, to url: URL) {
        if let data = try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted]) {
            try? data.write(to: url, options: .atomic)
        }
    }
}
