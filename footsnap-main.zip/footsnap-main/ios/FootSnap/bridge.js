/* FootSnap iOS bridge. Injected at document start into the FootSnap page served by server.py.
 *
 * The page is the same app.html the browsers use; this only changes what a WKWebView on
 * iPhone can't do well by itself:
 *   window.print()             -> native A4 PDF of the report (save to Files, AirDrop, Mail, print)
 *   navigator.clipboard        -> native pasteboard (blocked on plain http pages)
 *   the gear (server settings) -> native server settings
 *
 * window.__FOOTSNAP_TOKEN__ is set by the app just before this script runs.
 */
(function () {
  'use strict';
  var handler = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.footsnap;
  function post(msg) { if (handler) handler.postMessage(msg); }

  window.FOOTSNAP_NATIVE = { platform: 'ios', version: 1 };
  function mark() { if (document.documentElement) document.documentElement.classList.add('fs-native'); }
  if (document.documentElement) mark(); else document.addEventListener('DOMContentLoaded', mark);

  // The page reaches the API on its own origin; the access code comes from the native settings.
  try {
    localStorage.setItem('footsnap:server', JSON.stringify(''));
    localStorage.setItem('footsnap:token', JSON.stringify(window.__FOOTSNAP_TOKEN__ || ''));
  } catch (e) {}

  // Report: the app calls window.print(). Send the report id so the PDF gets a useful name.
  window.print = function () {
    var doc = document.getElementById('reportDoc');
    var text = doc ? (doc.innerText || doc.textContent || '') : '';
    var m = text.match(/FS-\d{8}-[A-Z0-9]+/);
    post({ type: 'print', id: m ? m[0] : '' });
  };

  // Copy summary for AireForms.
  var clip = {
    writeText: function (s) { post({ type: 'copy', text: String(s) }); return Promise.resolve(); },
    readText: function () { return Promise.reject(new Error('not available')); }
  };
  try { Object.defineProperty(navigator, 'clipboard', { value: clip, configurable: true }); }
  catch (e) { try { navigator.clipboard.writeText = clip.writeText; } catch (e2) {} }

  // On-iPhone mode (no server): the page is served from the app (footsnap://app/) and the API
  // is answered by LocalServer.swift. WebKit drops FormData/Blob bodies sent to an app's URL
  // scheme, so API requests that carry a body go to the app through a message instead.
  var local = window.__FOOTSNAP_LOCAL__ && window.webkit && window.webkit.messageHandlers &&
              window.webkit.messageHandlers.footsnapAPI;
  if (local) {
    var nativeFetch = window.fetch.bind(window);
    var base64 = function (blob) {
      return new Promise(function (resolve, reject) {
        var r = new FileReader();
        r.onload = function () { resolve(String(r.result).replace(/^data:[^,]*,/, '')); };
        r.onerror = function () { reject(r.error); };
        r.readAsDataURL(blob);
      });
    };
    var encode = function (body) {
      if (typeof FormData !== 'undefined' && body instanceof FormData) {
        var fields = {}, jobs = [];
        body.forEach(function (value, key) {
          if (typeof value === 'string') { fields[key] = value; return; }
          jobs.push(base64(value).then(function (b) {
            fields[key] = { name: value.name || 'photo.jpg', type: value.type || '', base64: b };
          }));
        });
        return Promise.all(jobs).then(function () { return { kind: 'form', fields: fields }; });
      }
      if (body instanceof Blob) return body.text().then(function (t) { return { kind: 'text', text: t }; });
      return Promise.resolve({ kind: 'text', text: String(body) });
    };
    window.fetch = function (input, init) {
      init = init || {};
      var url;
      try { url = new URL(typeof input === 'string' ? input : input.url, location.href); } catch (e) { return nativeFetch(input, init); }
      var method = String(init.method || (input && input.method) || 'GET').toUpperCase();
      if (url.protocol !== location.protocol || url.pathname.indexOf('/api/') !== 0 || init.body == null) {
        return nativeFetch(input, init);
      }
      return encode(init.body).then(function (body) {
        return local.postMessage({ method: method, path: url.pathname, body: body });
      }).then(function (r) {
        var empty = r.status === 204 || r.status === 205 || r.status === 304;
        return new Response(empty ? null : r.body, { status: r.status, headers: { 'Content-Type': r.type } });
      });
    };
  }

  // Gear: open the native server settings instead of the web ones.
  document.addEventListener('click', function (e) {
    var g = e.target && e.target.closest && e.target.closest('#gear');
    if (!g) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    post({ type: 'settings' });
  }, true);
})();
