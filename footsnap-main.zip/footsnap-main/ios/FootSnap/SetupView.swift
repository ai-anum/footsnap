import SwiftUI

/// The gear button in the app: analyse on this iPhone, or on the FootSnap server on a lab computer.
struct SetupView: View {
    @EnvironmentObject private var server: ServerStore
    @Environment(\.dismiss) private var dismiss
    let isSheet: Bool

    @State private var address = ""
    @State private var token = ""
    @State private var status: Status = .idle
    @State private var useServer = false

    enum Status {
        case idle, checking
        case ok(ServerHealth)
        case failed(String)
    }

    var body: some View {
        NavigationStack {
            Form {
                if !isSheet {
                    Section {
                        VStack(alignment: .leading, spacing: 8) {
                            Image("Logo")
                                .resizable()
                                .frame(width: 64, height: 64)
                                .accessibilityHidden(true)
                            Text("FootSnap")
                                .font(.largeTitle.weight(.bold))
                            Text("Diabetic foot ulcer photos: segmentation, 3D surface, assessment and report.")
                                .font(.callout)
                                .foregroundStyle(.secondary)
                            Text("Research prototype. Not a medical device.")
                                .font(.footnote.weight(.semibold))
                                .foregroundStyle(.orange)
                        }
                        .padding(.vertical, 6)
                    }
                }

                Section {
                    Picker("Analyse photos", selection: $useServer) {
                        Text("On this iPhone").tag(false)
                        Text("Lab server").tag(true)
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text("Where photos are analysed")
                } footer: {
                    Text(useServer
                         ? "The lab computer adds Marigold depth, curvature channels and the 3D surface. The phone must be on the same network."
                         : "No computer needed. The wound is found from colour only, and new photos get no depth maps or 3D surface. Photos stay on this iPhone.")
                }

                if !useServer {
                    Section {
                        Button {
                            server.save(address: "", token: "")
                            if isSheet { dismiss() }
                        } label: {
                            Text(isSheet ? "Use this iPhone" : "Open FootSnap")
                                .frame(maxWidth: .infinity)
                                .fontWeight(.semibold)
                        }
                    }
                }

                if useServer {
                Section {
                    TextField("192.168.1.20:8000", text: $address)
                        .keyboardType(.URL)
                        .textContentType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.go)
                        .onSubmit { Task { await test() } }
                    SecureField("Access code (only if the server has one)", text: $token)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } header: {
                    Text("Analysis server")
                } footer: {
                    Text("The computer running server.py. On Windows, run ipconfig in the Anaconda Prompt and use the IPv4 Address, e.g. 192.168.1.20. Port 8000 is added if you leave it out. The phone must be on the same network.")
                }

                Section {
                    Button {
                        Task { await test() }
                    } label: {
                        HStack {
                            Text("Test connection")
                            Spacer()
                            if case .checking = status { ProgressView() }
                        }
                    }
                    .disabled(ServerStore.normalise(address) == nil || isChecking)
                    statusRows
                }

                Section {
                    Button {
                        server.save(address: address, token: token)
                        if isSheet { dismiss() }
                    } label: {
                        Text(isSheet ? "Use this server" : "Open FootSnap")
                            .frame(maxWidth: .infinity)
                            .fontWeight(.semibold)
                    }
                    .disabled(ServerStore.normalise(address) == nil)
                }
                }
            }
            .navigationTitle(isSheet ? "Settings" : "Set up")
            .navigationBarTitleDisplayMode(isSheet ? .inline : .large)
            .toolbar {
                if isSheet {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") { dismiss() }
                    }
                }
            }
            .onAppear {
                address = server.address
                token = server.token
                useServer = !server.address.isEmpty
            }
        }
    }

    private var isChecking: Bool {
        if case .checking = status { return true }
        return false
    }

    @ViewBuilder private var statusRows: some View {
        switch status {
        case .idle, .checking:
            EmptyView()
        case .failed(let message):
            Label(message, systemImage: "xmark.octagon.fill")
                .foregroundStyle(.red)
                .font(.callout)
        case .ok(let h):
            Label("Connected", systemImage: "checkmark.circle.fill")
                .foregroundStyle(.green)
            row("Segmentation", h.segmentation ?? "unknown",
                good: (h.segmentation ?? "").contains("cuda"))
            row("Depth and 3D (Marigold)", (h.marigold ?? false) ? "ready" :
                    ((h.precomputed_maps ?? []).isEmpty ? "not set up" : "saved maps only"),
                good: h.marigold ?? false)
            row("Curvature channels", (h.curvature_stats ?? false) ? "stats.json found" : "missing (colour only)",
                good: h.curvature_stats ?? false)
            if (h.token_required ?? false) && token.isEmpty {
                Label("This server needs an access code.", systemImage: "key.fill")
                    .foregroundStyle(.orange)
                    .font(.callout)
            }
        }
    }

    private func row(_ name: String, _ value: String, good: Bool) -> some View {
        HStack {
            Text(name)
            Spacer()
            Text(value)
                .foregroundStyle(good ? Color.secondary : Color.orange)
                .multilineTextAlignment(.trailing)
        }
        .font(.callout)
    }

    private func test() async {
        status = .checking
        do {
            let health = try await ServerStore.check(address: address, token: token)
            status = .ok(health)
        } catch {
            status = .failed(ServerStore.describe(error))
        }
    }
}
