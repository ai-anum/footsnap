import Foundation

/// What GET /api/health reports (see server/server.py).
struct ServerHealth: Decodable {
    let ok: Bool
    let segmentation: String?
    let marigold: Bool?
    let curvature_stats: Bool?
    let token_required: Bool?
    let precomputed_maps: [String]?
}

enum ServerCheckError: LocalizedError {
    case badAddress
    case http(Int)
    case notFootSnap

    var errorDescription: String? {
        switch self {
        case .badAddress: return "That doesn’t look like a server address. Try something like 192.168.1.20:8000."
        case .http(401): return "The server needs an access code."
        case .http(let code): return "The server answered with an error (\(code))."
        case .notFootSnap: return "Something answered at that address, but it isn’t the FootSnap server."
        }
    }
}

/// The analysis server's address and access code, kept between launches.
@MainActor
final class ServerStore: ObservableObject {
    private static let addressKey = "serverAddress"
    private static let tokenKey = "serverToken"

    @Published var address: String {
        didSet { UserDefaults.standard.set(address, forKey: Self.addressKey) }
    }
    @Published var token: String {
        didSet { UserDefaults.standard.set(token, forKey: Self.tokenKey) }
    }
    /// Changing this reloads the web view.
    @Published private(set) var reloadID = UUID()

    init() {
        address = UserDefaults.standard.string(forKey: Self.addressKey) ?? ""
        token = UserDefaults.standard.string(forKey: Self.tokenKey) ?? ""
    }

    var baseURL: URL? { Self.normalise(address) }

    func reload() { reloadID = UUID() }

    func save(address: String, token: String) {
        self.address = address.trimmingCharacters(in: .whitespacesAndNewlines)
        self.token = token.trimmingCharacters(in: .whitespacesAndNewlines)
        reload()
    }

    /// "192.168.1.20" -> http://192.168.1.20:8000/ ; keeps an explicit scheme or port.
    nonisolated static func normalise(_ text: String) -> URL? {
        var s = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty else { return nil }
        let lower = s.lowercased()
        if !lower.hasPrefix("http://") && !lower.hasPrefix("https://") { s = "http://" + s }
        guard var c = URLComponents(string: s), let host = c.host, !host.isEmpty,
              !host.contains(" ") else { return nil }
        if c.port == nil && c.scheme == "http" { c.port = 8000 }   // server.py's default port
        c.path = "/"
        c.query = nil
        c.fragment = nil
        return c.url
    }

    /// Ask the server what is set up. Throws a readable error if it can't be reached.
    nonisolated static func check(address: String, token: String) async throws -> ServerHealth {
        guard let base = normalise(address) else { throw ServerCheckError.badAddress }
        var request = URLRequest(url: base.appendingPathComponent("api/health"),
                                 cachePolicy: .reloadIgnoringLocalCacheData,
                                 timeoutInterval: 6)
        if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        let (data, response) = try await URLSession.shared.data(for: request)
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 else { throw ServerCheckError.http(status) }
        guard let health = try? JSONDecoder().decode(ServerHealth.self, from: data), health.ok else {
            throw ServerCheckError.notFootSnap
        }
        return health
    }

    /// Plain-language version of a connection error.
    nonisolated static func describe(_ error: Error) -> String {
        if let e = error as? ServerCheckError { return e.localizedDescription }
        let ns = error as NSError
        guard ns.domain == NSURLErrorDomain else { return error.localizedDescription }
        switch ns.code {
        case NSURLErrorTimedOut:
            return "No answer in time. Check the computer is on, server.py is running, and Windows Firewall allows Python."
        case NSURLErrorCannotConnectToHost:
            return "The computer refused the connection. Is server.py running, and on this port?"
        case NSURLErrorCannotFindHost, NSURLErrorDNSLookupFailed:
            return "That computer name couldn’t be found. Use its IP address (ipconfig › IPv4 Address)."
        case NSURLErrorNotConnectedToInternet, NSURLErrorNetworkConnectionLost:
            return "The phone has no network to that computer. Check Wi-Fi, and Settings › FootSnap › Local Network."
        case NSURLErrorAppTransportSecurityRequiresSecureConnection:
            return "iOS blocked the plain http connection."
        default:
            return ns.localizedDescription
        }
    }
}
