import UIKit
import WebKit

/// A4 pages with the same margins as the report's @page rule (14 mm, 18 mm at the bottom).
final class A4PageRenderer: UIPrintPageRenderer {
    static let paper = CGRect(x: 0, y: 0, width: 595.28, height: 841.89)   // A4 in points
    static let mm: CGFloat = 72 / 25.4

    override var paperRect: CGRect { Self.paper }
    override var printableRect: CGRect {
        let m = Self.mm
        return CGRect(x: 14 * m, y: 14 * m,
                      width: Self.paper.width - 28 * m,
                      height: Self.paper.height - 32 * m)
    }
}

enum ReportPDFError: LocalizedError {
    case empty
    var errorDescription: String? { "The report has no pages. Open the report first, then try again." }
}

/// The report as a PDF, made by iOS's own print renderer from the page's print styles
/// (the same layout as "Print or save as PDF" in a desktop browser), without the Safari print dialog.
@MainActor
enum ReportPDF {
    static func render(from webView: WKWebView) throws -> Data {
        let renderer = A4PageRenderer()
        renderer.addPrintFormatter(webView.viewPrintFormatter(), startingAtPageAt: 0)

        let data = NSMutableData()
        let info: [String: Any] = [kCGPDFContextTitle as String: "FootSnap wound assessment report",
                                   kCGPDFContextCreator as String: "FootSnap for iPhone"]
        UIGraphicsBeginPDFContextToData(data, A4PageRenderer.paper, info)
        let pages = renderer.numberOfPages
        renderer.prepare(forDrawingPages: NSRange(location: 0, length: pages))
        for page in 0..<pages {
            UIGraphicsBeginPDFPage()
            renderer.drawPage(at: page, in: UIGraphicsGetPDFContextBounds())
        }
        UIGraphicsEndPDFContext()
        guard pages > 0, data.length > 0 else { throw ReportPDFError.empty }
        return data as Data
    }

    /// Writes the PDF to a private temporary folder (old reports there are removed first).
    static func write(from webView: WKWebView, reportID: String) throws -> URL {
        let data = try render(from: webView)
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("Reports", isDirectory: true)
        try? FileManager.default.removeItem(at: folder)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let safeID = reportID.filter { $0.isLetter || $0.isNumber || $0 == "-" }
        let name = safeID.isEmpty ? "FootSnap report.pdf" : "FootSnap report \(safeID).pdf"
        let file = folder.appendingPathComponent(name)
        try data.write(to: file, options: [.atomic, .completeFileProtection])
        return file
    }

    /// Share sheet: Save to Files, Print, AirDrop, Mail… The temporary copy is deleted afterwards
    /// because the report holds patient information.
    static func share(_ file: URL, from view: UIView) {
        let sheet = UIActivityViewController(activityItems: [file], applicationActivities: nil)
        sheet.completionWithItemsHandler = { _, _, _, _ in
            try? FileManager.default.removeItem(at: file)
        }
        if let pop = sheet.popoverPresentationController {    // iPad
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 80, width: 1, height: 1)
        }
        UIApplication.shared.footsnapTopViewController?.present(sheet, animated: true)
    }
}
