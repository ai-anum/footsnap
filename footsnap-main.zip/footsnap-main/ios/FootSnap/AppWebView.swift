import SwiftUI
import UIKit
import WebKit

/// The FootSnap page from the server, in a WKWebView, wired to native PDF, clipboard and settings.
struct AppWebView: UIViewRepresentable {
    let url: URL
    let token: String
    let reloadID: UUID
    @Binding var loadError: String?
    var onSettings: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()          // keeps the app's saved assessments (localStorage)
        config.allowsInlineMediaPlayback = true
        config.userContentController.add(WeakMessageHandler(context.coordinator), name: "footsnap")
        config.userContentController.addScriptMessageHandler(WeakReplyHandler(context.coordinator), contentWorld: .page, name: "footsnapAPI")
        config.setURLSchemeHandler(LocalServer.shared, forURLScheme: LocalServer.scheme)   // on-iPhone mode
        Self.installScripts(in: config.userContentController, token: token, local: url.scheme == LocalServer.scheme)

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = false
        webView.allowsLinkPreview = false
        // the page handles the notch and home indicator itself (viewport-fit=cover + env(safe-area-inset-*))
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .systemBackground
        #if DEBUG
        if #available(iOS 16.4, *) { webView.isInspectable = true }   // Safari › Develop › iPhone
        #endif

        context.coordinator.webView = webView
        context.coordinator.load(url, id: reloadID)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        let c = context.coordinator
        c.parent = self
        if c.loadedURL != url || c.loadedID != reloadID {
            let ucc = webView.configuration.userContentController
            ucc.removeAllUserScripts()
            Self.installScripts(in: ucc, token: token, local: url.scheme == LocalServer.scheme)
            c.load(url, id: reloadID)
        }
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "footsnap")
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "footsnapAPI", contentWorld: .page)
    }

    private static func installScripts(in ucc: WKUserContentController, token: String, local: Bool) {
        let tokenJSON = (try? JSONSerialization.data(withJSONObject: token, options: .fragmentsAllowed))
            .flatMap { String(data: $0, encoding: .utf8) } ?? "\"\""
        var source = "window.__FOOTSNAP_TOKEN__ = \(tokenJSON);\nwindow.__FOOTSNAP_LOCAL__ = \(local);\n"
        if let url = Bundle.main.url(forResource: "bridge", withExtension: "js"),
           let js = try? String(contentsOf: url, encoding: .utf8) {
            source += js
        }
        ucc.addUserScript(WKUserScript(source: source, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    }

    // MARK: - Coordinator

    @MainActor
    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, WKScriptMessageHandlerWithReply {
        var parent: AppWebView
        weak var webView: WKWebView?
        private(set) var loadedURL: URL?
        private(set) var loadedID: UUID?
        private var exporting = false

        init(_ parent: AppWebView) { self.parent = parent }

        func load(_ url: URL, id: UUID) {
            loadedURL = url
            loadedID = id
            setError(nil)
            webView?.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 10))
        }

        /// Deferred: this can be called while SwiftUI is updating the view.
        private func setError(_ message: String?) {
            Task { @MainActor in self.parent.loadError = message }
        }

        // Messages from bridge.js
        func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
            guard let body = message.body as? [String: Any], let type = body["type"] as? String else { return }
            switch type {
            case "print":
                exportReport(id: body["id"] as? String ?? "")
            case "copy":
                UIPasteboard.general.string = body["text"] as? String ?? ""
                showToast("Summary copied. Paste it into AireForms.")
            case "settings":
                parent.onSettings()
            default:
                break
            }
        }

        // API requests with a body from bridge.js, answered on the phone (on-iPhone mode only)
        func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage,
                                   replyHandler: @escaping @MainActor @Sendable (Any?, String?) -> Void) {
            guard message.frameInfo.request.url?.scheme == LocalServer.scheme,
                  let body = message.body as? [String: Any] else { return replyHandler(nil, "not available") }
            LocalServer.shared.handleMessage(body) { reply in
                replyHandler(["status": reply.status, "type": reply.type,
                              "body": String(decoding: reply.data, as: UTF8.self)], nil)
            }
        }

        private func exportReport(id: String) {
            guard let webView, !exporting else { return }
            exporting = true
            Task { @MainActor in
                defer { self.exporting = false }
                // let the page finish laying out the report before it is paginated
                try? await Task.sleep(nanoseconds: 150_000_000)
                do {
                    let file = try ReportPDF.write(from: webView, reportID: id)
                    ReportPDF.share(file, from: webView)
                } catch {
                    self.alert(title: "Couldn’t make the PDF", message: error.localizedDescription)
                }
            }
        }

        // Navigation
        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = action.request.url else { return decisionHandler(.allow) }
            let sameServer = url.host == loadedURL?.host && url.port == loadedURL?.port
            let external = ["http", "https", "mailto", "tel"].contains(url.scheme ?? "") && !sameServer
            if external && action.targetFrame?.isMainFrame != false && action.navigationType == .linkActivated {
                UIApplication.shared.open(url)          // other websites open in Safari
                return decisionHandler(.cancel)
            }
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            setError(nil)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            fail(error)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            fail(error)
        }

        private func fail(_ error: Error) {
            let ns = error as NSError
            if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorCancelled { return }
            if ns.domain == "WebKitErrorDomain" && ns.code == 102 { return }   // frame load interrupted
            setError(ServerStore.describe(error))
        }

        // The page's process was ended by iOS (usually memory). Reload rather than leave a blank screen.
        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            webView.reload()
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 1_500_000_000)
                self.showToast("FootSnap reloaded after running low on memory. Saved assessments are kept.")
            }
        }

        // target="_blank" / window.open
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                     for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = action.request.url { UIApplication.shared.open(url) }
            return nil
        }

        // alert() / confirm() from the page
        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
            present(a, orElse: completionHandler)
        }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
            a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
            present(a, orElse: { completionHandler(false) })
        }

        // Helpers
        private func present(_ vc: UIViewController, orElse fallback: () -> Void) {
            guard let top = UIApplication.shared.footsnapTopViewController else { return fallback() }
            top.present(vc, animated: true)
        }

        private func alert(title: String, message: String) {
            let a = UIAlertController(title: title, message: message, preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default))
            present(a, orElse: {})
        }

        /// Uses the page's own toast so it looks like the rest of the app.
        private func showToast(_ text: String) {
            let json = (try? JSONSerialization.data(withJSONObject: text, options: .fragmentsAllowed))
                .flatMap { String(data: $0, encoding: .utf8) } ?? "\"\""
            webView?.evaluateJavaScript("""
                (function(){var t=document.getElementById('toast'); if(!t) return;
                 t.textContent=\(json); t.hidden=false; clearTimeout(window.__fsToast);
                 window.__fsToast=setTimeout(function(){t.hidden=true;},3200);})();
                """, completionHandler: nil)
        }
    }
}

/// WKUserContentController keeps a strong reference to its handlers; this breaks the cycle.
@MainActor
final class WeakMessageHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(ucc, didReceive: message)
    }
}

@MainActor
final class WeakReplyHandler: NSObject, WKScriptMessageHandlerWithReply {
    weak var target: WKScriptMessageHandlerWithReply?
    init(_ target: WKScriptMessageHandlerWithReply) { self.target = target }
    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage,
                               replyHandler: @escaping @MainActor @Sendable (Any?, String?) -> Void) {
        guard let target else { return replyHandler(nil, "closed") }
        target.userContentController(ucc, didReceive: message, replyHandler: replyHandler)
    }
}

extension UIApplication {
    var footsnapTopViewController: UIViewController? {
        let scenes = connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first { $0.activationState == .foregroundActive } ?? scenes.first
        var vc = scene?.keyWindow?.rootViewController
        while let next = vc?.presentedViewController { vc = next }
        return vc
    }
}
